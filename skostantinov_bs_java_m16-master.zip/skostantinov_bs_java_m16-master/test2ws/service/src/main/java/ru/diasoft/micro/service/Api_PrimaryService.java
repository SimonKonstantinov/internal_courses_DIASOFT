package ru.diasoft.micro.service;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.diasoft.micro.domain.ApiEntity;
import ru.diasoft.micro.repository.ApiRepository;

import java.util.Optional;

@RequiredArgsConstructor
@Service
@Primary
public class Api_PrimaryService implements ApiService {

    private final ApiRepository repository;

    @Override
    public ResponseEntity<ApiEntity> ApiServicePost(Long id, String name, Integer age) {
        ApiEntity createdEntity = ApiEntity.builder().userID(id).name(name).age(age).build();
        repository.save(createdEntity);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiEntity(id, name, age));
    }


    @Override
    public ResponseEntity<ApiEntity> apiServiceFind(Long id) {
        Optional<ApiEntity> findEntity = repository.findById(id);

        return ResponseEntity.ok().body(new ApiEntity(id, findEntity.get().getName(), findEntity.get().getAge()));


    }

    @Override
    public ResponseEntity<ApiEntity> Api_ServicePutName(Long id, String name) {
        Optional<ApiEntity> findEntity = repository.findById(id);
        ApiEntity updateEntity = findEntity.get();
        updateEntity.setName(name);
        repository.save(updateEntity);

        return ResponseEntity.ok().body(new ApiEntity(updateEntity.getUserID(), updateEntity.getName(), updateEntity.getAge()));
    }

    @Override
    public ResponseEntity<ApiEntity> Api_ServicePutAge(Long id, Integer age) {
        Optional<ApiEntity> findEntity = repository.findById(id);
        ApiEntity updateEntity = findEntity.get();
        updateEntity.setAge(age);
        repository.save(updateEntity);

        return ResponseEntity.ok().body(new ApiEntity(updateEntity.getUserID(), updateEntity.getName(), updateEntity.getAge()));
    }
}
