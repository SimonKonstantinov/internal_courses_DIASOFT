package ru.diasoft.micro.service;
import org.springframework.http.ResponseEntity;
import ru.diasoft.micro.domain.ApiEntity;

/**
 * Created by skonstantinov on 19.01.2021.
 */
public interface ApiService {
    ResponseEntity<ApiEntity> ApiServicePost(
            java.lang.Long id,
            java.lang.String name,
            java.lang.Integer age);

    ResponseEntity<ApiEntity> apiServiceFind(
            java.lang.Long id);

    ResponseEntity<ApiEntity> Api_ServicePutName(
            java.lang.Long id,
            java.lang.String name);




    ResponseEntity<ApiEntity> Api_ServicePutAge(
            java.lang.Long id,
            java.lang.Integer age);

}
