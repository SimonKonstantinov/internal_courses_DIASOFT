package ru.diasoft.micro.domain;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * Created by skonstantinov on 19.01.2021.
 */

@Data
@Builder

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "t_User")

public class ApiEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "t_User_userid_seq")
    @SequenceGenerator(name = "t_User_userid_seq", sequenceName = "t_User_userid_seq")
    @Column(name = "ID")
    private Long userID;

    @Column(name = "Name")
    private String name;

    @Column(name = "Age")
    private Integer age;


}
