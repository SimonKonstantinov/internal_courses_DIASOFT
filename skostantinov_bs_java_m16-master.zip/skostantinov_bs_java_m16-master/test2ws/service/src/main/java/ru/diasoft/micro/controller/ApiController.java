package ru.diasoft.micro.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import ru.diasoft.micro.domain.ApiEntity;
import ru.diasoft.micro.service.ApiService;

/**
 * Created by skonstantinov on 19.01.2021.
 */

@RestController("micro.controller.ApiController")
@Api(tags = {"api"})

public class ApiController {
    private final ApiService apiService;


    @PostMapping("/v1/create")
    @Transactional
    @ApiOperation(value = "Creation a new template.", response = ApiEntity.class)
    public ResponseEntity<?> APICreate(@RequestParam(name = "id", required = true) Long id,
                                       @RequestParam(name = "name", required = true) String name,
                                       @RequestParam(name = "age", required = true) Integer age)
    {
        return this.apiService.ApiServicePost(id, name, age);
    }

    public ApiController(ApiService apiService) {
        this.apiService = apiService;
    }

    @RequestMapping(value = "v1/find/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "Searching a template by Id.", response=ApiEntity.class)
    public ResponseEntity<ApiEntity> tempalteFindById(
            @PathVariable(value = "id")
                    Long test2wsId)
    {
        return apiService.apiServiceFind(test2wsId);
    }


    @Transactional
    @RequestMapping(value = "/v1/updateAge/{id}", method = RequestMethod.PUT)
    @ApiOperation(value = "Modification  age of a tempare.", response=ApiEntity.class)
    public ResponseEntity<ApiEntity> templatePutAge(@RequestParam(name = "id", required = true)
                                                            Long id,
                                                    @RequestParam(name = "age", required = true)
                                                            Integer age)
    {
        return this.apiService.Api_ServicePutAge (id,age );
    }
    @Transactional
    @RequestMapping(value = "/v1/updateName/{id}", method = RequestMethod.PUT)
    @ApiOperation(value = "Modification  name of a tempare.", response=ApiEntity.class)
    public ResponseEntity<ApiEntity> templatePutName(@RequestParam(name = "id", required = true)
                                                             Long id,
                                                     @RequestParam(name = "name", required = true)
                                                             String name)
    {
        return this.apiService.Api_ServicePutName (id,name );
    }


}
