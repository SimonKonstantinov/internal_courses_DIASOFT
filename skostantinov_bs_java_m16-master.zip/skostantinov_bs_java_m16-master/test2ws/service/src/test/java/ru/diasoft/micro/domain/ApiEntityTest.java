package ru.diasoft.micro.domain;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import ru.diasoft.micro.repository.ApiRepository;

import ru.diasoft.micro.service.Api_PrimaryService;

import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * Created by skonstantinov on 19.01.2021.
 */

//@RunWith(SpringRunner.class)
//@SpringBootTest
//
//public class ApiEntityTest {
//    @Mock
//    private ApiRepository repository;
//
//    private Api_PrimaryService service;
//}

