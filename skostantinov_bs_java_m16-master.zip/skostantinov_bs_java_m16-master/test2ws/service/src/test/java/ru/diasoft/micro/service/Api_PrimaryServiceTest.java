package ru.diasoft.micro.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import ru.diasoft.micro.repository.ApiRepository;
import ru.diasoft.micro.domain.ApiEntity;
import static org.junit.Assert.*;
import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.when;

/**
 * Created by skonstantinov on 19.01.2021.
 */

@RunWith(SpringRunner.class)
@SpringBootTest

public class Api_PrimaryServiceTest {

    @MockBean
    private ApiRepository repository;


    private Api_PrimaryService service;


    @Before
    public void init(){
        service = new Api_PrimaryService(repository);

        ApiEntity newEntity = ApiEntity.builder().userID(2L).name("Matvey").age(23).build();

        when(repository.findById(2L)).thenReturn(Optional.of(newEntity));
        when(repository.findById(9L)).thenReturn(Optional.empty());
    }


    @Test
    public void apiServicePost()  {
        ResponseEntity<ApiEntity> response  = service.ApiServicePost(2L,"Aleksey",12);
        assertThat(response.getStatusCode().equals(HttpStatus.CREATED));

        assertThat(response.getBody().getName()).isNotEmpty();


    }



    @Test
    public void api_ServicePutName() throws Exception {
        ResponseEntity<ApiEntity> response  = service.Api_ServicePutName(2L,"Vitaliy");
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        ResponseEntity<ApiEntity> response1 = service.apiServiceFind(2L);
        assertThat(response1.getBody().getName()).isEqualTo("Vitaliy");

    }

    @Test
    public void api_ServicePutAge() throws Exception {
        ResponseEntity<ApiEntity> response  = service.Api_ServicePutAge(2L,34);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        ResponseEntity<ApiEntity> response1 = service.apiServiceFind(2L);
        assertThat(response1.getBody().getAge()).isEqualTo(34);
    }

}