### СБОРКА ПРОЕКТА

Для сборки достаточно выполнить команду:

```bash
mvn clean install
```

Дистрибутив будет находиться в **target/dbmanager-edu-1.0-binary-with-deps.zip**

### ТЕСТИРОВАНИЕ ПРОЛИВОК

Тесты проливок включаются через профили maven (см. pom.xml). Например, тест проливок на H2 запускается так:

```bash
mvn test -Ddbsupport=h2
```


### ЗАПУСК DBMANAGER

1. Распаковать target/dbmanager-edu-1.0-binary-with-deps.zip
2. Внутри архива находится директория dbmanager-edu-1.0
3. Запустить dm.bat / dm.sh со следующими параметрами:

```bash
dm.sh -i --url=jdbc:h2:mem:testdb --driver=org.h2.Driver --username=sa --password=
```

В данном случае dbmanager создаст в памяти базу данных и накатит на нее проливку. При необходимости можно указать другие драйвер, url, username и password.

Например, база данных в файле:

```bash
dm.sh -i --url=jdbc:h2:~/testdb --driver=org.h2.Driver --username=sa --password=
```


Полный перечень доступных параметров можно посмотреть:

```bash
dm.sh -h
```

### ДОКУМЕНТАЦИЯ

Краткую информацию о работе с DBManager можно найти в [readme.pptx](/readme.pptx) 

### ТЕСТОВОЕ ЗАДАНИЕ

Тестовое задание для проверки знаний DBManager лежит в [test-task.docx](/test-task.docx)