package ru.diasoft.micro.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import ru.diasoft.micro.repository.ApiRepository;
import ru.diasoft.micro.domain.ApiEntity;
import static org.junit.Assert.*;
import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.when;

/**
 * Created by skonstantinov on 19.01.2021.
 */

@RunWith(SpringRunner.class)
@SpringBootTest

public class Api_PrimaryServiceTest {

    @MockBean
    private ApiRepository repository;


    private Api_PrimaryService service;


    @Before
    public void init(){
        service = new Api_PrimaryService(repository);

        ApiEntity newEntity = ApiEntity.builder().clientID(2L).name("Matvey").birthday("1995-12-21").inn("7704407589").build();

        when(repository.findById(2L)).thenReturn(Optional.of(newEntity));
        when(repository.findById(9L)).thenReturn(Optional.empty());
    }


    @Test
    public void clientServicePostTest() {
        ResponseEntity<ApiEntity> response  = service.clientServicePost("CLIENT3", "1998-11-22", "666655544");
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody().getName()).isNotEmpty();
    }


    @Test
    public void ApiServiceGetTest() {
        ResponseEntity<ApiEntity> response1  = service.clientServiceFind(2L);
        assertThat(response1.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response1.getBody().getName()).isEqualTo("Matvey");

    }



}