package ru.diasoft.micro;


import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.lang.ArchRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RestController;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.methods;
/*
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class ControllerMethodReturnTypeTest {


    @Test
    public void controllers_should_return() {
        JavaClasses importedClasses = new ClassFileImporter().
                withImportOption(new ImportOption.DoNotIncludeTests()).
                importPackages("ru.diasoft.micro");


        ArchRule rule = methods().
                that().areDeclaredInClassesThat().areAnnotatedWith(RestController.class)
                .should().haveRawReturnType(ResponseEntity.class)
                .because("Ответ АПИ должен быть обернут в ResponseEntity!");

        rule.check(importedClasses);
    }

}


*/