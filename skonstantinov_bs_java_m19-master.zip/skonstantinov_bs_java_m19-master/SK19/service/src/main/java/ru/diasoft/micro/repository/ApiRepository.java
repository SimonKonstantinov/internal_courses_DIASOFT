package ru.diasoft.micro.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import ru.diasoft.micro.domain.ApiEntity;
import org.springframework.stereotype.Repository;
/**
 * Created by skonstantinov on 19.01.2021.
 */

@Repository
public interface ApiRepository extends JpaRepository<ApiEntity, Long>
{

}
