package ru.diasoft.micro.service;
import org.springframework.http.ResponseEntity;
import ru.diasoft.micro.domain.ApiEntity;

/**
 * Created by skonstantinov on 19.01.2021.
 */
public interface ApiService {
    ResponseEntity<ApiEntity> clientServicePost(
            String name,
            String birthday,
            String inn);


    ResponseEntity<ApiEntity> clientServiceFind(
            Long clientID);


}
