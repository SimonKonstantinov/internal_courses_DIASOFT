package ru.diasoft.micro.service;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.diasoft.micro.domain.ApiEntity;
import ru.diasoft.micro.repository.ApiRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import java.util.Optional;

@RequiredArgsConstructor
@Service
@Primary
public class Api_PrimaryService implements ApiService {
    private final Logger logger = LogManager.getLogger(this.getClass());
    private final ApiRepository repository;

    @Override
    public ResponseEntity<ApiEntity> clientServicePost( String name, String birthday, String INN) {
        ApiEntity createdUser = ApiEntity.builder().name(name).birthday(birthday).inn(INN).build();
        repository.save(createdUser);
        logger.info("new client = " + createdUser);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiEntity(createdUser.getClientID(),name, birthday, INN));
    }


    @Override
    public ResponseEntity<ApiEntity> clientServiceFind(Long clientID) {
        logger.info("clientID = " + clientID);
        Optional<ApiEntity> findEntity = repository.findById(clientID);
        logger.info("find client " + clientID+ "name "+findEntity.get().getName()+"Birthday "+findEntity.get().getBirthday()+"INN "+ findEntity.get().getInn());
        return ResponseEntity.ok().body(new ApiEntity(clientID, findEntity.get().getName(), findEntity.get().getBirthday(), findEntity.get().getInn()));
    }

}