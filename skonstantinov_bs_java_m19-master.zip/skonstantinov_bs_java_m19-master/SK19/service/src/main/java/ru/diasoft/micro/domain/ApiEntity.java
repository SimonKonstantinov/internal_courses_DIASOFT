package ru.diasoft.micro.domain;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;


import javax.persistence.*;

/**
 * Created by skonstantinov on 19.01.2021.
 */

@Data
@Builder

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "SK_CLIENT")

public class ApiEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SK_CLIENT_CLIENTID_seq")
    @SequenceGenerator(name = "SK_CLIENT_CLIENTID_seq", sequenceName = "SK_CLIENT_CLIENTID_seq")
    @Column(name = "CLIENTID")
    private Long clientID;

    @Column(name = "NAME")
    private String name;

    @Column(name="BIRTHDAY")
    @DateTimeFormat(pattern = "yyyy-MM-dd", iso = DateTimeFormat.ISO.DATE_TIME)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @ApiModelProperty(name = "BIRTHDAY", dataType = "java.util.Date", value = "BIRTHDAY")
    @JsonProperty("BIRTHDAY")
    private String birthday;

    @Column(name  = "INN")
    private String inn;


}
