package ru.diasoft.micro.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import ru.diasoft.micro.domain.ApiEntity;
import ru.diasoft.micro.mdp.lib.utils.exception.APIException;
import ru.diasoft.micro.mdp.lib.utils.exception.ExceptionUtils;
import ru.diasoft.micro.service.ApiService;

/**
 * Created by skonstantinov on 19.01.2021.
 */

@RestController("micro.controller.ApiController")
@Api(tags = {"api"})

public class ApiController {
    private final ApiService apiService;


    @PostMapping("/v1/add")
    @Transactional
    @ApiOperation(value = "add a new client", response = ApiEntity.class)
    public ResponseEntity<?> AddClient(
            @RequestParam(name = "name", required = true) String name,
            @RequestParam(name = "birthday", required = true) String birthday,
            @RequestParam(name = "inn", required = true) String inn) {
        try {
            return this.apiService.clientServicePost(name, birthday, inn);
        } catch (APIException var3) {
            return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(ExceptionUtils.buildErrorData(var3));
        } catch (Exception var4) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ExceptionUtils.buildErrorData(var4, Integer.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), Integer.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value())));
        }
    }


    public ApiController(ApiService apiService) {
        this.apiService = apiService;
    }

    @RequestMapping(value = "v1/find/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "Searching a template by Id.", response=ApiEntity.class)
    public ResponseEntity<?> ClientFindByID(@RequestParam(name = "clientID", required = true) Long clientID){
        try {
            return this.apiService.clientServiceFind(clientID);
        } catch (APIException var4) {
            return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(ExceptionUtils.buildErrorData(var4));
        } catch (Exception var5) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ExceptionUtils.buildErrorData(var5, Integer.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), Integer.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value())));
        }
    }
}

