/*
 initElementIdsJS 1.0 Copyright 2012 OOO "Diasoft". All rights reserved.
*/
function initElementIdsJS(){EI={};var e=getAllIds(); if (window["flexObjectsIds"]){e=e.concat(flexObjectsIds)} for(var t=0;t<e.size();t++){var n=e.get(t),r=n.lastIndexOf("_");r=r==-1?n.lastIndexOf("."):r,r==-1?r=0:r++,EI[n.substring(r)]=n.replace(/_/gi,".")}}
