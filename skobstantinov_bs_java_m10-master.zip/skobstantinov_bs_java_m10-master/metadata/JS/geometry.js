setGeometryByVisible = function (pnlList,mainEl,isRoot,startCoord,interBlock,mergeBlock){
	//println("setGeometryByVisible");
	interBlock= interBlock!=null ? interBlock : 4;
	mergeBlock = mergeBlock!=null ? mergeBlock : 0;
	var curY=startCoord;

	for (var i=0;i<pnlList.length;i++){

		if (pnlList[i]!=null && gbi(pnlList[i])!=null){
			if (isVisible(pnlList[i])){
				setCoordY(pnlList[i],curY);
				if (gbi(pnlList[i]+"Pnl")){}
				if (gbi("pnl"+pnlList[i]+"")){
					setHeight("pnl"+pnlList[i],getHeight(pnlList[i])-14);
				}
				curY+=getHeight(pnlList[i])+mergeBlock;
			}
		}
	}
	
	if (mainEl!=null) {
		setHeight(mainEl,curY+interBlock);
		if (gbi(mainEl+"pnl")){
			setHeight(mainEl+"pnl",curY+interBlock);
		}
		if (gbi("pnl"+mainEl)){
			setHeight("pnl"+mainEl,curY+interBlock);
		} 
		if (isRoot){
			setPageBodyContainerHeight(curY+interBlock);
		}
	}
}

setXGeometryByVisible = function (pnlList,startCoord,interBlock,mergeBlock){
	//println("setXGeometryByVisible");
	interBlock= interBlock!=null ? interBlock : 4;
	mergeBlock = mergeBlock!=null ? mergeBlock : 0;
	var curX=startCoord;
	
	for (var i=0;i<pnlList.length;i++){
		if (pnlList[i]!=null && gbi(pnlList[i])!=null){
			if (isVisible(pnlList[i])){
				setCoordX(pnlList[i],curX);
				if (gbi(pnlList[i]+"Pnl")){}
				if (gbi("pnl"+pnlList[i]+"")){
					setWidth("pnl"+pnlList[i],getWidth(pnlList[i])-14);
				}
				curX+=getWidth(pnlList[i])+mergeBlock;
			}
		}
	}
}
