function isPlatform8() {
	isPlatform8Flag = false;
    try {
		var gwtFrame = getGWTFrame();
		if (gwtFrame) {
			isPlatform8Flag = true; 
		}
    }
    finally {
		return isPlatform8Flag;
    }
}

function fixFormCaptionWidth(formId) {
	if (!isPlatform8()) {
		setWidth('formCaptionLabel', /*getPageBodyContainerWidth()*/ getWidth(formId) - 8); // Растяжка верхнего разделителя (размер формы - padding-right)
	}
}