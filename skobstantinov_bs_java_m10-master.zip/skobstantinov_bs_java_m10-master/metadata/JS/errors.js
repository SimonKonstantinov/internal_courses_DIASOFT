function businessError() {
	/*
	 * Проверка бизнеc-ошибки в pageflow
	 */
	var NotificationList = Process.get('NotificationList');
	var ReturnCode = Process.get('ReturnCode');
	var ReturnMsg  = Process.get('ReturnMsg');

	if (ReturnCode!=null && ReturnCode!='' && ReturnCode!=0) {
		setOutputParams('lastErrorCode',ReturnCode);
		setOutputParams('lastErrorMessage',ReturnMsg);
		return true;
	}

	if (NotificationList!=null && NotificationList.size()>0) {
		for (var i=0;i<NotificationList.size();i++) {
			if (NotificationList.get(i).get('NTFID')!=0) {
				return true;
			}
		}
	}
	
	return false;
}

function checkServiceError(Result){
	/*
	 * Функция ловит из процесса ошибку от сервиса, либо exception, либо список бизнес-ошибок
	 */
	if (Result) {
        var lastErrorCode       = Result.get('lastErrorCode');
        var lastErrorMessage    = Result.get('lastErrorMessage');
        var ReturnCode 		 	= Result.get('ReturnCode');
        var ReturnMsg 		 	= Result.get('ReturnMsg');
        var NotificationList 	= Result.get('NotificationList');    
    }
    else {
        var lastErrorCode        = getInputParams('lastErrorCode');
        var lastErrorMessage     = getInputParams('lastErrorMessage');
        var lastErrorDescription = getInputParams('lastErrorDescription');
        var ReturnCode 		 	 = getInputParams('ReturnCode');
        var ReturnMsg 		 	 = getInputParams('ReturnMsg');
        var NotificationList 	 = getInputParams('NotificationList');    
    }
    
	if (NotificationList && NotificationList.size()>0 && NotificationList.get(0).get("NTFID")!=0){
		errorFormList(NotificationList);
		if (Result) {
            return true;
        }
        setInputParam('NotificationList',null);
		setOutputParams('NotificationList',null);
	}
	else if (lastErrorCode || lastErrorMessage){
		if (lastErrorDescription){
			errorForm(lastErrorCode,lastErrorMessage,lastErrorDescription);
		} else {
			errorForm(lastErrorCode,lastErrorMessage,lastErrorMessage);
		}
        if (Result) {
            return true;
        }
		setInputParam('lastErrorCode',null);
		setInputParam('lastErrorMessage',null);
		setInputParam('lastErrorDescription',null);
		setOutputParams('lastErrorCode',null);
		setOutputParams('lastErrorMessage',null);
		setOutputParams('lastErrorDescription',null);
	}
	else if ((ReturnCode || ReturnMsg) && ReturnCode!=0){
		errorForm(ReturnCode,ReturnMsg,ReturnMsg);
		if (Result) {
            return true;
        }
        setInputParam('ReturnCode',null);
		setInputParam('ReturnMsg',null);
		setOutputParams('ReturnCode',null);
		setOutputParams('ReturnMsg',null);
	}
    return false;
}

function errorForm(lastErrorCode, lastErrorMessage, lastErrorDescription){
	/*
	 * Функция отображает окно сообщения об ошибке
	 * Входные параметры:
	 *  lastErrorCode 			- код ошибки
	 *  lastErrorMessage 		- короткое сообщение об ошибке
	 *  lastErrorDescription 	- полное сообщение об ошибке
	 */    
	if  ((lastErrorCode!=null && lastErrorCode!="") || (lastErrorMessage!=null && lastErrorMessage!="")){
		
		var msgList = getNewList();
		var errorMsg = getNewMap();
		
		errorMsg.put('MSGCODE',  lastErrorCode);
		errorMsg.put('SHORTMSG', lastErrorMessage);
		errorMsg.put('LONGMSG',  lastErrorDescription);
		msgList.add(errorMsg);

		showMessageStack(msgList);
	}
}

function errorFormList(NotificationList){
	/*
	 * Функция отображает окно сообщения об ошибке со списком ошибок
	 * Входные параметры:
	 *  NotificationList - список ошибок
	 */
	if (NotificationList!=null && NotificationList!="") {
		
		var msgList = getNewList();
		var errorMsg;
		
		for (var i=0;i<NotificationList.size();i++){
			errorMsg = getNewMap();
			
			errorMsg.put('MSGCODE',  NotificationList.get(i).get("NTFID"));
			errorMsg.put('SHORTMSG', NotificationList.get(i).get("NTFMessage"));
			errorMsg.put('LONGMSG',  NotificationList.get(i).get("NTFMessage"));
			msgList.add(errorMsg);
		}
		
		showMessageStack(msgList);
	}
}
