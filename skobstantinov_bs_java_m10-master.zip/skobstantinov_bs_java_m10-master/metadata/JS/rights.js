function checkEffectiveRight(postProcessFunc) {
	/*
	  * Проверка прав в вебклиенте
	  */
	if (rights.length>0) {
		if (srights && rights[0].sysname in srights) {
			updateEffectiveRight(srights[rights[0].sysname]);
			checkEffectiveRight();
		}
		else {
			dsCall("[adminws]","dsUserCheckAccountEffectiveRight",new InlineMap({USERACCOUNTID: getInputParams('USERACCOUNTID'), RightSysName: rights[0].sysname}), "checkEffectiveRightCallback");
		}
	}
	else {
		rights = [];
		var note = 'Allowed rights: ';
		for (var i=0;i<chrights.length;i++) {
			rights[chrights[i].sysname]  = chrights[i].value;
			srights[chrights[i].sysname] = chrights[i].value;
			if (chrights[i].value) {
				note += chrights[i].sysname + ', ';
			}
		}
		//println(note);
		chrights = null;
		
		showElementsByRights.call(null);
	}
}
  
function checkEffectiveRightCallback(Result) {
	if (Result && Result.get("CheckResult")!==null) {
		updateEffectiveRight(Result.get("CheckResult"));
		checkEffectiveRight();
	}
}

function updateEffectiveRight(result) {
	rights[0].value = result;
	chrights.push(rights.shift());
}

function createMenuByRights(Menu){
    var menu = getNewList();
	for (var j=0;j<Menu.length;j++){
		// Добавляем пункт меню только в том случае, если доступно право
		if (Menu[j][3]) {
			addMenuItem(menu,Menu[j][0],"",Menu[j][1],"SCRIPT","",Menu[j][2]);
		}
	}
    return menu;
}

function showElementByRight(name, right) {
	if (right)
		showElement(name);
}

function checkEffectiveRightByRole() {
   var ROLES = getInputParams('ROLES') || getNewList();
   for (var i=0, N=ROLES.size(); i<N; i++) {
       var ROLE = ROLES.get(i);
       if (ROLE.get('ROLESYSNAME') == 'FCReportAdmin') {
          rights['RReportView']   = true;
          rights['RReportInsert'] = true;
          rights['RReportUpdate'] = true;
          rights['RReportDelete'] = true;
          rights['RInstanceView'] = true;
          rights['RProtocolView'] = true;
		  rights['RInstanceDelete'] = true;
       } else if (ROLE.get('ROLESYSNAME') == 'FCReportUser') {
          rights['RReportView']    = true;
          rights['RReportExecute'] = true;
          rights['RInstanceView']  = true;
          rights['RProtocolView']  = true;
		  rights['RReportDownload'] = true;
		  rights['RInstanceDelete'] = true;
       }
   }
   showElementsByRights.call(null);
}
