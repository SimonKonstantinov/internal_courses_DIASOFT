
function addRows(tableName, rowsList, clearFlag, asyncFlag){
	/*
	 * addRows - добавляет список строк rowsList в таблицу tableName
	 * предварительно очищает таблицу если clearFlag передан true
	 */
	if (clearFlag==true) {
		clearTable(tableName);
	}
	
	if (asyncFlag==true) {
		for (var k=0;k<rowsList.size();k++){
			addRowAsync(tableName,rowsList.get(k));
		}
	}
	else {
		for (var k=0;k<rowsList.size();k++){
			addRow(tableName,rowsList.get(k));
		}
	}
}

function formatSumm(inputSumm){
	/*
	 * formatSumm - форматирует сумму inputSumm, отсекая до 2х знаков после запятой и разделяя на группы разрядов.
	 * В отличие от встроенной formatAmount не округляет копейки. inputSumm - сумма.
	 */
	if (inputSumm==null){
		var amountStr="0";
	} else {	
		var amountStr=inputSumm+"";
	}
	
	var pointIdx=amountStr.indexOf(".");
	if (pointIdx!=-1){
		var amountStrCut=amountStr.substring(0,pointIdx);
		var divCnt=Math.floor(amountStrCut.length/3);
		var firstPiece=amountStrCut.length - (divCnt*3);
		var outStr=""+amountStrCut.substring(0,firstPiece);
		var j=firstPiece;
		while (j<amountStrCut.length){
			outStr=outStr+" "+amountStrCut.substring(j,j+3);
			j=j+3;
		}
		outStr=outStr+".";
		var amountStrFl=amountStr.substring(pointIdx+1,amountStr.length);
		if (amountStrFl.length<2){
			outStr=outStr+amountStrFl+"0";
		}
		else {
			outStr=outStr+amountStrFl.substring(0,2);
		}
		
	}
	/*
	else {
		var divCnt=Math.floor(amountStr.length/3);
		var firstPiece=amountStr.length - (divCnt*3);
		var outStr=""+amountStr.substring(0,firstPiece);
		var j=firstPiece;		
		while (j<amountStr.length){
			outStr=outStr+" "+amountStr.substring(j,j+3);
			j=j+3;
		}
		outStr=outStr+".00";
	}
	*/
	
	return outStr;
}

function addComboOptions(comboName, rowsList, values, names, clearFlag){
	/*
	 * addComboOptions	- добавляет список строк rowsList в комбобокс comboName
	 * предварительно очищает комбобокс если clearFlag передан true
	*/
	if (clearFlag==true){
		clearComboOptions(comboName);
	}
	
	for(var k=0;k<rowsList.size();k++){
		addComboOption(comboName,rowsList.get(k).get(values),rowsList.get(k).get(names));
	}
}

function deleteComboOptionByIndex(componentName, index){
	/*
	 * deleteComboOptionByIndex - Удаление указанного элемента списка компонентов TWList и TWComboBox
	 * componentName	- полное имя компонента
	 * index			- номер удаляемого элемента
	 */
	var opts=getComboOptions(componentName);
	clearComboOptions(componentName);
	for (var j=0;j<opts.length;j++){
		if (j!=index) addComboOption(componentName,opts[j]['VALUE'],opts[j]['TEXT']);
	}
}

function deleteComboOptionByValue(componentName, value){
	/*
	 * deleteComboOptionByIndex - Удаление указанного элемента списка компонентов TWList и TWComboBox
	 * componentName	- полное имя компонента
	 * index			- номер удаляемого элемента
	 */
	var opts=getComboOptions(componentName);
	clearComboOptions(componentName);
	for (var j=0;j<opts.length;j++){
		if (opts[j]['VALUE']!=value) addComboOption(componentName,opts[j]['VALUE'],opts[j]['TEXT']);
	}
}

function addMenuItem (menuObj, nameValue, childrenValue, enableValue, typeValue, tagValue, scriptValue, validateValue){

	if (!nameValue) nameValue=""; 
	if (!childrenValue) childrenValue="";
	if (!enableValue) enableValue="true";
	if (!typeValue) typeValue="";
	if (!tagValue) tagValue="";
	if (!scriptValue) scriptValue="";
	if (!validateValue) validateValue="false";

	var map = getNewMap();
	map.put("name", nameValue);
	if (childrenValue!="") map.put("children", childrenValue)
	map.put("enabled", enableValue); 
	map.put("type", typeValue);
	map.put("tag", tagValue);
	map.put("script", scriptValue);
	map.put("validate", validateValue);
	menuObj.add(map);
}

function createMenu(Menu){
	/*
	 *	createMenu - Функция создания контекстного меню. Возвращает меню согласно входному массиву Menu.
	 *	
	 *	Входные параметры:
	 *		Menu - массив вида Menu[n] = ["caption","status","action"];
	 *			n		- порядковый номер элемента меню
	 *			caption - текст пункта меню
	 *			status	- статус пункта, true/false
	 *			action	- имя JavaScript-функции
	*/
	var menu = getNewList();

	for (var j=0;j<Menu.length;j++){
		addMenuItem(menu,Menu[j][0],"",Menu[j][1],"SCRIPT","",Menu[j][2]);
	}
	
	return menu;
}

function setCheckBoxFlag(flagList, flagName, checkBoxName){
	/*
	 * setCheckBoxFlag - функция установки чекбокса по флагу
	 */
	for (var j=0;j<flagList.size();j++){
		if ((flagList.get(j).get("FLAGNAME")==flagName) && (flagList.get(j).get("FLAGVALUE")==1)){
			setCheckBoxChecked(checkBoxName,true);
		}
	}
}

function getSeparator(){
	var symbol = String.fromCharCode(8212);
	var separator = "";
	for(var i=0; i<15; i++) separator = separator + symbol;
	return separator;
}

function checkTableRowExist(tableName, fieldName, fieldValue){
	/*
	 * Функция проверяет существование строки в таблице
	 */
	var cnt=getRowsCount(tableName);
	for (var i=0;i<cnt;i++){
		if (getCellText(tableName,i,fieldName)==fieldValue){   
			setSelectedRow(tableName,i);
			return true;
	 	}
	}
	return false;
}

function checkDates(startDate, endDate){
	/*
 	 * Функция проверяет, что выбранные для диапазона даты не пересекаются
 	 */
	if (parseInt(diffDate(startDate,endDate,"day"))<0){
		return false;
	} else {
		return true;
	}
}

function checkDatesAndGo(startDate, endDate, tag, validate){
	/*
	 * Функция проверяет, что выбранные для диапазона даты не пересекаются и переходит по тэгу
	 */
	if (startDate!=null && endDate!=null){
		if (!validateForm()){
			return;
		}
		if (checkDates(convertDate(startDate),convertDate(endDate))){
			sendForm(tag,validate);
		} else {
			showError(getResourceBundle("validateDates"));
		}
	} else {
		sendForm(tag,validate);
	}
}

function nvl(source,value) {
	if (source!=null && source!='' && !isNaN(source)) {
		return source;
	}
	else
		return value;
}

function stringFromTemplate (template, data) {
    /*
     * Функция преобразует шаблон с параметрами %param, подставляя значения из объекта {param: value}
     */
    var reg = /%(\w+)/g;
    
    if (!data) return template;
    
    return template.replace(reg, function (str, key) {
        return (key in data) ? data[key] : '';
    });
}

// Функции-обертки для стандартных для повышения (субъективно) удобства

function toggleElementVisible(name, cond) {
    /*
     * Функция отображает или скрывает элемент 'name' в зависимости от условия 'cond'
     */
    if (cond) {
        showElement(name);
    } else {
        hideElement(name);
    }
}

function toggleElementEnable(name, cond) {
    /*
     * Функция включает или выключает элемент 'name' в зависимости от условия 'cond'
     */
    if (cond) {
        enableElement(name);
    } else {
        disableElement(name);
    }
}

function setInputParamExt(name, getter, postfix, callback) {
	var inName = name.replace(/\./g, '_') + (postfix ? ('_' + postfix) : '');
	if (callback) {
		setInputParam(inName, getter(name), callback);
	} else {
		setInputParam(inName, getter(name));
	}
}

function setRequiredExt(name, require, labelName) {
	setRequired(name, require);
	if (labelName) {
		if (require) {
			setValue(labelName, '<u>'+getValue(labelName)+'</u>');
		} else {
			setValue(labelName, getValue(labelName).replace('<u>','').replace('</u>',''));
		}
	}
}
