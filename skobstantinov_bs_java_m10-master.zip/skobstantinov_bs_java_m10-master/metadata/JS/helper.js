/*
 * InlineMap, InlineList
 */
function InlineMap(obj) {
    var map = getNewMap();
    if (obj instanceof Object) {
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
				map.put(''+key, obj[key]);
			}
        }
    }
    return map;
}

function InlineList(arr) {
    var list = getNewList();
    if (Object.prototype.toString.call(arr) === '[object Array]') {
        for (var i=0,l=arr.length; i<l; i++) {
            list.add(new InlineMap(arr[i]));
        }
    }
    return list;
}

function copyMap(obj) {
	return new InlineMap(obj);
}

/*
 * Resizer
 */
function Resizer(formName, rightPadding, bottomPadding) {
    
    // Отступы
	var CP = 33;
    var rP = rightPadding  || 15;
    var bP = /*(bottomPadding || 15) - CP*/ 15 + CP;
	
    // Начальные размеры формы
    var startWidth  = /*getPageBodyContainerWidth()*/  getWidth(formName);
    var startHeight = /*getPageBodyContainerHeight()*/ getHeight(formName);
	
    // Массивы элементов для ресайзинга по ширине и высоте соответственно
    var x = [];
    var y = [];
    
    var addWidth = function (element, fixWidth) {
        if (fixWidth) {
            element.width = getWidth(element.name);
        }
    }
    
    var addHeight = function (element, fixHeight) {
        if (fixHeight) {
            element.height = getHeight(element.name);
        }
    }
    
    var addPercent = function (element, percent) {
        var p = parseFloat(percent);
        if (!isNaN(p) && p > 0 && p < 1) {
            element.percent = p;
        }
    }

    return {
        
        // Метод для выполнения ресайзинга
        resize: function () {
            
            var clientWidth  = getClientWindowSize().get(0);
            var clientHeight = getClientWindowSize().get(1);
            
            if (clientWidth - rP > startWidth && x.length > 0) {
                
                var formWidth = getWidth(formName);
                var dX = clientWidth  - rP - formWidth;
                
                setWidth(formName,  formWidth + dX);
                setPageBodyContainerWidth(formWidth + dX);
                
                for (var i=0, N=x.length; i<N; i++) {
                    var curX = x[i];
                    var curDx = dX;
                    if (curX.percent) curDx = Math.round(1*dX*curX.percent);
                    if (curX.right) {
                        setCoordX(curX.name, getCoordX(curX.name) + curDx);
                    } else {
                        setWidth(curX.name, (curX.width || getWidth(curX.name)) + curDx);
                        if (curX.width) curX.width += curDx;
                    }
                }
            }
            
            if (clientHeight - bP > startHeight && y.length > 0) {
                
                var formHeight = getHeight(formName);
                var dY = clientHeight - bP - formHeight;
                
                setHeight(formName, formHeight + dY);
                setPageBodyContainerHeight(formHeight + dY);
                
                for (var i=0, N=y.length; i<N; i++) {
                    var curY = y[i];
                    var curDy = dY;
                    if (curY.percent) curDy = Math.round(1*dY*curY.percent);
                    if (curY.bottom) {
                        if (isVisible(curY.name)) {
							setCoordY(curY.name, getCoordY(curY.name) + curDy);
						}
                    } else {
                        if (isVisible(curY.name)) {
							setHeight(curY.name, (curY.height || getHeight(curY.name)) + curDy);
							if (curY.height) curY.height += curDy;
						}
                    }
                }
            }
        },
        
        // Метод для обновления размеров у тех элементов, для которых они сохранены
        update: function () {
            for (var i=0, N=x.length; i<N; i++) {
                var curX = x[i];
                if (curX.width) curX.width = getWidth(curX.name);
            }
            for (var i=0, N=y.length; i<N; i++) {
                var curY = y[i];
                if (curY.height) curY.height = getHeight(curY.name);
            }
        },
        
        // Объект с методами для ресайзинга по ширине
        x: {
            
            // Метод для добавления элемента, который будет растягиваться по ширине
            // fixWight - флаг, сохраняет ширину у элементов, которые при изменении ширины (setWidth())
            // меняют ее только визуально (вызовы getWidth() возвращают изначальную ширину).
            // Если флаг передан, используется сохраненная ширина
            stretch: function (name, percent, fixWidth) {
                var el = {name: name};
                addWidth(el, fixWidth);
                addPercent(el, percent);
                x.push(el);
                return this;
            },
            
            // Метод для добавления элемента, который при ресайзинге останется справа
            moveRight: function(name, percent) {
                var el = {name: name, right: true};
                addPercent(el, percent);
                x.push(el);
                return this;
            }
        },
        
        // Объект с методами для ресайзинга по высоте
        y: {
            
            // Метод для добавления элемента, который будет растягиваться по высоте
            // fixHeight - флаг, сохраняет высоту у элементов, которые при изменении высоты (setHeight())
            // меняют ее только визуально (вызовы getHeight() возвращают изначальную высоту).
            // Если флаг передан, используется сохраненная высота
            stretch: function (name, percent, fixHeight) {
                var el = {name: name};
                addHeight(el, fixHeight);
                addPercent(el, percent);
                y.push(el);
                return this;
            },
            
            // Метод для добавления элемента, который при ресайзинге останется снизу
            moveBottom: function(name, percent) {
                var el = {name: name, bottom: true};
                addPercent(el, percent);
                y.push(el);
                return this;
            }
        }
    }
}

/*
 * Выполняет func для каждой строки грида.
 * Внутри func доступны item - 'Form.grGrid.ItemN', i - номер строки, n - четность/нечетность (2/1)
 */
function forEachGridRow(gridId, func) {
   for (var i = 1; i<=getRowsCount(gridId); i++) {
       var n = Math.abs((i%2)-2); //Четность/нечетность (2/1)
       var item = gridId + '.Item' + i;
       func.call(null, item, i, n);
   }
}