package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InputParameterSysName Наименование входящего параметра
 * @param InputParameterName Имя параметра для пользователя
 * @param InputParameterType Тип параметра
 * @param InputParameterRequiredFlag Признак обязательности параметра
 * @param InputParameterDefaultValue Значение входящего параметра
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TInputParamterListTypeForDSFCReportFindInputParameterListByReportID",
	propOrder = {
		"inputParameterSysName",
		"inputParameterName",
		"inputParameterType",
		"inputParameterRequiredFlag",
		"inputParameterDefaultValue"
	}
)
public class TInputParamterListTypeForDSFCReportFindInputParameterListByReportID extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INPUT_PARAMETER_SYS_NAME = "InputParameterSysName";
	public static final String PROPERTY_INPUT_PARAMETER_NAME = "InputParameterName";
	public static final String PROPERTY_INPUT_PARAMETER_TYPE = "InputParameterType";
	public static final String PROPERTY_INPUT_PARAMETER_REQUIRED_FLAG = "InputParameterRequiredFlag";
	public static final String PROPERTY_INPUT_PARAMETER_DEFAULT_VALUE = "InputParameterDefaultValue";

	private static final MetaObject INFO = new MetaObject(
		TInputParamterListTypeForDSFCReportFindInputParameterListByReportID.class.getName(),
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETER_SYS_NAME, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETER_NAME, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETER_TYPE, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETER_REQUIRED_FLAG, Boolean.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETER_DEFAULT_VALUE, String.class, false, false, false) 
	);

    public TInputParamterListTypeForDSFCReportFindInputParameterListByReportID() {
		super(INFO);
	}

	/**
	 * @return Наименование входящего параметра
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETER_SYS_NAME, required = true)
	public String getInputParameterSysName() {
		return getProperty(PROPERTY_INPUT_PARAMETER_SYS_NAME);
	}

	/**
	 * @param value Наименование входящего параметра
	 */
	public void setInputParameterSysName(String value) {
		setProperty(PROPERTY_INPUT_PARAMETER_SYS_NAME, value);
	}
	/**
	 * @return Имя параметра для пользователя
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETER_NAME, required = true)
	public String getInputParameterName() {
		return getProperty(PROPERTY_INPUT_PARAMETER_NAME);
	}

	/**
	 * @param value Имя параметра для пользователя
	 */
	public void setInputParameterName(String value) {
		setProperty(PROPERTY_INPUT_PARAMETER_NAME, value);
	}
	/**
	 * @return Тип параметра
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETER_TYPE, required = true)
	public String getInputParameterType() {
		return getProperty(PROPERTY_INPUT_PARAMETER_TYPE);
	}

	/**
	 * @param value Тип параметра
	 */
	public void setInputParameterType(String value) {
		setProperty(PROPERTY_INPUT_PARAMETER_TYPE, value);
	}
	/**
	 * @return Признак обязательности параметра
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETER_REQUIRED_FLAG, required = false)
	public Boolean getInputParameterRequiredFlag() {
		return getProperty(PROPERTY_INPUT_PARAMETER_REQUIRED_FLAG);
	}

	/**
	 * @param value Признак обязательности параметра
	 */
	public void setInputParameterRequiredFlag(Boolean value) {
		setProperty(PROPERTY_INPUT_PARAMETER_REQUIRED_FLAG, value);
	}
	/**
	 * @return Значение входящего параметра
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETER_DEFAULT_VALUE, required = false)
	public String getInputParameterDefaultValue() {
		return getProperty(PROPERTY_INPUT_PARAMETER_DEFAULT_VALUE);
	}

	/**
	 * @param value Значение входящего параметра
	 */
	public void setInputParameterDefaultValue(String value) {
		setProperty(PROPERTY_INPUT_PARAMETER_DEFAULT_VALUE, value);
	}

}
