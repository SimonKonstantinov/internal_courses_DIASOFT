package ru.diasoft.flextera.services.ftfcreportws.type.response;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param MethodID Идентификатор метода
 * @param MethodName Имя метода
 * @param ServiceName Имя сервиса, в котором реализован метод
 * @param FCReportID Идентификатор отчета
 * @param TableList Список таблиц для хранения ответа метода
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportFindMethodByIDRes",
	propOrder = {
		"methodID",
		"methodName",
		"serviceName",
		"FCReportID",
		"tableList",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportFindMethodByIDRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_METHOD_ID = "MethodID";
	public static final String PROPERTY_METHOD_NAME = "MethodName";
	public static final String PROPERTY_SERVICE_NAME = "ServiceName";
	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_TABLE_LIST = "TableList";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportFindMethodByIDRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_METHOD_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_METHOD_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_SERVICE_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_TABLE_LIST, TTableListTypeForDSFCReportFindMethodByID.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportFindMethodByIDRes() {
		super(INFO);
	}

	/**
	 * @return Идентификатор метода
	 */
	@XmlElement(name = PROPERTY_METHOD_ID, required = true)
	public Long getMethodID() {
		return getProperty(PROPERTY_METHOD_ID);
	}

	/**
	 * @param value Идентификатор метода
	 */
	public void setMethodID(Long value) {
		setProperty(PROPERTY_METHOD_ID, value);
	}
	/**
	 * @return Имя метода
	 */
	@XmlElement(name = PROPERTY_METHOD_NAME, required = false)
	public String getMethodName() {
		return getProperty(PROPERTY_METHOD_NAME);
	}

	/**
	 * @param value Имя метода
	 */
	public void setMethodName(String value) {
		setProperty(PROPERTY_METHOD_NAME, value);
	}
	/**
	 * @return Имя сервиса, в котором реализован метод
	 */
	@XmlElement(name = PROPERTY_SERVICE_NAME, required = false)
	public String getServiceName() {
		return getProperty(PROPERTY_SERVICE_NAME);
	}

	/**
	 * @param value Имя сервиса, в котором реализован метод
	 */
	public void setServiceName(String value) {
		setProperty(PROPERTY_SERVICE_NAME, value);
	}
	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = false)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Список таблиц для хранения ответа метода
	 */
	@XmlElement(name = PROPERTY_TABLE_LIST, required = false)
	public List<TTableListTypeForDSFCReportFindMethodByID> getTableList() {
		return getProperty(PROPERTY_TABLE_LIST);
	}

	/**
	 * @param value Список таблиц для хранения ответа метода
	 */
	public void setTableList(List<TTableListTypeForDSFCReportFindMethodByID> value) {
		setProperty(PROPERTY_TABLE_LIST, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
