package ru.diasoft.flextera.services.ftfcreportws.type.request;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InputParamtrList Список параметров
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportMassInsertInputParametrReq",
	propOrder = {
		"inputParamtrList"
	}
)
public class DsFCReportMassInsertInputParametrReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INPUT_PARAMTR_LIST = "InputParamtrList";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportMassInsertInputParametrReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMTR_LIST, TInputParamtrListTypeForDSFCReportMassInsertInputParametr.class, true, true, false) 
	);

    public DsFCReportMassInsertInputParametrReq() {
		super(INFO);
	}

	/**
	 * @return Список параметров
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMTR_LIST, required = true)
	public List<TInputParamtrListTypeForDSFCReportMassInsertInputParametr> getInputParamtrList() {
		return getProperty(PROPERTY_INPUT_PARAMTR_LIST);
	}

	/**
	 * @param value Список параметров
	 */
	public void setInputParamtrList(List<TInputParamtrListTypeForDSFCReportMassInsertInputParametr> value) {
		setProperty(PROPERTY_INPUT_PARAMTR_LIST, value);
	}

}
