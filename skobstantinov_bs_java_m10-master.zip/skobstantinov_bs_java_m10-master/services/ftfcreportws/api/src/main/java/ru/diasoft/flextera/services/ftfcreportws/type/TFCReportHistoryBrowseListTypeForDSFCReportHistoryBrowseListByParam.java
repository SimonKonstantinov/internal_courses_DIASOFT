package ru.diasoft.flextera.services.ftfcreportws.type;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param StartDate Дата начала построения отчета
 * @param ProcessID Идентификатор процесса
 * @param UserLogin Логин пользователя, запустившего отчет
 * @param EndDate Дата окончания построения отчета
 * @param FCReportID Идентификатор отчета
 * @param ExecuteStatus Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
 * @param ReportFilePath Путь и наименование файла отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TFCReportHistoryBrowseListTypeForDSFCReportHistoryBrowseListByParam",
	propOrder = {
		"startDate",
		"processID",
		"userLogin",
		"endDate",
		"FCReportID",
		"executeStatus",
		"reportFilePath"
	}
)
public class TFCReportHistoryBrowseListTypeForDSFCReportHistoryBrowseListByParam extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_START_DATE = "StartDate";
	public static final String PROPERTY_PROCESS_ID = "ProcessID";
	public static final String PROPERTY_USER_LOGIN = "UserLogin";
	public static final String PROPERTY_END_DATE = "EndDate";
	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_EXECUTE_STATUS = "ExecuteStatus";
	public static final String PROPERTY_REPORT_FILE_PATH = "ReportFilePath";

	private static final MetaObject INFO = new MetaObject(
		TFCReportHistoryBrowseListTypeForDSFCReportHistoryBrowseListByParam.class.getName(),
		new MetaObjectAttribute(PROPERTY_START_DATE, Date.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PROCESS_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_USER_LOGIN, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_END_DATE, Date.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_EXECUTE_STATUS, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_REPORT_FILE_PATH, String.class, false, false, false) 
	);

    public TFCReportHistoryBrowseListTypeForDSFCReportHistoryBrowseListByParam() {
		super(INFO);
	}

	/**
	 * @return Дата начала построения отчета
	 */
	@XmlElement(name = PROPERTY_START_DATE, required = false)
	public Date getStartDate() {
		return getProperty(PROPERTY_START_DATE);
	}

	/**
	 * @param value Дата начала построения отчета
	 */
	public void setStartDate(Date value) {
		setProperty(PROPERTY_START_DATE, value);
	}
	/**
	 * @return Идентификатор процесса
	 */
	@XmlElement(name = PROPERTY_PROCESS_ID, required = false)
	public Long getProcessID() {
		return getProperty(PROPERTY_PROCESS_ID);
	}

	/**
	 * @param value Идентификатор процесса
	 */
	public void setProcessID(Long value) {
		setProperty(PROPERTY_PROCESS_ID, value);
	}
	/**
	 * @return Логин пользователя, запустившего отчет
	 */
	@XmlElement(name = PROPERTY_USER_LOGIN, required = false)
	public String getUserLogin() {
		return getProperty(PROPERTY_USER_LOGIN);
	}

	/**
	 * @param value Логин пользователя, запустившего отчет
	 */
	public void setUserLogin(String value) {
		setProperty(PROPERTY_USER_LOGIN, value);
	}
	/**
	 * @return Дата окончания построения отчета
	 */
	@XmlElement(name = PROPERTY_END_DATE, required = false)
	public Date getEndDate() {
		return getProperty(PROPERTY_END_DATE);
	}

	/**
	 * @param value Дата окончания построения отчета
	 */
	public void setEndDate(Date value) {
		setProperty(PROPERTY_END_DATE, value);
	}
	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = false)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	@XmlElement(name = PROPERTY_EXECUTE_STATUS, required = false)
	public Integer getExecuteStatus() {
		return getProperty(PROPERTY_EXECUTE_STATUS);
	}

	/**
	 * @param value Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	public void setExecuteStatus(Integer value) {
		setProperty(PROPERTY_EXECUTE_STATUS, value);
	}
	/**
	 * @return Путь и наименование файла отчета
	 */
	@XmlElement(name = PROPERTY_REPORT_FILE_PATH, required = false)
	public String getReportFilePath() {
		return getProperty(PROPERTY_REPORT_FILE_PATH);
	}

	/**
	 * @param value Путь и наименование файла отчета
	 */
	public void setReportFilePath(String value) {
		setProperty(PROPERTY_REPORT_FILE_PATH, value);
	}

}
