package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import ru.diasoft.flextera.services.ftfcreportws.type.*;
import ru.diasoft.flextera.services.ftfcreportws.type.request.*;
import ru.diasoft.flextera.services.ftfcreportws.type.response.*;


import static org.apache.commons.lang.StringUtils.join;
import static ru.diasoft.core.application.dto.TypeConverter.transformType;
import static ru.diasoft.core.application.dto.validation.Validators.*;
import static ru.diasoft.core.exception.RetCodes.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ru.diasoft.core.application.command.AbstractCommand;
import ru.diasoft.core.application.dto.AbstractTransferObject;
import ru.diasoft.core.application.dto.DataValidationException;
import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.MultipleMainListsException;
import ru.diasoft.core.application.dto.PropertyRequiredException;
import ru.diasoft.core.application.dto.meta.MetaObject;
import ru.diasoft.core.application.dto.meta.MetaObjectAttribute;
import ru.diasoft.core.application.dto.validation.NTFInserter;
import ru.diasoft.core.application.dto.validation.Validators;
import ru.diasoft.core.persistence.facet.FacetQueryStore;
import ru.diasoft.core.util.sandbox.Sandbox;

/**
 * Получение информации о входящих параметрах, необходимых для построения отчета
 * 
 * @param FCReportID Идентификатор отчета
 * 
 * @return InputParamterList Список входящих параметров
 * @return ParameterKeyList Список ключевых полей списочных параметров.
 * @return ReturnMsg Сообщение
 * @return ReturnCode Код
 */
public abstract class DsFCReportFindInputParameterListByReportIDStub
		extends AbstractCommand<DsFCReportFindInputParameterListByReportIDReq, DsFCReportFindInputParameterListByReportIDRes> implements NTFInserter {

	protected final FacetQueryStore queries = Sandbox.INSTANCE.singleProvider(FacetQueryStore.class);
	protected final Validators.LinkageValidator linkageValidator = new Validators.LinkageValidator(this);

	protected DsFCReportFindInputParameterListByReportIDStub() {
		super(DsFCReportFindInputParameterListByReportIDReq.class, DsFCReportFindInputParameterListByReportIDRes.class);
		setOutputData(new ru.diasoft.flextera.services.ftfcreportws.type.response.ObjectFactory().createDsFCReportFindInputParameterListByReportIDRes());
	    getOutputData().setInputParamterList(new ArrayList<TInputParamterListTypeForDSFCReportFindInputParameterListByReportID>());
	    getOutputData().setParameterKeyList(new ArrayList<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID>());
		setSupressDefaultValidation(true);
	}

	@Override
	protected void validateInput(MetaObject metaInfo, Map<String, Object> values) throws DataValidationException {
		// Checking required parameters
		List<String> missingParams = GROUP_VALIDATOR.validate(metaInfo, values);
		if(missingParams.size() > 0) {
			throw new PropertyRequiredException(join(missingParams, ", "));
		}
		
		// Checking for multiple main lists
		List<String> mainListNames = MAIN_LIST_VALIDATOR.validate(metaInfo, values);
		if(mainListNames.size() > 1) {
			throw new MultipleMainListsException(join(mainListNames, ", "));
		}
		
		// Checking required parameters of inner lists
		for (MetaObjectAttribute attr : metaInfo.getAttributes()) {
			Object value = values.get(attr.getSystemName());
			if(value instanceof List) {
				for(Object dto : (List<?>)value) {
					if(dto instanceof AbstractTransferObject) {
						missingParams = ((AbstractTransferObject)dto).validate(GROUP_VALIDATOR);
						if(missingParams.size() > 0) {
							Long linkID = null;
							if(dto instanceof Linkable) {
								linkID = ((Linkable)dto).getLinkID();
							}
							if(linkID == null || linkID < 0) {
								linkID = Long.valueOf(0);
							}
							insertNotification(linkID, PROPERTY_REQUIRED_EXCEPTION.getStatus(), PROPERTY_REQUIRED_EXCEPTION.getResourceBundleName(), join(missingParams, ", "), attr.getSystemName());
						}
					}
				}
			}
		}
		
		// Checking linkage between lists
		linkageValidator.validate(metaInfo, values);
	}

	@Override
	protected void validateOutput(MetaObject metaInfo, Map<String, Object> values) throws DataValidationException {
		// Checking required parameters
		List<String> missingParams = GROUP_VALIDATOR.validate(metaInfo, values);
		if(missingParams.size() > 0) {
			throw new PropertyRequiredException(join(missingParams, ", "));
		}
	}

	public void insertNotification(Long linkID, Long ntfID, String key, Object... args) {
	}


}
