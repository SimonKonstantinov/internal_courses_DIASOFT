package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param ProtocolMessageText Текст сообщения
 * @param ProtocolMessageType Тип сообщения. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
 * @param ProtocolMessageID Идентификатор сообщения протокола
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam",
	propOrder = {
		"protocolMessageText",
		"protocolMessageType",
		"protocolMessageID"
	}
)
public class TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_PROTOCOL_MESSAGE_TEXT = "ProtocolMessageText";
	public static final String PROPERTY_PROTOCOL_MESSAGE_TYPE = "ProtocolMessageType";
	public static final String PROPERTY_PROTOCOL_MESSAGE_ID = "ProtocolMessageID";

	private static final MetaObject INFO = new MetaObject(
		TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam.class.getName(),
		new MetaObjectAttribute(PROPERTY_PROTOCOL_MESSAGE_TEXT, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PROTOCOL_MESSAGE_TYPE, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PROTOCOL_MESSAGE_ID, Long.class, false, true, false) 
	);

    public TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam() {
		super(INFO);
	}

	/**
	 * @return Текст сообщения
	 */
	@XmlElement(name = PROPERTY_PROTOCOL_MESSAGE_TEXT, required = false)
	public String getProtocolMessageText() {
		return getProperty(PROPERTY_PROTOCOL_MESSAGE_TEXT);
	}

	/**
	 * @param value Текст сообщения
	 */
	public void setProtocolMessageText(String value) {
		setProperty(PROPERTY_PROTOCOL_MESSAGE_TEXT, value);
	}
	/**
	 * @return Тип сообщения. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
	 */
	@XmlElement(name = PROPERTY_PROTOCOL_MESSAGE_TYPE, required = false)
	public Integer getProtocolMessageType() {
		return getProperty(PROPERTY_PROTOCOL_MESSAGE_TYPE);
	}

	/**
	 * @param value Тип сообщения. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
	 */
	public void setProtocolMessageType(Integer value) {
		setProperty(PROPERTY_PROTOCOL_MESSAGE_TYPE, value);
	}
	/**
	 * @return Идентификатор сообщения протокола
	 */
	@XmlElement(name = PROPERTY_PROTOCOL_MESSAGE_ID, required = true)
	public Long getProtocolMessageID() {
		return getProperty(PROPERTY_PROTOCOL_MESSAGE_ID);
	}

	/**
	 * @param value Идентификатор сообщения протокола
	 */
	public void setProtocolMessageID(Long value) {
		setProperty(PROPERTY_PROTOCOL_MESSAGE_ID, value);
	}

}
