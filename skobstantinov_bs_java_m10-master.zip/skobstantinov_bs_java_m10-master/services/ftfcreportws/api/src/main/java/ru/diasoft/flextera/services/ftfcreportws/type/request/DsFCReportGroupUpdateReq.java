package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportGroupID Идентификатор группы пользовательских отчетов
 * @param FCReportGroupName Наименование группы пользовательских отчетов
 * @param FCReportGroupSysName Системное наименование группы пользовательских отчетов
 * @param FCReportGroupDescription Описание группы пользовательских отчетов
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportGroupUpdateReq",
	propOrder = {
		"FCReportGroupID",
		"FCReportGroupName",
		"FCReportGroupSysName",
		"FCReportGroupDescription"
	}
)
public class DsFCReportGroupUpdateReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_GROUP_ID = "FCReportGroupID";
	public static final String PROPERTY_FCREPORT_GROUP_NAME = "FCReportGroupName";
	public static final String PROPERTY_FCREPORT_GROUP_SYS_NAME = "FCReportGroupSysName";
	public static final String PROPERTY_FCREPORT_GROUP_DESCRIPTION = "FCReportGroupDescription";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportGroupUpdateReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_SYS_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_DESCRIPTION, String.class, false, false, false) 
	);

    public DsFCReportGroupUpdateReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор группы пользовательских отчетов
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_ID, required = true)
	public Long getFCReportGroupID() {
		return getProperty(PROPERTY_FCREPORT_GROUP_ID);
	}

	/**
	 * @param value Идентификатор группы пользовательских отчетов
	 */
	public void setFCReportGroupID(Long value) {
		setProperty(PROPERTY_FCREPORT_GROUP_ID, value);
	}
	/**
	 * @return Наименование группы пользовательских отчетов
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_NAME, required = false)
	public String getFCReportGroupName() {
		return getProperty(PROPERTY_FCREPORT_GROUP_NAME);
	}

	/**
	 * @param value Наименование группы пользовательских отчетов
	 */
	public void setFCReportGroupName(String value) {
		setProperty(PROPERTY_FCREPORT_GROUP_NAME, value);
	}
	/**
	 * @return Системное наименование группы пользовательских отчетов
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_SYS_NAME, required = false)
	public String getFCReportGroupSysName() {
		return getProperty(PROPERTY_FCREPORT_GROUP_SYS_NAME);
	}

	/**
	 * @param value Системное наименование группы пользовательских отчетов
	 */
	public void setFCReportGroupSysName(String value) {
		setProperty(PROPERTY_FCREPORT_GROUP_SYS_NAME, value);
	}
	/**
	 * @return Описание группы пользовательских отчетов
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_DESCRIPTION, required = false)
	public String getFCReportGroupDescription() {
		return getProperty(PROPERTY_FCREPORT_GROUP_DESCRIPTION);
	}

	/**
	 * @param value Описание группы пользовательских отчетов
	 */
	public void setFCReportGroupDescription(String value) {
		setProperty(PROPERTY_FCREPORT_GROUP_DESCRIPTION, value);
	}

}
