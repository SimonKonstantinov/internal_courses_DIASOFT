package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param ProcessID Идентификатор запущенного процесса
 * @param ExecuteStatus Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
 * @param ExecuteStatusText Комментарий к статусу формирования отчета
 * @param IsAsync Флаг для асинхронных событий
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsOnAfterFCReportExecuteBuildingReq",
	propOrder = {
		"processID",
		"executeStatus",
		"executeStatusText",
		"isAsync"
	}
)
public class DsOnAfterFCReportExecuteBuildingReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_PROCESS_ID = "ProcessID";
	public static final String PROPERTY_EXECUTE_STATUS = "ExecuteStatus";
	public static final String PROPERTY_EXECUTE_STATUS_TEXT = "ExecuteStatusText";
	public static final String PROPERTY_IS_ASYNC = "IsAsync";

	private static final MetaObject INFO = new MetaObject(
		DsOnAfterFCReportExecuteBuildingReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_PROCESS_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_EXECUTE_STATUS, Integer.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_EXECUTE_STATUS_TEXT, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_IS_ASYNC, Boolean.class, false, false, false) 
	);

    public DsOnAfterFCReportExecuteBuildingReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор запущенного процесса
	 */
	@XmlElement(name = PROPERTY_PROCESS_ID, required = true)
	public Long getProcessID() {
		return getProperty(PROPERTY_PROCESS_ID);
	}

	/**
	 * @param value Идентификатор запущенного процесса
	 */
	public void setProcessID(Long value) {
		setProperty(PROPERTY_PROCESS_ID, value);
	}
	/**
	 * @return Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	@XmlElement(name = PROPERTY_EXECUTE_STATUS, required = true)
	public Integer getExecuteStatus() {
		return getProperty(PROPERTY_EXECUTE_STATUS);
	}

	/**
	 * @param value Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	public void setExecuteStatus(Integer value) {
		setProperty(PROPERTY_EXECUTE_STATUS, value);
	}
	/**
	 * @return Комментарий к статусу формирования отчета
	 */
	@XmlElement(name = PROPERTY_EXECUTE_STATUS_TEXT, required = false)
	public String getExecuteStatusText() {
		return getProperty(PROPERTY_EXECUTE_STATUS_TEXT);
	}

	/**
	 * @param value Комментарий к статусу формирования отчета
	 */
	public void setExecuteStatusText(String value) {
		setProperty(PROPERTY_EXECUTE_STATUS_TEXT, value);
	}
	/**
	 * @return Флаг для асинхронных событий
	 */
	@XmlElement(name = PROPERTY_IS_ASYNC, required = false)
	public Boolean getIsAsync() {
		return getProperty(PROPERTY_IS_ASYNC);
	}

	/**
	 * @param value Флаг для асинхронных событий
	 */
	public void setIsAsync(Boolean value) {
		setProperty(PROPERTY_IS_ASYNC, value);
	}

}
