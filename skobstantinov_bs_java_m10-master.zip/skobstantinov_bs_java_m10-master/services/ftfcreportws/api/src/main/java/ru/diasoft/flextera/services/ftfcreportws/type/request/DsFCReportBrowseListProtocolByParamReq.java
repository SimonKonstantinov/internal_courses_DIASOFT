package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param ProcessID Идентификатор запущенного процесса
 * @param LastProtocolMessageID Идентификатор последнего полученного сообщения
 * @param ProtocolMessageType Тип сообщения протокола. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
 * @param ORDERBY Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
 * @param PAGE Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
 * @param ROWSCOUNT Число записей на страницу для постраничной разбивки. По умолчанию 10
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportBrowseListProtocolByParamReq",
	propOrder = {
		"processID",
		"lastProtocolMessageID",
		"protocolMessageType",
		"ORDERBY",
		"PAGE",
		"ROWSCOUNT"
	}
)
public class DsFCReportBrowseListProtocolByParamReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_PROCESS_ID = "ProcessID";
	public static final String PROPERTY_LAST_PROTOCOL_MESSAGE_ID = "LastProtocolMessageID";
	public static final String PROPERTY_PROTOCOL_MESSAGE_TYPE = "ProtocolMessageType";
	public static final String PROPERTY_ORDERBY = "ORDERBY";
	public static final String PROPERTY_PAGE = "PAGE";
	public static final String PROPERTY_ROWSCOUNT = "ROWSCOUNT";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportBrowseListProtocolByParamReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_PROCESS_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_LAST_PROTOCOL_MESSAGE_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PROTOCOL_MESSAGE_TYPE, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_ORDERBY, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PAGE, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_ROWSCOUNT, Integer.class, false, false, false) 
	);

    public DsFCReportBrowseListProtocolByParamReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор запущенного процесса
	 */
	@XmlElement(name = PROPERTY_PROCESS_ID, required = true)
	public Long getProcessID() {
		return getProperty(PROPERTY_PROCESS_ID);
	}

	/**
	 * @param value Идентификатор запущенного процесса
	 */
	public void setProcessID(Long value) {
		setProperty(PROPERTY_PROCESS_ID, value);
	}
	/**
	 * @return Идентификатор последнего полученного сообщения
	 */
	@XmlElement(name = PROPERTY_LAST_PROTOCOL_MESSAGE_ID, required = false)
	public Long getLastProtocolMessageID() {
		return getProperty(PROPERTY_LAST_PROTOCOL_MESSAGE_ID);
	}

	/**
	 * @param value Идентификатор последнего полученного сообщения
	 */
	public void setLastProtocolMessageID(Long value) {
		setProperty(PROPERTY_LAST_PROTOCOL_MESSAGE_ID, value);
	}
	/**
	 * @return Тип сообщения протокола. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
	 */
	@XmlElement(name = PROPERTY_PROTOCOL_MESSAGE_TYPE, required = false)
	public Integer getProtocolMessageType() {
		return getProperty(PROPERTY_PROTOCOL_MESSAGE_TYPE);
	}

	/**
	 * @param value Тип сообщения протокола. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
	 */
	public void setProtocolMessageType(Integer value) {
		setProperty(PROPERTY_PROTOCOL_MESSAGE_TYPE, value);
	}
	/**
	 * @return Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 */
	@XmlElement(name = PROPERTY_ORDERBY, required = false)
	public String getORDERBY() {
		return getProperty(PROPERTY_ORDERBY);
	}

	/**
	 * @param value Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 */
	public void setORDERBY(String value) {
		setProperty(PROPERTY_ORDERBY, value);
	}
	/**
	 * @return Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 */
	@XmlElement(name = PROPERTY_PAGE, required = false)
	public Integer getPAGE() {
		return getProperty(PROPERTY_PAGE);
	}

	/**
	 * @param value Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 */
	public void setPAGE(Integer value) {
		setProperty(PROPERTY_PAGE, value);
	}
	/**
	 * @return Число записей на страницу для постраничной разбивки. По умолчанию 10
	 */
	@XmlElement(name = PROPERTY_ROWSCOUNT, required = false)
	public Integer getROWSCOUNT() {
		return getProperty(PROPERTY_ROWSCOUNT);
	}

	/**
	 * @param value Число записей на страницу для постраничной разбивки. По умолчанию 10
	 */
	public void setROWSCOUNT(Integer value) {
		setProperty(PROPERTY_ROWSCOUNT, value);
	}

}
