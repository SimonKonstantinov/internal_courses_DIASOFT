package ru.diasoft.flextera.services.ftfcreportws.type.request;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportID Идентификатор отчета
 * @param FCReportName Наименование отчета
 * @param FCReportSysName Системное наименование отчета
 * @param UserLogin Логин пользователя
 * @param StartDate Дата запуска отчета
 * @param ExecuteStatus Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
 * @param ProcessID Идентификатор запущенного процесса
 * @param ORDERBY Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
 * @param PAGE Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
 * @param ROWSCOUNT Число записей на страницу для постраничной разбивки. По умолчанию 10
 * @param FCReportGroupID Идентификатор группы отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportBrowseListInstanceByParamReq",
	propOrder = {
		"FCReportID",
		"FCReportName",
		"FCReportSysName",
		"userLogin",
		"startDate",
		"executeStatus",
		"processID",
		"ORDERBY",
		"PAGE",
		"ROWSCOUNT",
		"FCReportGroupID"
	}
)
public class DsFCReportBrowseListInstanceByParamReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_FCREPORT_NAME = "FCReportName";
	public static final String PROPERTY_FCREPORT_SYS_NAME = "FCReportSysName";
	public static final String PROPERTY_USER_LOGIN = "UserLogin";
	public static final String PROPERTY_START_DATE = "StartDate";
	public static final String PROPERTY_EXECUTE_STATUS = "ExecuteStatus";
	public static final String PROPERTY_PROCESS_ID = "ProcessID";
	public static final String PROPERTY_ORDERBY = "ORDERBY";
	public static final String PROPERTY_PAGE = "PAGE";
	public static final String PROPERTY_ROWSCOUNT = "ROWSCOUNT";
	public static final String PROPERTY_FCREPORT_GROUP_ID = "FCReportGroupID";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportBrowseListInstanceByParamReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_SYS_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_USER_LOGIN, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_START_DATE, Date.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_EXECUTE_STATUS, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PROCESS_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_ORDERBY, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PAGE, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_ROWSCOUNT, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_ID, Long.class, false, false, false) 
	);

    public DsFCReportBrowseListInstanceByParamReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = false)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_NAME, required = false)
	public String getFCReportName() {
		return getProperty(PROPERTY_FCREPORT_NAME);
	}

	/**
	 * @param value Наименование отчета
	 */
	public void setFCReportName(String value) {
		setProperty(PROPERTY_FCREPORT_NAME, value);
	}
	/**
	 * @return Системное наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_SYS_NAME, required = false)
	public String getFCReportSysName() {
		return getProperty(PROPERTY_FCREPORT_SYS_NAME);
	}

	/**
	 * @param value Системное наименование отчета
	 */
	public void setFCReportSysName(String value) {
		setProperty(PROPERTY_FCREPORT_SYS_NAME, value);
	}
	/**
	 * @return Логин пользователя
	 */
	@XmlElement(name = PROPERTY_USER_LOGIN, required = false)
	public String getUserLogin() {
		return getProperty(PROPERTY_USER_LOGIN);
	}

	/**
	 * @param value Логин пользователя
	 */
	public void setUserLogin(String value) {
		setProperty(PROPERTY_USER_LOGIN, value);
	}
	/**
	 * @return Дата запуска отчета
	 */
	@XmlElement(name = PROPERTY_START_DATE, required = false)
	public Date getStartDate() {
		return getProperty(PROPERTY_START_DATE);
	}

	/**
	 * @param value Дата запуска отчета
	 */
	public void setStartDate(Date value) {
		setProperty(PROPERTY_START_DATE, value);
	}
	/**
	 * @return Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	@XmlElement(name = PROPERTY_EXECUTE_STATUS, required = false)
	public Integer getExecuteStatus() {
		return getProperty(PROPERTY_EXECUTE_STATUS);
	}

	/**
	 * @param value Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	public void setExecuteStatus(Integer value) {
		setProperty(PROPERTY_EXECUTE_STATUS, value);
	}
	/**
	 * @return Идентификатор запущенного процесса
	 */
	@XmlElement(name = PROPERTY_PROCESS_ID, required = false)
	public Long getProcessID() {
		return getProperty(PROPERTY_PROCESS_ID);
	}

	/**
	 * @param value Идентификатор запущенного процесса
	 */
	public void setProcessID(Long value) {
		setProperty(PROPERTY_PROCESS_ID, value);
	}
	/**
	 * @return Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 */
	@XmlElement(name = PROPERTY_ORDERBY, required = false)
	public String getORDERBY() {
		return getProperty(PROPERTY_ORDERBY);
	}

	/**
	 * @param value Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 */
	public void setORDERBY(String value) {
		setProperty(PROPERTY_ORDERBY, value);
	}
	/**
	 * @return Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 */
	@XmlElement(name = PROPERTY_PAGE, required = false)
	public Integer getPAGE() {
		return getProperty(PROPERTY_PAGE);
	}

	/**
	 * @param value Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 */
	public void setPAGE(Integer value) {
		setProperty(PROPERTY_PAGE, value);
	}
	/**
	 * @return Число записей на страницу для постраничной разбивки. По умолчанию 10
	 */
	@XmlElement(name = PROPERTY_ROWSCOUNT, required = false)
	public Integer getROWSCOUNT() {
		return getProperty(PROPERTY_ROWSCOUNT);
	}

	/**
	 * @param value Число записей на страницу для постраничной разбивки. По умолчанию 10
	 */
	public void setROWSCOUNT(Integer value) {
		setProperty(PROPERTY_ROWSCOUNT, value);
	}
	/**
	 * @return Идентификатор группы отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_ID, required = false)
	public Long getFCReportGroupID() {
		return getProperty(PROPERTY_FCREPORT_GROUP_ID);
	}

	/**
	 * @param value Идентификатор группы отчета
	 */
	public void setFCReportGroupID(Long value) {
		setProperty(PROPERTY_FCREPORT_GROUP_ID, value);
	}

}
