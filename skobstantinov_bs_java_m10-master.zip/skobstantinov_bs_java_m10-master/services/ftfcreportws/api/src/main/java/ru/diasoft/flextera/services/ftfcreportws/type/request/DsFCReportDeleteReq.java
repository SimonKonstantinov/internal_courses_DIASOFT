package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportID Идентификатор отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportDeleteReq",
	propOrder = {
		"FCReportID"
	}
)
public class DsFCReportDeleteReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_ID = "FCReportID";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportDeleteReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, true, false) 
	);

    public DsFCReportDeleteReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = true)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}

}
