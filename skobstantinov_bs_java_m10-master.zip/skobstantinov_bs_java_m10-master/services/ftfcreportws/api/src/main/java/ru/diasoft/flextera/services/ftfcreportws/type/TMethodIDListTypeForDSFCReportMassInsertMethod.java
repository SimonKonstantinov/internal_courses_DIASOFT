package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param LinkID Идентификатор для связи
 * @param MethodID Идентификатор метода
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TMethodIDListTypeForDSFCReportMassInsertMethod",
	propOrder = {
		"linkID",
		"methodID"
	}
)
public class TMethodIDListTypeForDSFCReportMassInsertMethod extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_LINK_ID = "LinkID";
	public static final String PROPERTY_METHOD_ID = "MethodID";

	private static final MetaObject INFO = new MetaObject(
		TMethodIDListTypeForDSFCReportMassInsertMethod.class.getName(),
		new MetaObjectAttribute(PROPERTY_LINK_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_METHOD_ID, Long.class, false, true, false) 
	);

    public TMethodIDListTypeForDSFCReportMassInsertMethod() {
		super(INFO);
	}

	/**
	 * @return Идентификатор для связи
	 */
	@XmlElement(name = PROPERTY_LINK_ID, required = true)
	public Long getLinkID() {
		return getProperty(PROPERTY_LINK_ID);
	}

	/**
	 * @param value Идентификатор для связи
	 */
	public void setLinkID(Long value) {
		setProperty(PROPERTY_LINK_ID, value);
	}
	/**
	 * @return Идентификатор метода
	 */
	@XmlElement(name = PROPERTY_METHOD_ID, required = true)
	public Long getMethodID() {
		return getProperty(PROPERTY_METHOD_ID);
	}

	/**
	 * @param value Идентификатор метода
	 */
	public void setMethodID(Long value) {
		setProperty(PROPERTY_METHOD_ID, value);
	}

}
