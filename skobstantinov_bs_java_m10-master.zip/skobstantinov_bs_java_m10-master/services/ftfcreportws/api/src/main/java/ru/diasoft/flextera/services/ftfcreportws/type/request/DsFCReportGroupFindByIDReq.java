package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportGroupID Идентификатор группы пользовательских отчетов
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportGroupFindByIDReq",
	propOrder = {
		"FCReportGroupID"
	}
)
public class DsFCReportGroupFindByIDReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_GROUP_ID = "FCReportGroupID";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportGroupFindByIDReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_ID, Long.class, false, true, false) 
	);

    public DsFCReportGroupFindByIDReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор группы пользовательских отчетов
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_ID, required = true)
	public Long getFCReportGroupID() {
		return getProperty(PROPERTY_FCREPORT_GROUP_ID);
	}

	/**
	 * @param value Идентификатор группы пользовательских отчетов
	 */
	public void setFCReportGroupID(Long value) {
		setProperty(PROPERTY_FCREPORT_GROUP_ID, value);
	}

}
