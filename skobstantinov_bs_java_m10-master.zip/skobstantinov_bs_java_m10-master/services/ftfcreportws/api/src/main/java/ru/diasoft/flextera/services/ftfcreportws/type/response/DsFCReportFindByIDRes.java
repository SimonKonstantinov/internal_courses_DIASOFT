package ru.diasoft.flextera.services.ftfcreportws.type.response;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportID Идентификатор отчета
 * @param FCReportName Наименование отчета
 * @param FCReportSysName Системное наименование отчета
 * @param DeleteDataFlag Флаг удаления данных, загруженных для экземпляра отчета
 * @param FileFormat Формат файла, в котором будет сохранен отчет. Возможные значения:<br>
	 *	1 - xls;<br>
	 *	2 - pdf;<br>
	 *	3 - rtf.
 * @param UserLogin Логин пользователя, создавшего отчет
 * @param TemplatePathName Путь и наименование файла шаблона отчета
 * @param ConfigPathName Путь и наименование конфигурационного файла
 * @param FCReportGroupID Идентификатор группы отчета
 * @param FCReportGroupName Наименование группы отчета
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportFindByIDRes",
	propOrder = {
		"FCReportID",
		"FCReportName",
		"FCReportSysName",
		"deleteDataFlag",
		"fileFormat",
		"userLogin",
		"templatePathName",
		"configPathName",
		"FCReportGroupID",
		"FCReportGroupName",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportFindByIDRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_FCREPORT_NAME = "FCReportName";
	public static final String PROPERTY_FCREPORT_SYS_NAME = "FCReportSysName";
	public static final String PROPERTY_DELETE_DATA_FLAG = "DeleteDataFlag";
	public static final String PROPERTY_FILE_FORMAT = "FileFormat";
	public static final String PROPERTY_USER_LOGIN = "UserLogin";
	public static final String PROPERTY_TEMPLATE_PATH_NAME = "TemplatePathName";
	public static final String PROPERTY_CONFIG_PATH_NAME = "ConfigPathName";
	public static final String PROPERTY_FCREPORT_GROUP_ID = "FCReportGroupID";
	public static final String PROPERTY_FCREPORT_GROUP_NAME = "FCReportGroupName";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportFindByIDRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_SYS_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_DELETE_DATA_FLAG, Boolean.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FILE_FORMAT, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_USER_LOGIN, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_TEMPLATE_PATH_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_CONFIG_PATH_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportFindByIDRes() {
		super(INFO);
	}

	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = false)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_NAME, required = false)
	public String getFCReportName() {
		return getProperty(PROPERTY_FCREPORT_NAME);
	}

	/**
	 * @param value Наименование отчета
	 */
	public void setFCReportName(String value) {
		setProperty(PROPERTY_FCREPORT_NAME, value);
	}
	/**
	 * @return Системное наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_SYS_NAME, required = false)
	public String getFCReportSysName() {
		return getProperty(PROPERTY_FCREPORT_SYS_NAME);
	}

	/**
	 * @param value Системное наименование отчета
	 */
	public void setFCReportSysName(String value) {
		setProperty(PROPERTY_FCREPORT_SYS_NAME, value);
	}
	/**
	 * @return Флаг удаления данных, загруженных для экземпляра отчета
	 */
	@XmlElement(name = PROPERTY_DELETE_DATA_FLAG, required = false)
	public Boolean getDeleteDataFlag() {
		return getProperty(PROPERTY_DELETE_DATA_FLAG);
	}

	/**
	 * @param value Флаг удаления данных, загруженных для экземпляра отчета
	 */
	public void setDeleteDataFlag(Boolean value) {
		setProperty(PROPERTY_DELETE_DATA_FLAG, value);
	}
	/**
	 * @return Формат файла, в котором будет сохранен отчет. Возможные значения:<br>
	 *	1 - xls;<br>
	 *	2 - pdf;<br>
	 *	3 - rtf.
	 */
	@XmlElement(name = PROPERTY_FILE_FORMAT, required = false)
	public Integer getFileFormat() {
		return getProperty(PROPERTY_FILE_FORMAT);
	}

	/**
	 * @param value Формат файла, в котором будет сохранен отчет. Возможные значения:<br>
	 *	1 - xls;<br>
	 *	2 - pdf;<br>
	 *	3 - rtf.
	 */
	public void setFileFormat(Integer value) {
		setProperty(PROPERTY_FILE_FORMAT, value);
	}
	/**
	 * @return Логин пользователя, создавшего отчет
	 */
	@XmlElement(name = PROPERTY_USER_LOGIN, required = false)
	public String getUserLogin() {
		return getProperty(PROPERTY_USER_LOGIN);
	}

	/**
	 * @param value Логин пользователя, создавшего отчет
	 */
	public void setUserLogin(String value) {
		setProperty(PROPERTY_USER_LOGIN, value);
	}
	/**
	 * @return Путь и наименование файла шаблона отчета
	 */
	@XmlElement(name = PROPERTY_TEMPLATE_PATH_NAME, required = false)
	public String getTemplatePathName() {
		return getProperty(PROPERTY_TEMPLATE_PATH_NAME);
	}

	/**
	 * @param value Путь и наименование файла шаблона отчета
	 */
	public void setTemplatePathName(String value) {
		setProperty(PROPERTY_TEMPLATE_PATH_NAME, value);
	}
	/**
	 * @return Путь и наименование конфигурационного файла
	 */
	@XmlElement(name = PROPERTY_CONFIG_PATH_NAME, required = false)
	public String getConfigPathName() {
		return getProperty(PROPERTY_CONFIG_PATH_NAME);
	}

	/**
	 * @param value Путь и наименование конфигурационного файла
	 */
	public void setConfigPathName(String value) {
		setProperty(PROPERTY_CONFIG_PATH_NAME, value);
	}
	/**
	 * @return Идентификатор группы отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_ID, required = false)
	public Long getFCReportGroupID() {
		return getProperty(PROPERTY_FCREPORT_GROUP_ID);
	}

	/**
	 * @param value Идентификатор группы отчета
	 */
	public void setFCReportGroupID(Long value) {
		setProperty(PROPERTY_FCREPORT_GROUP_ID, value);
	}
	/**
	 * @return Наименование группы отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_NAME, required = false)
	public String getFCReportGroupName() {
		return getProperty(PROPERTY_FCREPORT_GROUP_NAME);
	}

	/**
	 * @param value Наименование группы отчета
	 */
	public void setFCReportGroupName(String value) {
		setProperty(PROPERTY_FCREPORT_GROUP_NAME, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
