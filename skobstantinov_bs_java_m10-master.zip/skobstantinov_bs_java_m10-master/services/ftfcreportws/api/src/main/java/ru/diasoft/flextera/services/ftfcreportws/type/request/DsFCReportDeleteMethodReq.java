package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param MethodID Идентификатор метода
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportDeleteMethodReq",
	propOrder = {
		"methodID"
	}
)
public class DsFCReportDeleteMethodReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_METHOD_ID = "MethodID";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportDeleteMethodReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_METHOD_ID, Long.class, false, true, false) 
	);

    public DsFCReportDeleteMethodReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор метода
	 */
	@XmlElement(name = PROPERTY_METHOD_ID, required = true)
	public Long getMethodID() {
		return getProperty(PROPERTY_METHOD_ID);
	}

	/**
	 * @param value Идентификатор метода
	 */
	public void setMethodID(Long value) {
		setProperty(PROPERTY_METHOD_ID, value);
	}

}
