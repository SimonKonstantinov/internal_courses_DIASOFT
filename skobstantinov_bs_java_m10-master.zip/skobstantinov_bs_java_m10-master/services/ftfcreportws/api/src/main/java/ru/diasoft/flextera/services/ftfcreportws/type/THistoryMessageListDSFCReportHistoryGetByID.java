package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param HistoryMessageText Текст сообщения записи истории запуска отчета
 * @param HistoryMessageType Тип сообщения. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
 * @param HistoryMessageID Идентификатор сообщения истории запуска отчета
 * @param ReportHistoryID Идентификатор записи истории запуска отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "THistoryMessageListDSFCReportHistoryGetByID",
	propOrder = {
		"historyMessageText",
		"historyMessageType",
		"historyMessageID",
		"reportHistoryID"
	}
)
public class THistoryMessageListDSFCReportHistoryGetByID extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_HISTORY_MESSAGE_TEXT = "HistoryMessageText";
	public static final String PROPERTY_HISTORY_MESSAGE_TYPE = "HistoryMessageType";
	public static final String PROPERTY_HISTORY_MESSAGE_ID = "HistoryMessageID";
	public static final String PROPERTY_REPORT_HISTORY_ID = "ReportHistoryID";

	private static final MetaObject INFO = new MetaObject(
		THistoryMessageListDSFCReportHistoryGetByID.class.getName(),
		new MetaObjectAttribute(PROPERTY_HISTORY_MESSAGE_TEXT, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_HISTORY_MESSAGE_TYPE, Integer.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_HISTORY_MESSAGE_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_REPORT_HISTORY_ID, Long.class, false, true, false) 
	);

    public THistoryMessageListDSFCReportHistoryGetByID() {
		super(INFO);
	}

	/**
	 * @return Текст сообщения записи истории запуска отчета
	 */
	@XmlElement(name = PROPERTY_HISTORY_MESSAGE_TEXT, required = false)
	public String getHistoryMessageText() {
		return getProperty(PROPERTY_HISTORY_MESSAGE_TEXT);
	}

	/**
	 * @param value Текст сообщения записи истории запуска отчета
	 */
	public void setHistoryMessageText(String value) {
		setProperty(PROPERTY_HISTORY_MESSAGE_TEXT, value);
	}
	/**
	 * @return Тип сообщения. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
	 */
	@XmlElement(name = PROPERTY_HISTORY_MESSAGE_TYPE, required = true)
	public Integer getHistoryMessageType() {
		return getProperty(PROPERTY_HISTORY_MESSAGE_TYPE);
	}

	/**
	 * @param value Тип сообщения. Возможные значения:<br>
	 *	1 - информационное;<br>
	 *	2 - ошибка.
	 */
	public void setHistoryMessageType(Integer value) {
		setProperty(PROPERTY_HISTORY_MESSAGE_TYPE, value);
	}
	/**
	 * @return Идентификатор сообщения истории запуска отчета
	 */
	@XmlElement(name = PROPERTY_HISTORY_MESSAGE_ID, required = true)
	public Long getHistoryMessageID() {
		return getProperty(PROPERTY_HISTORY_MESSAGE_ID);
	}

	/**
	 * @param value Идентификатор сообщения истории запуска отчета
	 */
	public void setHistoryMessageID(Long value) {
		setProperty(PROPERTY_HISTORY_MESSAGE_ID, value);
	}
	/**
	 * @return Идентификатор записи истории запуска отчета
	 */
	@XmlElement(name = PROPERTY_REPORT_HISTORY_ID, required = true)
	public Long getReportHistoryID() {
		return getProperty(PROPERTY_REPORT_HISTORY_ID);
	}

	/**
	 * @param value Идентификатор записи истории запуска отчета
	 */
	public void setReportHistoryID(Long value) {
		setProperty(PROPERTY_REPORT_HISTORY_ID, value);
	}

}
