package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param LinkID Идентификатор для связи
 * @param FCReportID Идентификатор отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TFCReportIDListTypeForDSFCReportMassInsert",
	propOrder = {
		"linkID",
		"FCReportID"
	}
)
public class TFCReportIDListTypeForDSFCReportMassInsert extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_LINK_ID = "LinkID";
	public static final String PROPERTY_FCREPORT_ID = "FCReportID";

	private static final MetaObject INFO = new MetaObject(
		TFCReportIDListTypeForDSFCReportMassInsert.class.getName(),
		new MetaObjectAttribute(PROPERTY_LINK_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, true, false) 
	);

    public TFCReportIDListTypeForDSFCReportMassInsert() {
		super(INFO);
	}

	/**
	 * @return Идентификатор для связи
	 */
	@XmlElement(name = PROPERTY_LINK_ID, required = true)
	public Long getLinkID() {
		return getProperty(PROPERTY_LINK_ID);
	}

	/**
	 * @param value Идентификатор для связи
	 */
	public void setLinkID(Long value) {
		setProperty(PROPERTY_LINK_ID, value);
	}
	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = true)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}

}
