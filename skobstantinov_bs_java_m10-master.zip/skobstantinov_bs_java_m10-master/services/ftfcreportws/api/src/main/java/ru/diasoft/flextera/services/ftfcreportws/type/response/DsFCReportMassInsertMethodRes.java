package ru.diasoft.flextera.services.ftfcreportws.type.response;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param MethodIDList Список идентификаторов методов
 * @param NotificationList Список ошибок
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportMassInsertMethodRes",
	propOrder = {
		"methodIDList",
		"notificationList",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportMassInsertMethodRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_METHOD_IDLIST = "MethodIDList";
	public static final String PROPERTY_NOTIFICATION_LIST = "NotificationList";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportMassInsertMethodRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_METHOD_IDLIST, TMethodIDListTypeForDSFCReportMassInsertMethod.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_NOTIFICATION_LIST, TNotificationListTypeForDSFCReportMassInsertMethod.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportMassInsertMethodRes() {
		super(INFO);
	}

	/**
	 * @return Список идентификаторов методов
	 */
	@XmlElement(name = PROPERTY_METHOD_IDLIST, required = false)
	public List<TMethodIDListTypeForDSFCReportMassInsertMethod> getMethodIDList() {
		return getProperty(PROPERTY_METHOD_IDLIST);
	}

	/**
	 * @param value Список идентификаторов методов
	 */
	public void setMethodIDList(List<TMethodIDListTypeForDSFCReportMassInsertMethod> value) {
		setProperty(PROPERTY_METHOD_IDLIST, value);
	}
	/**
	 * @return Список ошибок
	 */
	@XmlElement(name = PROPERTY_NOTIFICATION_LIST, required = false)
	public List<TNotificationListTypeForDSFCReportMassInsertMethod> getNotificationList() {
		return getProperty(PROPERTY_NOTIFICATION_LIST);
	}

	/**
	 * @param value Список ошибок
	 */
	public void setNotificationList(List<TNotificationListTypeForDSFCReportMassInsertMethod> value) {
		setProperty(PROPERTY_NOTIFICATION_LIST, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
