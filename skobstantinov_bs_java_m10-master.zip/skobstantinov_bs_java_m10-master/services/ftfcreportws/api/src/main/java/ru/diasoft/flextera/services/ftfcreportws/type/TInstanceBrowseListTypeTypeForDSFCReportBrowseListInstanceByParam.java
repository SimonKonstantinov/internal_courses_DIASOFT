package ru.diasoft.flextera.services.ftfcreportws.type;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InstanceID Идентификатор экземпляра запуска отчета
 * @param ProcessID Идентификатор запущенного процесса
 * @param FCReportID Идентификатор отчета
 * @param FCReportName Наименование отчета
 * @param FCReportSysName Системное наименование отчета
 * @param UserLogin Логин пользователя
 * @param StartDate Дата запуска отчета
 * @param ExecuteStatus Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
 * @param FCReportFileName Наименование сформированного файла отчета
 * @param EndDate Дата окончания формирования отчета
 * @param FCReportGroupID Идентификатор группы отчета
 * @param FCReportGroupName Наименование группы отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam",
	propOrder = {
		"instanceID",
		"processID",
		"FCReportID",
		"FCReportName",
		"FCReportSysName",
		"userLogin",
		"startDate",
		"executeStatus",
		"FCReportFileName",
		"endDate",
		"FCReportGroupID",
		"FCReportGroupName"
	}
)
public class TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INSTANCE_ID = "InstanceID";
	public static final String PROPERTY_PROCESS_ID = "ProcessID";
	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_FCREPORT_NAME = "FCReportName";
	public static final String PROPERTY_FCREPORT_SYS_NAME = "FCReportSysName";
	public static final String PROPERTY_USER_LOGIN = "UserLogin";
	public static final String PROPERTY_START_DATE = "StartDate";
	public static final String PROPERTY_EXECUTE_STATUS = "ExecuteStatus";
	public static final String PROPERTY_FCREPORT_FILE_NAME = "FCReportFileName";
	public static final String PROPERTY_END_DATE = "EndDate";
	public static final String PROPERTY_FCREPORT_GROUP_ID = "FCReportGroupID";
	public static final String PROPERTY_FCREPORT_GROUP_NAME = "FCReportGroupName";

	private static final MetaObject INFO = new MetaObject(
		TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam.class.getName(),
		new MetaObjectAttribute(PROPERTY_INSTANCE_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_PROCESS_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_SYS_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_USER_LOGIN, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_START_DATE, Date.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_EXECUTE_STATUS, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_FILE_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_END_DATE, Date.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_NAME, String.class, false, false, false) 
	);

    public TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam() {
		super(INFO);
	}

	/**
	 * @return Идентификатор экземпляра запуска отчета
	 */
	@XmlElement(name = PROPERTY_INSTANCE_ID, required = true)
	public Long getInstanceID() {
		return getProperty(PROPERTY_INSTANCE_ID);
	}

	/**
	 * @param value Идентификатор экземпляра запуска отчета
	 */
	public void setInstanceID(Long value) {
		setProperty(PROPERTY_INSTANCE_ID, value);
	}
	/**
	 * @return Идентификатор запущенного процесса
	 */
	@XmlElement(name = PROPERTY_PROCESS_ID, required = false)
	public Long getProcessID() {
		return getProperty(PROPERTY_PROCESS_ID);
	}

	/**
	 * @param value Идентификатор запущенного процесса
	 */
	public void setProcessID(Long value) {
		setProperty(PROPERTY_PROCESS_ID, value);
	}
	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = false)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_NAME, required = false)
	public String getFCReportName() {
		return getProperty(PROPERTY_FCREPORT_NAME);
	}

	/**
	 * @param value Наименование отчета
	 */
	public void setFCReportName(String value) {
		setProperty(PROPERTY_FCREPORT_NAME, value);
	}
	/**
	 * @return Системное наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_SYS_NAME, required = false)
	public String getFCReportSysName() {
		return getProperty(PROPERTY_FCREPORT_SYS_NAME);
	}

	/**
	 * @param value Системное наименование отчета
	 */
	public void setFCReportSysName(String value) {
		setProperty(PROPERTY_FCREPORT_SYS_NAME, value);
	}
	/**
	 * @return Логин пользователя
	 */
	@XmlElement(name = PROPERTY_USER_LOGIN, required = false)
	public String getUserLogin() {
		return getProperty(PROPERTY_USER_LOGIN);
	}

	/**
	 * @param value Логин пользователя
	 */
	public void setUserLogin(String value) {
		setProperty(PROPERTY_USER_LOGIN, value);
	}
	/**
	 * @return Дата запуска отчета
	 */
	@XmlElement(name = PROPERTY_START_DATE, required = false)
	public Date getStartDate() {
		return getProperty(PROPERTY_START_DATE);
	}

	/**
	 * @param value Дата запуска отчета
	 */
	public void setStartDate(Date value) {
		setProperty(PROPERTY_START_DATE, value);
	}
	/**
	 * @return Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	@XmlElement(name = PROPERTY_EXECUTE_STATUS, required = false)
	public Integer getExecuteStatus() {
		return getProperty(PROPERTY_EXECUTE_STATUS);
	}

	/**
	 * @param value Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 */
	public void setExecuteStatus(Integer value) {
		setProperty(PROPERTY_EXECUTE_STATUS, value);
	}
	/**
	 * @return Наименование сформированного файла отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_FILE_NAME, required = false)
	public String getFCReportFileName() {
		return getProperty(PROPERTY_FCREPORT_FILE_NAME);
	}

	/**
	 * @param value Наименование сформированного файла отчета
	 */
	public void setFCReportFileName(String value) {
		setProperty(PROPERTY_FCREPORT_FILE_NAME, value);
	}
	/**
	 * @return Дата окончания формирования отчета
	 */
	@XmlElement(name = PROPERTY_END_DATE, required = false)
	public Date getEndDate() {
		return getProperty(PROPERTY_END_DATE);
	}

	/**
	 * @param value Дата окончания формирования отчета
	 */
	public void setEndDate(Date value) {
		setProperty(PROPERTY_END_DATE, value);
	}
	/**
	 * @return Идентификатор группы отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_ID, required = false)
	public Long getFCReportGroupID() {
		return getProperty(PROPERTY_FCREPORT_GROUP_ID);
	}

	/**
	 * @param value Идентификатор группы отчета
	 */
	public void setFCReportGroupID(Long value) {
		setProperty(PROPERTY_FCREPORT_GROUP_ID, value);
	}
	/**
	 * @return Наименование группы отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_NAME, required = false)
	public String getFCReportGroupName() {
		return getProperty(PROPERTY_FCREPORT_GROUP_NAME);
	}

	/**
	 * @param value Наименование группы отчета
	 */
	public void setFCReportGroupName(String value) {
		setProperty(PROPERTY_FCREPORT_GROUP_NAME, value);
	}

}
