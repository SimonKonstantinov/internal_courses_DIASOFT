package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param LinkID Идентификатор для связи
 * @param MethodID Идентификатор метода
 * @param InputDatasetName Наименование входящего набора данных
 * @param InputParametrSysName Наименование входящего параметра метода
 * @param InputParametrValue Значение входящего параметра метода
 * @param InputParametrName Имя параметра для пользователя
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TInputParamtrListTypeForDSFCReportMassInsertInputParametr",
	propOrder = {
		"linkID",
		"methodID",
		"inputDatasetName",
		"inputParametrSysName",
		"inputParametrValue",
		"inputParametrName"
	}
)
public class TInputParamtrListTypeForDSFCReportMassInsertInputParametr extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_LINK_ID = "LinkID";
	public static final String PROPERTY_METHOD_ID = "MethodID";
	public static final String PROPERTY_INPUT_DATASET_NAME = "InputDatasetName";
	public static final String PROPERTY_INPUT_PARAMETR_SYS_NAME = "InputParametrSysName";
	public static final String PROPERTY_INPUT_PARAMETR_VALUE = "InputParametrValue";
	public static final String PROPERTY_INPUT_PARAMETR_NAME = "InputParametrName";

	private static final MetaObject INFO = new MetaObject(
		TInputParamtrListTypeForDSFCReportMassInsertInputParametr.class.getName(),
		new MetaObjectAttribute(PROPERTY_LINK_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_METHOD_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_DATASET_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETR_SYS_NAME, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETR_VALUE, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETR_NAME, String.class, false, false, false) 
	);

    public TInputParamtrListTypeForDSFCReportMassInsertInputParametr() {
		super(INFO);
	}

	/**
	 * @return Идентификатор для связи
	 */
	@XmlElement(name = PROPERTY_LINK_ID, required = true)
	public Long getLinkID() {
		return getProperty(PROPERTY_LINK_ID);
	}

	/**
	 * @param value Идентификатор для связи
	 */
	public void setLinkID(Long value) {
		setProperty(PROPERTY_LINK_ID, value);
	}
	/**
	 * @return Идентификатор метода
	 */
	@XmlElement(name = PROPERTY_METHOD_ID, required = true)
	public Long getMethodID() {
		return getProperty(PROPERTY_METHOD_ID);
	}

	/**
	 * @param value Идентификатор метода
	 */
	public void setMethodID(Long value) {
		setProperty(PROPERTY_METHOD_ID, value);
	}
	/**
	 * @return Наименование входящего набора данных
	 */
	@XmlElement(name = PROPERTY_INPUT_DATASET_NAME, required = false)
	public String getInputDatasetName() {
		return getProperty(PROPERTY_INPUT_DATASET_NAME);
	}

	/**
	 * @param value Наименование входящего набора данных
	 */
	public void setInputDatasetName(String value) {
		setProperty(PROPERTY_INPUT_DATASET_NAME, value);
	}
	/**
	 * @return Наименование входящего параметра метода
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETR_SYS_NAME, required = true)
	public String getInputParametrSysName() {
		return getProperty(PROPERTY_INPUT_PARAMETR_SYS_NAME);
	}

	/**
	 * @param value Наименование входящего параметра метода
	 */
	public void setInputParametrSysName(String value) {
		setProperty(PROPERTY_INPUT_PARAMETR_SYS_NAME, value);
	}
	/**
	 * @return Значение входящего параметра метода
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETR_VALUE, required = true)
	public String getInputParametrValue() {
		return getProperty(PROPERTY_INPUT_PARAMETR_VALUE);
	}

	/**
	 * @param value Значение входящего параметра метода
	 */
	public void setInputParametrValue(String value) {
		setProperty(PROPERTY_INPUT_PARAMETR_VALUE, value);
	}
	/**
	 * @return Имя параметра для пользователя
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETR_NAME, required = false)
	public String getInputParametrName() {
		return getProperty(PROPERTY_INPUT_PARAMETR_NAME);
	}

	/**
	 * @param value Имя параметра для пользователя
	 */
	public void setInputParametrName(String value) {
		setProperty(PROPERTY_INPUT_PARAMETR_NAME, value);
	}

}
