package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param LinkID Идентификатор для связи
 * @param OutputDatasetName Имя исходящего набора данных метода
 * @param TableName Имя таблицы для хранения ответа метода
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TTableListTypeForDSFCReportMassInsertMethod",
	propOrder = {
		"linkID",
		"outputDatasetName",
		"tableName"
	}
)
public class TTableListTypeForDSFCReportMassInsertMethod extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_LINK_ID = "LinkID";
	public static final String PROPERTY_OUTPUT_DATASET_NAME = "OutputDatasetName";
	public static final String PROPERTY_TABLE_NAME = "TableName";

	private static final MetaObject INFO = new MetaObject(
		TTableListTypeForDSFCReportMassInsertMethod.class.getName(),
		new MetaObjectAttribute(PROPERTY_LINK_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_OUTPUT_DATASET_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_TABLE_NAME, String.class, false, true, false) 
	);

    public TTableListTypeForDSFCReportMassInsertMethod() {
		super(INFO);
	}

	/**
	 * @return Идентификатор для связи
	 */
	@XmlElement(name = PROPERTY_LINK_ID, required = true)
	public Long getLinkID() {
		return getProperty(PROPERTY_LINK_ID);
	}

	/**
	 * @param value Идентификатор для связи
	 */
	public void setLinkID(Long value) {
		setProperty(PROPERTY_LINK_ID, value);
	}
	/**
	 * @return Имя исходящего набора данных метода
	 */
	@XmlElement(name = PROPERTY_OUTPUT_DATASET_NAME, required = false)
	public String getOutputDatasetName() {
		return getProperty(PROPERTY_OUTPUT_DATASET_NAME);
	}

	/**
	 * @param value Имя исходящего набора данных метода
	 */
	public void setOutputDatasetName(String value) {
		setProperty(PROPERTY_OUTPUT_DATASET_NAME, value);
	}
	/**
	 * @return Имя таблицы для хранения ответа метода
	 */
	@XmlElement(name = PROPERTY_TABLE_NAME, required = true)
	public String getTableName() {
		return getProperty(PROPERTY_TABLE_NAME);
	}

	/**
	 * @param value Имя таблицы для хранения ответа метода
	 */
	public void setTableName(String value) {
		setProperty(PROPERTY_TABLE_NAME, value);
	}

}
