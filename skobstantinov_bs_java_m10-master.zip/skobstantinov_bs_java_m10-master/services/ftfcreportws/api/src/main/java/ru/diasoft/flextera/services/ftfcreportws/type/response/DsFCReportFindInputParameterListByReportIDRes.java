package ru.diasoft.flextera.services.ftfcreportws.type.response;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InputParamterList Список входящих параметров
 * @param ParameterKeyList Список ключевых полей списочных параметров.
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportFindInputParameterListByReportIDRes",
	propOrder = {
		"inputParamterList",
		"parameterKeyList",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportFindInputParameterListByReportIDRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INPUT_PARAMTER_LIST = "InputParamterList";
	public static final String PROPERTY_PARAMETER_KEY_LIST = "ParameterKeyList";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportFindInputParameterListByReportIDRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMTER_LIST, TInputParamterListTypeForDSFCReportFindInputParameterListByReportID.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_PARAMETER_KEY_LIST, TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportFindInputParameterListByReportIDRes() {
		super(INFO);
	}

	/**
	 * @return Список входящих параметров
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMTER_LIST, required = false)
	public List<TInputParamterListTypeForDSFCReportFindInputParameterListByReportID> getInputParamterList() {
		return getProperty(PROPERTY_INPUT_PARAMTER_LIST);
	}

	/**
	 * @param value Список входящих параметров
	 */
	public void setInputParamterList(List<TInputParamterListTypeForDSFCReportFindInputParameterListByReportID> value) {
		setProperty(PROPERTY_INPUT_PARAMTER_LIST, value);
	}
	/**
	 * @return Список ключевых полей списочных параметров.
	 */
	@XmlElement(name = PROPERTY_PARAMETER_KEY_LIST, required = false)
	public List<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID> getParameterKeyList() {
		return getProperty(PROPERTY_PARAMETER_KEY_LIST);
	}

	/**
	 * @param value Список ключевых полей списочных параметров.
	 */
	public void setParameterKeyList(List<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID> value) {
		setProperty(PROPERTY_PARAMETER_KEY_LIST, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
