package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param LinkID Идентификатор для связи
 * @param NTFID Идентификатор кода ошибки
 * @param NTFMessage Сообщение об ошибке
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TNotificationListTypeForDSFCReportMassInsertInputParametr",
	propOrder = {
		"linkID",
		"NTFID",
		"NTFMessage"
	}
)
public class TNotificationListTypeForDSFCReportMassInsertInputParametr extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_LINK_ID = "LinkID";
	public static final String PROPERTY_NTFID = "NTFID";
	public static final String PROPERTY_NTFMESSAGE = "NTFMessage";

	private static final MetaObject INFO = new MetaObject(
		TNotificationListTypeForDSFCReportMassInsertInputParametr.class.getName(),
		new MetaObjectAttribute(PROPERTY_LINK_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_NTFID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_NTFMESSAGE, String.class, false, false, false) 
	);

    public TNotificationListTypeForDSFCReportMassInsertInputParametr() {
		super(INFO);
	}

	/**
	 * @return Идентификатор для связи
	 */
	@XmlElement(name = PROPERTY_LINK_ID, required = true)
	public Long getLinkID() {
		return getProperty(PROPERTY_LINK_ID);
	}

	/**
	 * @param value Идентификатор для связи
	 */
	public void setLinkID(Long value) {
		setProperty(PROPERTY_LINK_ID, value);
	}
	/**
	 * @return Идентификатор кода ошибки
	 */
	@XmlElement(name = PROPERTY_NTFID, required = true)
	public Long getNTFID() {
		return getProperty(PROPERTY_NTFID);
	}

	/**
	 * @param value Идентификатор кода ошибки
	 */
	public void setNTFID(Long value) {
		setProperty(PROPERTY_NTFID, value);
	}
	/**
	 * @return Сообщение об ошибке
	 */
	@XmlElement(name = PROPERTY_NTFMESSAGE, required = false)
	public String getNTFMessage() {
		return getProperty(PROPERTY_NTFMESSAGE);
	}

	/**
	 * @param value Сообщение об ошибке
	 */
	public void setNTFMessage(String value) {
		setProperty(PROPERTY_NTFMESSAGE, value);
	}

}
