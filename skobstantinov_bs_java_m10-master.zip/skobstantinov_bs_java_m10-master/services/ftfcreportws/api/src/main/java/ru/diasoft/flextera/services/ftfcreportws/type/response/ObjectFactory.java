package ru.diasoft.flextera.services.ftfcreportws.type.response;
import javax.xml.bind.*;
import javax.xml.bind.annotation.*;
import javax.xml.namespace.*;



@XmlRegistry
public class ObjectFactory 
{
    private final static String NAME_SPACE = "http://support.diasoft.ru/type/response";


    private final static QName _DsFCReportProcessExecuteBuildingRes_QNAME = new QName(NAME_SPACE, "DsFCReportProcessExecuteBuildingRes", "response");

    private final static QName _DsFCReportMassInsertRes_QNAME = new QName(NAME_SPACE, "DsFCReportMassInsertRes", "response");

    private final static QName _DsFCReportDeleteRes_QNAME = new QName(NAME_SPACE, "DsFCReportDeleteRes", "response");

    private final static QName _DsFCReportUpdateRes_QNAME = new QName(NAME_SPACE, "DsFCReportUpdateRes", "response");

    private final static QName _DsFCReportBrowseListByParamRes_QNAME = new QName(NAME_SPACE, "DsFCReportBrowseListByParamRes", "response");

    private final static QName _DsFCReportFindByIDRes_QNAME = new QName(NAME_SPACE, "DsFCReportFindByIDRes", "response");

    private final static QName _DsFCReportBrowseListInstanceByParamRes_QNAME = new QName(NAME_SPACE, "DsFCReportBrowseListInstanceByParamRes", "response");

    private final static QName _DsFCReportFindInputParameterListByReportIDRes_QNAME = new QName(NAME_SPACE, "DsFCReportFindInputParameterListByReportIDRes", "response");

    private final static QName _DsFCReportFindProtocolByInstanceIDRes_QNAME = new QName(NAME_SPACE, "DsFCReportFindProtocolByInstanceIDRes", "response");

    private final static QName _DsFCReportMassDeleteInstanceRes_QNAME = new QName(NAME_SPACE, "DsFCReportMassDeleteInstanceRes", "response");

    private final static QName _DsFCReportGroupInsertRes_QNAME = new QName(NAME_SPACE, "DsFCReportGroupInsertRes", "response");

    private final static QName _DsFCReportGroupUpdateRes_QNAME = new QName(NAME_SPACE, "DsFCReportGroupUpdateRes", "response");

    private final static QName _DsFCReportGroupDeleteRes_QNAME = new QName(NAME_SPACE, "DsFCReportGroupDeleteRes", "response");

    private final static QName _DsFCReportGroupFindByIDRes_QNAME = new QName(NAME_SPACE, "DsFCReportGroupFindByIDRes", "response");

    private final static QName _DsFCReportGroupBrowseListByParamRes_QNAME = new QName(NAME_SPACE, "DsFCReportGroupBrowseListByParamRes", "response");

    private final static QName _DsOnAfterFCReportExecuteBuildingRes_QNAME = new QName(NAME_SPACE, "DsOnAfterFCReportExecuteBuildingRes", "response");

    public ObjectFactory() 
    {
    }

    public DsFCReportProcessExecuteBuildingRes createDsFCReportProcessExecuteBuildingRes() 
    {
        return new DsFCReportProcessExecuteBuildingRes();
    }

    public DsFCReportMassInsertRes createDsFCReportMassInsertRes() 
    {
        return new DsFCReportMassInsertRes();
    }

    public DsFCReportDeleteRes createDsFCReportDeleteRes() 
    {
        return new DsFCReportDeleteRes();
    }

    public DsFCReportUpdateRes createDsFCReportUpdateRes() 
    {
        return new DsFCReportUpdateRes();
    }

    public DsFCReportBrowseListByParamRes createDsFCReportBrowseListByParamRes() 
    {
        return new DsFCReportBrowseListByParamRes();
    }

    public DsFCReportFindByIDRes createDsFCReportFindByIDRes() 
    {
        return new DsFCReportFindByIDRes();
    }

    public DsFCReportBrowseListInstanceByParamRes createDsFCReportBrowseListInstanceByParamRes() 
    {
        return new DsFCReportBrowseListInstanceByParamRes();
    }

    public DsFCReportFindInputParameterListByReportIDRes createDsFCReportFindInputParameterListByReportIDRes() 
    {
        return new DsFCReportFindInputParameterListByReportIDRes();
    }

    public DsFCReportFindProtocolByInstanceIDRes createDsFCReportFindProtocolByInstanceIDRes() 
    {
        return new DsFCReportFindProtocolByInstanceIDRes();
    }

    public DsFCReportMassDeleteInstanceRes createDsFCReportMassDeleteInstanceRes() 
    {
        return new DsFCReportMassDeleteInstanceRes();
    }

    public DsFCReportGroupInsertRes createDsFCReportGroupInsertRes() 
    {
        return new DsFCReportGroupInsertRes();
    }

    public DsFCReportGroupUpdateRes createDsFCReportGroupUpdateRes() 
    {
        return new DsFCReportGroupUpdateRes();
    }

    public DsFCReportGroupDeleteRes createDsFCReportGroupDeleteRes() 
    {
        return new DsFCReportGroupDeleteRes();
    }

    public DsFCReportGroupFindByIDRes createDsFCReportGroupFindByIDRes() 
    {
        return new DsFCReportGroupFindByIDRes();
    }

    public DsFCReportGroupBrowseListByParamRes createDsFCReportGroupBrowseListByParamRes() 
    {
        return new DsFCReportGroupBrowseListByParamRes();
    }

    public DsOnAfterFCReportExecuteBuildingRes createDsOnAfterFCReportExecuteBuildingRes() 
    {
        return new DsOnAfterFCReportExecuteBuildingRes();
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportProcessExecuteBuildingRes"
    )
    public JAXBElement<DsFCReportProcessExecuteBuildingRes> createDsFCReportProcessExecuteBuildingRes(DsFCReportProcessExecuteBuildingRes value) 
    {
        return new JAXBElement<DsFCReportProcessExecuteBuildingRes>(_DsFCReportProcessExecuteBuildingRes_QNAME, DsFCReportProcessExecuteBuildingRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportMassInsertRes"
    )
    public JAXBElement<DsFCReportMassInsertRes> createDsFCReportMassInsertRes(DsFCReportMassInsertRes value) 
    {
        return new JAXBElement<DsFCReportMassInsertRes>(_DsFCReportMassInsertRes_QNAME, DsFCReportMassInsertRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportDeleteRes"
    )
    public JAXBElement<DsFCReportDeleteRes> createDsFCReportDeleteRes(DsFCReportDeleteRes value) 
    {
        return new JAXBElement<DsFCReportDeleteRes>(_DsFCReportDeleteRes_QNAME, DsFCReportDeleteRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportUpdateRes"
    )
    public JAXBElement<DsFCReportUpdateRes> createDsFCReportUpdateRes(DsFCReportUpdateRes value) 
    {
        return new JAXBElement<DsFCReportUpdateRes>(_DsFCReportUpdateRes_QNAME, DsFCReportUpdateRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportBrowseListByParamRes"
    )
    public JAXBElement<DsFCReportBrowseListByParamRes> createDsFCReportBrowseListByParamRes(DsFCReportBrowseListByParamRes value) 
    {
        return new JAXBElement<DsFCReportBrowseListByParamRes>(_DsFCReportBrowseListByParamRes_QNAME, DsFCReportBrowseListByParamRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportFindByIDRes"
    )
    public JAXBElement<DsFCReportFindByIDRes> createDsFCReportFindByIDRes(DsFCReportFindByIDRes value) 
    {
        return new JAXBElement<DsFCReportFindByIDRes>(_DsFCReportFindByIDRes_QNAME, DsFCReportFindByIDRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportBrowseListInstanceByParamRes"
    )
    public JAXBElement<DsFCReportBrowseListInstanceByParamRes> createDsFCReportBrowseListInstanceByParamRes(DsFCReportBrowseListInstanceByParamRes value) 
    {
        return new JAXBElement<DsFCReportBrowseListInstanceByParamRes>(_DsFCReportBrowseListInstanceByParamRes_QNAME, DsFCReportBrowseListInstanceByParamRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportFindInputParameterListByReportIDRes"
    )
    public JAXBElement<DsFCReportFindInputParameterListByReportIDRes> createDsFCReportFindInputParameterListByReportIDRes(DsFCReportFindInputParameterListByReportIDRes value) 
    {
        return new JAXBElement<DsFCReportFindInputParameterListByReportIDRes>(_DsFCReportFindInputParameterListByReportIDRes_QNAME, DsFCReportFindInputParameterListByReportIDRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportFindProtocolByInstanceIDRes"
    )
    public JAXBElement<DsFCReportFindProtocolByInstanceIDRes> createDsFCReportFindProtocolByInstanceIDRes(DsFCReportFindProtocolByInstanceIDRes value) 
    {
        return new JAXBElement<DsFCReportFindProtocolByInstanceIDRes>(_DsFCReportFindProtocolByInstanceIDRes_QNAME, DsFCReportFindProtocolByInstanceIDRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportMassDeleteInstanceRes"
    )
    public JAXBElement<DsFCReportMassDeleteInstanceRes> createDsFCReportMassDeleteInstanceRes(DsFCReportMassDeleteInstanceRes value) 
    {
        return new JAXBElement<DsFCReportMassDeleteInstanceRes>(_DsFCReportMassDeleteInstanceRes_QNAME, DsFCReportMassDeleteInstanceRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportGroupInsertRes"
    )
    public JAXBElement<DsFCReportGroupInsertRes> createDsFCReportGroupInsertRes(DsFCReportGroupInsertRes value) 
    {
        return new JAXBElement<DsFCReportGroupInsertRes>(_DsFCReportGroupInsertRes_QNAME, DsFCReportGroupInsertRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportGroupUpdateRes"
    )
    public JAXBElement<DsFCReportGroupUpdateRes> createDsFCReportGroupUpdateRes(DsFCReportGroupUpdateRes value) 
    {
        return new JAXBElement<DsFCReportGroupUpdateRes>(_DsFCReportGroupUpdateRes_QNAME, DsFCReportGroupUpdateRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportGroupDeleteRes"
    )
    public JAXBElement<DsFCReportGroupDeleteRes> createDsFCReportGroupDeleteRes(DsFCReportGroupDeleteRes value) 
    {
        return new JAXBElement<DsFCReportGroupDeleteRes>(_DsFCReportGroupDeleteRes_QNAME, DsFCReportGroupDeleteRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportGroupFindByIDRes"
    )
    public JAXBElement<DsFCReportGroupFindByIDRes> createDsFCReportGroupFindByIDRes(DsFCReportGroupFindByIDRes value) 
    {
        return new JAXBElement<DsFCReportGroupFindByIDRes>(_DsFCReportGroupFindByIDRes_QNAME, DsFCReportGroupFindByIDRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsFCReportGroupBrowseListByParamRes"
    )
    public JAXBElement<DsFCReportGroupBrowseListByParamRes> createDsFCReportGroupBrowseListByParamRes(DsFCReportGroupBrowseListByParamRes value) 
    {
        return new JAXBElement<DsFCReportGroupBrowseListByParamRes>(_DsFCReportGroupBrowseListByParamRes_QNAME, DsFCReportGroupBrowseListByParamRes.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/response", 
          name = "DsOnAfterFCReportExecuteBuildingRes"
    )
    public JAXBElement<DsOnAfterFCReportExecuteBuildingRes> createDsOnAfterFCReportExecuteBuildingRes(DsOnAfterFCReportExecuteBuildingRes value) 
    {
        return new JAXBElement<DsOnAfterFCReportExecuteBuildingRes>(_DsOnAfterFCReportExecuteBuildingRes_QNAME, DsOnAfterFCReportExecuteBuildingRes.class, null, value);
    }

}
