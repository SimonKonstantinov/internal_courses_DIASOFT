package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import ru.diasoft.flextera.services.ftfcreportws.type.*;
import ru.diasoft.flextera.services.ftfcreportws.type.request.*;
import ru.diasoft.flextera.services.ftfcreportws.type.response.*;


import static org.apache.commons.lang.StringUtils.join;
import static ru.diasoft.core.application.dto.TypeConverter.transformType;
import static ru.diasoft.core.application.dto.validation.Validators.*;
import static ru.diasoft.core.exception.RetCodes.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ru.diasoft.core.application.command.AbstractCommand;
import ru.diasoft.core.application.dto.AbstractTransferObject;
import ru.diasoft.core.application.dto.DataValidationException;
import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.MultipleMainListsException;
import ru.diasoft.core.application.dto.PropertyRequiredException;
import ru.diasoft.core.application.dto.meta.MetaObject;
import ru.diasoft.core.application.dto.meta.MetaObjectAttribute;
import ru.diasoft.core.application.dto.validation.NTFInserter;
import ru.diasoft.core.application.dto.validation.Validators;
import ru.diasoft.core.persistence.facet.FacetQueryStore;
import ru.diasoft.core.util.sandbox.Sandbox;

/**
 * Метод получения информации об экземплярах запуска отчета
 * 
 * @param FCReportID Идентификатор отчета
 * @param FCReportName Наименование отчета
 * @param FCReportSysName Системное наименование отчета
 * @param UserLogin Логин пользователя
 * @param StartDate Дата запуска отчета
 * @param ExecuteStatus Статус формирования отчета. Возможные значения:<br>
 *	1 - формируется;<br>
 *	2 - готов;<br>
 *	3 - ошибка.
 * @param ProcessID Идентификатор запущенного процесса
 * @param ORDERBY Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
 *	Если не задана, сортировка производится по первому полю выходного набора.
 * @param PAGE Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
 * @param ROWSCOUNT Число записей на страницу для постраничной разбивки. По умолчанию 10
 * @param FCReportGroupID Идентификатор группы отчета
 * 
 * @return TOTALCOUNT Общее количество найденных записей
 * @return Result Список экземпляров запуска отчетов
 * @return ReturnMsg Сообщение
 * @return ReturnCode Код
 */
public abstract class DsFCReportBrowseListInstanceByParamStub
		extends AbstractCommand<DsFCReportBrowseListInstanceByParamReq, DsFCReportBrowseListInstanceByParamRes> implements NTFInserter {

	protected final FacetQueryStore queries = Sandbox.INSTANCE.singleProvider(FacetQueryStore.class);
	protected final Validators.LinkageValidator linkageValidator = new Validators.LinkageValidator(this);

	protected DsFCReportBrowseListInstanceByParamStub() {
		super(DsFCReportBrowseListInstanceByParamReq.class, DsFCReportBrowseListInstanceByParamRes.class);
		setOutputData(new ru.diasoft.flextera.services.ftfcreportws.type.response.ObjectFactory().createDsFCReportBrowseListInstanceByParamRes());
	    getOutputData().setResult(new ArrayList<TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam>());
		setSupressDefaultValidation(true);
	}

	@Override
	protected void validateInput(MetaObject metaInfo, Map<String, Object> values) throws DataValidationException {
		// Checking required parameters
		List<String> missingParams = GROUP_VALIDATOR.validate(metaInfo, values);
		if(missingParams.size() > 0) {
			throw new PropertyRequiredException(join(missingParams, ", "));
		}
		
		// Checking for multiple main lists
		List<String> mainListNames = MAIN_LIST_VALIDATOR.validate(metaInfo, values);
		if(mainListNames.size() > 1) {
			throw new MultipleMainListsException(join(mainListNames, ", "));
		}
		
		// Checking required parameters of inner lists
		for (MetaObjectAttribute attr : metaInfo.getAttributes()) {
			Object value = values.get(attr.getSystemName());
			if(value instanceof List) {
				for(Object dto : (List<?>)value) {
					if(dto instanceof AbstractTransferObject) {
						missingParams = ((AbstractTransferObject)dto).validate(GROUP_VALIDATOR);
						if(missingParams.size() > 0) {
							Long linkID = null;
							if(dto instanceof Linkable) {
								linkID = ((Linkable)dto).getLinkID();
							}
							if(linkID == null || linkID < 0) {
								linkID = Long.valueOf(0);
							}
							insertNotification(linkID, PROPERTY_REQUIRED_EXCEPTION.getStatus(), PROPERTY_REQUIRED_EXCEPTION.getResourceBundleName(), join(missingParams, ", "), attr.getSystemName());
						}
					}
				}
			}
		}
		
		// Checking linkage between lists
		linkageValidator.validate(metaInfo, values);
	}

	@Override
	protected void validateOutput(MetaObject metaInfo, Map<String, Object> values) throws DataValidationException {
		// Checking required parameters
		List<String> missingParams = GROUP_VALIDATOR.validate(metaInfo, values);
		if(missingParams.size() > 0) {
			throw new PropertyRequiredException(join(missingParams, ", "));
		}
	}

	public void insertNotification(Long linkID, Long ntfID, String key, Object... args) {
	}


}
