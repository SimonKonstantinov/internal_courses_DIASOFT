package ru.diasoft.flextera.services.ftfcreportws.command;
import ru.diasoft.core.application.command.*;
import ru.diasoft.flextera.services.type.*;


public abstract class GetHealthInfoCommandStub 
       extends AbstractCommand<GetHealthInfo, GetHealthInfoRes> {
       
       public GetHealthInfoCommandStub() {
       		super(GetHealthInfo.class, GetHealthInfoRes.class);
       }
}
