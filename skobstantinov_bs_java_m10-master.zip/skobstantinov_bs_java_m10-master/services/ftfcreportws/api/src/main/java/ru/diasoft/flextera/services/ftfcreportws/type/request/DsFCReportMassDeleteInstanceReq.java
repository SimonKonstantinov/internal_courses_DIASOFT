package ru.diasoft.flextera.services.ftfcreportws.type.request;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InstanceIDList Список идентификаторов удаляемых экземпляров запуска отчетов
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportMassDeleteInstanceReq",
	propOrder = {
		"instanceIDList"
	}
)
public class DsFCReportMassDeleteInstanceReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INSTANCE_IDLIST = "InstanceIDList";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportMassDeleteInstanceReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_INSTANCE_IDLIST, TInstanceIDListTypeForDSFCReportMassDeleteInstance.class, true, true, false) 
	);

    public DsFCReportMassDeleteInstanceReq() {
		super(INFO);
	}

	/**
	 * @return Список идентификаторов удаляемых экземпляров запуска отчетов
	 */
	@XmlElement(name = PROPERTY_INSTANCE_IDLIST, required = true)
	public List<TInstanceIDListTypeForDSFCReportMassDeleteInstance> getInstanceIDList() {
		return getProperty(PROPERTY_INSTANCE_IDLIST);
	}

	/**
	 * @param value Список идентификаторов удаляемых экземпляров запуска отчетов
	 */
	public void setInstanceIDList(List<TInstanceIDListTypeForDSFCReportMassDeleteInstance> value) {
		setProperty(PROPERTY_INSTANCE_IDLIST, value);
	}

}
