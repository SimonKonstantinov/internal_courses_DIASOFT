package ru.diasoft.flextera.services.ftfcreportws.type.request;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param MethodList Список параметров метода
 * @param TableList Список таблиц для хранения ответа метода
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportMassInsertMethodReq",
	propOrder = {
		"methodList",
		"tableList"
	}
)
public class DsFCReportMassInsertMethodReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_METHOD_LIST = "MethodList";
	public static final String PROPERTY_TABLE_LIST = "TableList";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportMassInsertMethodReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_METHOD_LIST, TMethodListTypeForDSFCReportMassInsertMethod.class, true, true, false), 
		new MetaObjectAttribute(PROPERTY_TABLE_LIST, TTableListTypeForDSFCReportMassInsertMethod.class, true, true, false) 
	);

    public DsFCReportMassInsertMethodReq() {
		super(INFO);
	}

	/**
	 * @return Список параметров метода
	 */
	@XmlElement(name = PROPERTY_METHOD_LIST, required = true)
	public List<TMethodListTypeForDSFCReportMassInsertMethod> getMethodList() {
		return getProperty(PROPERTY_METHOD_LIST);
	}

	/**
	 * @param value Список параметров метода
	 */
	public void setMethodList(List<TMethodListTypeForDSFCReportMassInsertMethod> value) {
		setProperty(PROPERTY_METHOD_LIST, value);
	}
	/**
	 * @return Список таблиц для хранения ответа метода
	 */
	@XmlElement(name = PROPERTY_TABLE_LIST, required = true)
	public List<TTableListTypeForDSFCReportMassInsertMethod> getTableList() {
		return getProperty(PROPERTY_TABLE_LIST);
	}

	/**
	 * @param value Список таблиц для хранения ответа метода
	 */
	public void setTableList(List<TTableListTypeForDSFCReportMassInsertMethod> value) {
		setProperty(PROPERTY_TABLE_LIST, value);
	}

}
