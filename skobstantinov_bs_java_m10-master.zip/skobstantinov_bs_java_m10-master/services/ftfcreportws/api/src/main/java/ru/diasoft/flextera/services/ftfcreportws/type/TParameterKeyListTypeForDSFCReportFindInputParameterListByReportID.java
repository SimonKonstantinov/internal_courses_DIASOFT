package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InputParameterSysName Наименование входящего параметра метода
 * @param ParameterKeySysName Системное наименование элемента
 * @param ParameterKeyName Наименование элемента для пользователя
 * @param ParameterKeyType Тип элемента
 * @param ParameterKeyRequiredFlag Признак обязательности элемента
 * @param ParameterKeyDefaultValue Значение элемента
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID",
	propOrder = {
		"inputParameterSysName",
		"parameterKeySysName",
		"parameterKeyName",
		"parameterKeyType",
		"parameterKeyRequiredFlag",
		"parameterKeyDefaultValue"
	}
)
public class TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INPUT_PARAMETER_SYS_NAME = "InputParameterSysName";
	public static final String PROPERTY_PARAMETER_KEY_SYS_NAME = "ParameterKeySysName";
	public static final String PROPERTY_PARAMETER_KEY_NAME = "ParameterKeyName";
	public static final String PROPERTY_PARAMETER_KEY_TYPE = "ParameterKeyType";
	public static final String PROPERTY_PARAMETER_KEY_REQUIRED_FLAG = "ParameterKeyRequiredFlag";
	public static final String PROPERTY_PARAMETER_KEY_DEFAULT_VALUE = "ParameterKeyDefaultValue";

	private static final MetaObject INFO = new MetaObject(
		TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID.class.getName(),
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETER_SYS_NAME, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_PARAMETER_KEY_SYS_NAME, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_PARAMETER_KEY_NAME, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_PARAMETER_KEY_TYPE, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_PARAMETER_KEY_REQUIRED_FLAG, Boolean.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PARAMETER_KEY_DEFAULT_VALUE, String.class, false, false, false) 
	);

    public TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID() {
		super(INFO);
	}

	/**
	 * @return Наименование входящего параметра метода
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETER_SYS_NAME, required = true)
	public String getInputParameterSysName() {
		return getProperty(PROPERTY_INPUT_PARAMETER_SYS_NAME);
	}

	/**
	 * @param value Наименование входящего параметра метода
	 */
	public void setInputParameterSysName(String value) {
		setProperty(PROPERTY_INPUT_PARAMETER_SYS_NAME, value);
	}
	/**
	 * @return Системное наименование элемента
	 */
	@XmlElement(name = PROPERTY_PARAMETER_KEY_SYS_NAME, required = true)
	public String getParameterKeySysName() {
		return getProperty(PROPERTY_PARAMETER_KEY_SYS_NAME);
	}

	/**
	 * @param value Системное наименование элемента
	 */
	public void setParameterKeySysName(String value) {
		setProperty(PROPERTY_PARAMETER_KEY_SYS_NAME, value);
	}
	/**
	 * @return Наименование элемента для пользователя
	 */
	@XmlElement(name = PROPERTY_PARAMETER_KEY_NAME, required = true)
	public String getParameterKeyName() {
		return getProperty(PROPERTY_PARAMETER_KEY_NAME);
	}

	/**
	 * @param value Наименование элемента для пользователя
	 */
	public void setParameterKeyName(String value) {
		setProperty(PROPERTY_PARAMETER_KEY_NAME, value);
	}
	/**
	 * @return Тип элемента
	 */
	@XmlElement(name = PROPERTY_PARAMETER_KEY_TYPE, required = true)
	public String getParameterKeyType() {
		return getProperty(PROPERTY_PARAMETER_KEY_TYPE);
	}

	/**
	 * @param value Тип элемента
	 */
	public void setParameterKeyType(String value) {
		setProperty(PROPERTY_PARAMETER_KEY_TYPE, value);
	}
	/**
	 * @return Признак обязательности элемента
	 */
	@XmlElement(name = PROPERTY_PARAMETER_KEY_REQUIRED_FLAG, required = false)
	public Boolean getParameterKeyRequiredFlag() {
		return getProperty(PROPERTY_PARAMETER_KEY_REQUIRED_FLAG);
	}

	/**
	 * @param value Признак обязательности элемента
	 */
	public void setParameterKeyRequiredFlag(Boolean value) {
		setProperty(PROPERTY_PARAMETER_KEY_REQUIRED_FLAG, value);
	}
	/**
	 * @return Значение элемента
	 */
	@XmlElement(name = PROPERTY_PARAMETER_KEY_DEFAULT_VALUE, required = false)
	public String getParameterKeyDefaultValue() {
		return getProperty(PROPERTY_PARAMETER_KEY_DEFAULT_VALUE);
	}

	/**
	 * @param value Значение элемента
	 */
	public void setParameterKeyDefaultValue(String value) {
		setProperty(PROPERTY_PARAMETER_KEY_DEFAULT_VALUE, value);
	}

}
