package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param ReportHistoryID Идентификатор записи истории запуска отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportHistoryGetByIDReq",
	propOrder = {
		"reportHistoryID"
	}
)
public class DsFCReportHistoryGetByIDReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_REPORT_HISTORY_ID = "ReportHistoryID";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportHistoryGetByIDReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_REPORT_HISTORY_ID, Long.class, false, true, false) 
	);

    public DsFCReportHistoryGetByIDReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор записи истории запуска отчета
	 */
	@XmlElement(name = PROPERTY_REPORT_HISTORY_ID, required = true)
	public Long getReportHistoryID() {
		return getProperty(PROPERTY_REPORT_HISTORY_ID);
	}

	/**
	 * @param value Идентификатор записи истории запуска отчета
	 */
	public void setReportHistoryID(Long value) {
		setProperty(PROPERTY_REPORT_HISTORY_ID, value);
	}

}
