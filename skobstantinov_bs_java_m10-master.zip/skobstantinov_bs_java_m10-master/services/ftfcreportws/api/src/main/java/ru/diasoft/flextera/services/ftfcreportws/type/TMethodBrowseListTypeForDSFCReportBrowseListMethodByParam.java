package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param MethodID Идентификатор метода
 * @param MethodName Имя метода
 * @param ServiceName Имя сервиса, в котором реализован метод
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TMethodBrowseListTypeForDSFCReportBrowseListMethodByParam",
	propOrder = {
		"methodID",
		"methodName",
		"serviceName"
	}
)
public class TMethodBrowseListTypeForDSFCReportBrowseListMethodByParam extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_METHOD_ID = "MethodID";
	public static final String PROPERTY_METHOD_NAME = "MethodName";
	public static final String PROPERTY_SERVICE_NAME = "ServiceName";

	private static final MetaObject INFO = new MetaObject(
		TMethodBrowseListTypeForDSFCReportBrowseListMethodByParam.class.getName(),
		new MetaObjectAttribute(PROPERTY_METHOD_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_METHOD_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_SERVICE_NAME, String.class, false, false, false) 
	);

    public TMethodBrowseListTypeForDSFCReportBrowseListMethodByParam() {
		super(INFO);
	}

	/**
	 * @return Идентификатор метода
	 */
	@XmlElement(name = PROPERTY_METHOD_ID, required = true)
	public Long getMethodID() {
		return getProperty(PROPERTY_METHOD_ID);
	}

	/**
	 * @param value Идентификатор метода
	 */
	public void setMethodID(Long value) {
		setProperty(PROPERTY_METHOD_ID, value);
	}
	/**
	 * @return Имя метода
	 */
	@XmlElement(name = PROPERTY_METHOD_NAME, required = false)
	public String getMethodName() {
		return getProperty(PROPERTY_METHOD_NAME);
	}

	/**
	 * @param value Имя метода
	 */
	public void setMethodName(String value) {
		setProperty(PROPERTY_METHOD_NAME, value);
	}
	/**
	 * @return Имя сервиса, в котором реализован метод
	 */
	@XmlElement(name = PROPERTY_SERVICE_NAME, required = false)
	public String getServiceName() {
		return getProperty(PROPERTY_SERVICE_NAME);
	}

	/**
	 * @param value Имя сервиса, в котором реализован метод
	 */
	public void setServiceName(String value) {
		setProperty(PROPERTY_SERVICE_NAME, value);
	}

}
