package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param LinkID Идентификатор для связи
 * @param InputParametrID Идентификатор входящего параметра метода
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TInputParametrIDListTypeForDSFCReportMassInsertInputParametr",
	propOrder = {
		"linkID",
		"inputParametrID"
	}
)
public class TInputParametrIDListTypeForDSFCReportMassInsertInputParametr extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_LINK_ID = "LinkID";
	public static final String PROPERTY_INPUT_PARAMETR_ID = "InputParametrID";

	private static final MetaObject INFO = new MetaObject(
		TInputParametrIDListTypeForDSFCReportMassInsertInputParametr.class.getName(),
		new MetaObjectAttribute(PROPERTY_LINK_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETR_ID, Long.class, false, true, false) 
	);

    public TInputParametrIDListTypeForDSFCReportMassInsertInputParametr() {
		super(INFO);
	}

	/**
	 * @return Идентификатор для связи
	 */
	@XmlElement(name = PROPERTY_LINK_ID, required = true)
	public Long getLinkID() {
		return getProperty(PROPERTY_LINK_ID);
	}

	/**
	 * @param value Идентификатор для связи
	 */
	public void setLinkID(Long value) {
		setProperty(PROPERTY_LINK_ID, value);
	}
	/**
	 * @return Идентификатор входящего параметра метода
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETR_ID, required = true)
	public Long getInputParametrID() {
		return getProperty(PROPERTY_INPUT_PARAMETR_ID);
	}

	/**
	 * @param value Идентификатор входящего параметра метода
	 */
	public void setInputParametrID(Long value) {
		setProperty(PROPERTY_INPUT_PARAMETR_ID, value);
	}

}
