package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportID Идентификатор отчета
 * @param FCReportName Наименование отчета
 * @param FCReportSysName Системное наименование отчета
 * @param FileFormat Формат файла, в котором будет сохранен отчет. Возможные значения:<br>
	 *	1 - xls;<br>
	 *	2 - pdf;<br>
	 *	3 - rtf.
 * @param DeleteDataFlag Флаг удаления данных, загруженных для экземпляра отчета
 * @param TemplatePathName Путь и наименование файла шаблона отчета
 * @param ConfigPathName Путь и наименование конфигурационного файла
 * @param FCReportGroupID Идентификатор группы отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportUpdateReq",
	propOrder = {
		"FCReportID",
		"FCReportName",
		"FCReportSysName",
		"fileFormat",
		"deleteDataFlag",
		"templatePathName",
		"configPathName",
		"FCReportGroupID"
	}
)
public class DsFCReportUpdateReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_FCREPORT_NAME = "FCReportName";
	public static final String PROPERTY_FCREPORT_SYS_NAME = "FCReportSysName";
	public static final String PROPERTY_FILE_FORMAT = "FileFormat";
	public static final String PROPERTY_DELETE_DATA_FLAG = "DeleteDataFlag";
	public static final String PROPERTY_TEMPLATE_PATH_NAME = "TemplatePathName";
	public static final String PROPERTY_CONFIG_PATH_NAME = "ConfigPathName";
	public static final String PROPERTY_FCREPORT_GROUP_ID = "FCReportGroupID";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportUpdateReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_SYS_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FILE_FORMAT, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_DELETE_DATA_FLAG, Boolean.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_TEMPLATE_PATH_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_CONFIG_PATH_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_GROUP_ID, Long.class, false, false, false) 
	);

    public DsFCReportUpdateReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = true)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_NAME, required = false)
	public String getFCReportName() {
		return getProperty(PROPERTY_FCREPORT_NAME);
	}

	/**
	 * @param value Наименование отчета
	 */
	public void setFCReportName(String value) {
		setProperty(PROPERTY_FCREPORT_NAME, value);
	}
	/**
	 * @return Системное наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_SYS_NAME, required = false)
	public String getFCReportSysName() {
		return getProperty(PROPERTY_FCREPORT_SYS_NAME);
	}

	/**
	 * @param value Системное наименование отчета
	 */
	public void setFCReportSysName(String value) {
		setProperty(PROPERTY_FCREPORT_SYS_NAME, value);
	}
	/**
	 * @return Формат файла, в котором будет сохранен отчет. Возможные значения:<br>
	 *	1 - xls;<br>
	 *	2 - pdf;<br>
	 *	3 - rtf.
	 */
	@XmlElement(name = PROPERTY_FILE_FORMAT, required = false)
	public Integer getFileFormat() {
		return getProperty(PROPERTY_FILE_FORMAT);
	}

	/**
	 * @param value Формат файла, в котором будет сохранен отчет. Возможные значения:<br>
	 *	1 - xls;<br>
	 *	2 - pdf;<br>
	 *	3 - rtf.
	 */
	public void setFileFormat(Integer value) {
		setProperty(PROPERTY_FILE_FORMAT, value);
	}
	/**
	 * @return Флаг удаления данных, загруженных для экземпляра отчета
	 */
	@XmlElement(name = PROPERTY_DELETE_DATA_FLAG, required = false)
	public Boolean getDeleteDataFlag() {
		return getProperty(PROPERTY_DELETE_DATA_FLAG);
	}

	/**
	 * @param value Флаг удаления данных, загруженных для экземпляра отчета
	 */
	public void setDeleteDataFlag(Boolean value) {
		setProperty(PROPERTY_DELETE_DATA_FLAG, value);
	}
	/**
	 * @return Путь и наименование файла шаблона отчета
	 */
	@XmlElement(name = PROPERTY_TEMPLATE_PATH_NAME, required = false)
	public String getTemplatePathName() {
		return getProperty(PROPERTY_TEMPLATE_PATH_NAME);
	}

	/**
	 * @param value Путь и наименование файла шаблона отчета
	 */
	public void setTemplatePathName(String value) {
		setProperty(PROPERTY_TEMPLATE_PATH_NAME, value);
	}
	/**
	 * @return Путь и наименование конфигурационного файла
	 */
	@XmlElement(name = PROPERTY_CONFIG_PATH_NAME, required = false)
	public String getConfigPathName() {
		return getProperty(PROPERTY_CONFIG_PATH_NAME);
	}

	/**
	 * @param value Путь и наименование конфигурационного файла
	 */
	public void setConfigPathName(String value) {
		setProperty(PROPERTY_CONFIG_PATH_NAME, value);
	}
	/**
	 * @return Идентификатор группы отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_GROUP_ID, required = false)
	public Long getFCReportGroupID() {
		return getProperty(PROPERTY_FCREPORT_GROUP_ID);
	}

	/**
	 * @param value Идентификатор группы отчета
	 */
	public void setFCReportGroupID(Long value) {
		setProperty(PROPERTY_FCREPORT_GROUP_ID, value);
	}

}
