package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportID Идентификатор отчета
 * @param FCReportSysName Системное наименование отчета
 * @param InputParametrXMLString Список входящих параметров в строке формата xml
 * @param FCReportFileName Наименование сформированного файла отчета
 * @param ExecutionType Тип построения отчета: 1 - в асинхронном режиме (значение по умолчанию) , 2 - в синхронном режиме.
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportProcessExecuteBuildingReq",
	propOrder = {
		"FCReportID",
		"FCReportSysName",
		"inputParametrXMLString",
		"FCReportFileName",
		"executionType"
	}
)
public class DsFCReportProcessExecuteBuildingReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_FCREPORT_SYS_NAME = "FCReportSysName";
	public static final String PROPERTY_INPUT_PARAMETR_XMLSTRING = "InputParametrXMLString";
	public static final String PROPERTY_FCREPORT_FILE_NAME = "FCReportFileName";
	public static final String PROPERTY_EXECUTION_TYPE = "ExecutionType";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportProcessExecuteBuildingReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_SYS_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETR_XMLSTRING, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_FCREPORT_FILE_NAME, String.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_EXECUTION_TYPE, Integer.class, false, false, false) 
	);

    public DsFCReportProcessExecuteBuildingReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = false)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Системное наименование отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_SYS_NAME, required = false)
	public String getFCReportSysName() {
		return getProperty(PROPERTY_FCREPORT_SYS_NAME);
	}

	/**
	 * @param value Системное наименование отчета
	 */
	public void setFCReportSysName(String value) {
		setProperty(PROPERTY_FCREPORT_SYS_NAME, value);
	}
	/**
	 * @return Список входящих параметров в строке формата xml
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETR_XMLSTRING, required = false)
	public String getInputParametrXMLString() {
		return getProperty(PROPERTY_INPUT_PARAMETR_XMLSTRING);
	}

	/**
	 * @param value Список входящих параметров в строке формата xml
	 */
	public void setInputParametrXMLString(String value) {
		setProperty(PROPERTY_INPUT_PARAMETR_XMLSTRING, value);
	}
	/**
	 * @return Наименование сформированного файла отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_FILE_NAME, required = true)
	public String getFCReportFileName() {
		return getProperty(PROPERTY_FCREPORT_FILE_NAME);
	}

	/**
	 * @param value Наименование сформированного файла отчета
	 */
	public void setFCReportFileName(String value) {
		setProperty(PROPERTY_FCREPORT_FILE_NAME, value);
	}
	/**
	 * @return Тип построения отчета: 1 - в асинхронном режиме (значение по умолчанию) , 2 - в синхронном режиме.
	 */
	@XmlElement(name = PROPERTY_EXECUTION_TYPE, required = false)
	public Integer getExecutionType() {
		return getProperty(PROPERTY_EXECUTION_TYPE);
	}

	/**
	 * @param value Тип построения отчета: 1 - в асинхронном режиме (значение по умолчанию) , 2 - в синхронном режиме.
	 */
	public void setExecutionType(Integer value) {
		setProperty(PROPERTY_EXECUTION_TYPE, value);
	}

}
