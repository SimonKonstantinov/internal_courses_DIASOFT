package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InstanceID Идентификатор экземпляра запуска отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TInstanceIDListTypeForDSFCReportMassDeleteInstance",
	propOrder = {
		"instanceID"
	}
)
public class TInstanceIDListTypeForDSFCReportMassDeleteInstance extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INSTANCE_ID = "InstanceID";

	private static final MetaObject INFO = new MetaObject(
		TInstanceIDListTypeForDSFCReportMassDeleteInstance.class.getName(),
		new MetaObjectAttribute(PROPERTY_INSTANCE_ID, Long.class, false, true, false) 
	);

    public TInstanceIDListTypeForDSFCReportMassDeleteInstance() {
		super(INFO);
	}

	/**
	 * @return Идентификатор экземпляра запуска отчета
	 */
	@XmlElement(name = PROPERTY_INSTANCE_ID, required = true)
	public Long getInstanceID() {
		return getProperty(PROPERTY_INSTANCE_ID);
	}

	/**
	 * @param value Идентификатор экземпляра запуска отчета
	 */
	public void setInstanceID(Long value) {
		setProperty(PROPERTY_INSTANCE_ID, value);
	}

}
