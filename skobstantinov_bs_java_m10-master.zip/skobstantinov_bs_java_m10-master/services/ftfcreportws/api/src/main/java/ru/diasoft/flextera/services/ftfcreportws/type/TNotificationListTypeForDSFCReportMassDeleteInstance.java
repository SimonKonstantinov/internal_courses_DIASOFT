package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param NTFID Идентификатор кода ошибки
 * @param NTFMessage Сообщение об ошибке
 * @param InstanceID Идентификатор экземпляра запуска отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "TNotificationListTypeForDSFCReportMassDeleteInstance",
	propOrder = {
		"NTFID",
		"NTFMessage",
		"instanceID"
	}
)
public class TNotificationListTypeForDSFCReportMassDeleteInstance extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_NTFID = "NTFID";
	public static final String PROPERTY_NTFMESSAGE = "NTFMessage";
	public static final String PROPERTY_INSTANCE_ID = "InstanceID";

	private static final MetaObject INFO = new MetaObject(
		TNotificationListTypeForDSFCReportMassDeleteInstance.class.getName(),
		new MetaObjectAttribute(PROPERTY_NTFID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_NTFMESSAGE, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_INSTANCE_ID, Long.class, false, true, false) 
	);

    public TNotificationListTypeForDSFCReportMassDeleteInstance() {
		super(INFO);
	}

	/**
	 * @return Идентификатор кода ошибки
	 */
	@XmlElement(name = PROPERTY_NTFID, required = true)
	public Long getNTFID() {
		return getProperty(PROPERTY_NTFID);
	}

	/**
	 * @param value Идентификатор кода ошибки
	 */
	public void setNTFID(Long value) {
		setProperty(PROPERTY_NTFID, value);
	}
	/**
	 * @return Сообщение об ошибке
	 */
	@XmlElement(name = PROPERTY_NTFMESSAGE, required = false)
	public String getNTFMessage() {
		return getProperty(PROPERTY_NTFMESSAGE);
	}

	/**
	 * @param value Сообщение об ошибке
	 */
	public void setNTFMessage(String value) {
		setProperty(PROPERTY_NTFMESSAGE, value);
	}
	/**
	 * @return Идентификатор экземпляра запуска отчета
	 */
	@XmlElement(name = PROPERTY_INSTANCE_ID, required = true)
	public Long getInstanceID() {
		return getProperty(PROPERTY_INSTANCE_ID);
	}

	/**
	 * @param value Идентификатор экземпляра запуска отчета
	 */
	public void setInstanceID(Long value) {
		setProperty(PROPERTY_INSTANCE_ID, value);
	}

}
