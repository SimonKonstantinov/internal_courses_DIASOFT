package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param InputParametrID Идентификатор входящего параметра метода
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportDeleteInputParametrReq",
	propOrder = {
		"inputParametrID"
	}
)
public class DsFCReportDeleteInputParametrReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_INPUT_PARAMETR_ID = "InputParametrID";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportDeleteInputParametrReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_INPUT_PARAMETR_ID, Long.class, false, true, false) 
	);

    public DsFCReportDeleteInputParametrReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор входящего параметра метода
	 */
	@XmlElement(name = PROPERTY_INPUT_PARAMETR_ID, required = true)
	public Long getInputParametrID() {
		return getProperty(PROPERTY_INPUT_PARAMETR_ID);
	}

	/**
	 * @param value Идентификатор входящего параметра метода
	 */
	public void setInputParametrID(Long value) {
		setProperty(PROPERTY_INPUT_PARAMETR_ID, value);
	}

}
