package ru.diasoft.flextera.services.ftfcreportws.type.response;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param NotificationList Список ошибок
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportMassDeleteInstanceRes",
	propOrder = {
		"notificationList",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportMassDeleteInstanceRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_NOTIFICATION_LIST = "NotificationList";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportMassDeleteInstanceRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_NOTIFICATION_LIST, TNotificationListTypeForDSFCReportMassDeleteInstance.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportMassDeleteInstanceRes() {
		super(INFO);
	}

	/**
	 * @return Список ошибок
	 */
	@XmlElement(name = PROPERTY_NOTIFICATION_LIST, required = false)
	public List<TNotificationListTypeForDSFCReportMassDeleteInstance> getNotificationList() {
		return getProperty(PROPERTY_NOTIFICATION_LIST);
	}

	/**
	 * @param value Список ошибок
	 */
	public void setNotificationList(List<TNotificationListTypeForDSFCReportMassDeleteInstance> value) {
		setProperty(PROPERTY_NOTIFICATION_LIST, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
