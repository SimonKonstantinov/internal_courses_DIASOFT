package ru.diasoft.flextera.services.ftfcreportws.type.response;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportIDList Список идентификаторов отчетов
 * @param NotificationList Список ошибок
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportMassInsertRes",
	propOrder = {
		"FCReportIDList",
		"notificationList",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportMassInsertRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_IDLIST = "FCReportIDList";
	public static final String PROPERTY_NOTIFICATION_LIST = "NotificationList";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportMassInsertRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_IDLIST, TFCReportIDListTypeForDSFCReportMassInsert.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_NOTIFICATION_LIST, TNotificationListTypeForDSFCReportMassInsert.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportMassInsertRes() {
		super(INFO);
	}

	/**
	 * @return Список идентификаторов отчетов
	 */
	@XmlElement(name = PROPERTY_FCREPORT_IDLIST, required = false)
	public List<TFCReportIDListTypeForDSFCReportMassInsert> getFCReportIDList() {
		return getProperty(PROPERTY_FCREPORT_IDLIST);
	}

	/**
	 * @param value Список идентификаторов отчетов
	 */
	public void setFCReportIDList(List<TFCReportIDListTypeForDSFCReportMassInsert> value) {
		setProperty(PROPERTY_FCREPORT_IDLIST, value);
	}
	/**
	 * @return Список ошибок
	 */
	@XmlElement(name = PROPERTY_NOTIFICATION_LIST, required = false)
	public List<TNotificationListTypeForDSFCReportMassInsert> getNotificationList() {
		return getProperty(PROPERTY_NOTIFICATION_LIST);
	}

	/**
	 * @param value Список ошибок
	 */
	public void setNotificationList(List<TNotificationListTypeForDSFCReportMassInsert> value) {
		setProperty(PROPERTY_NOTIFICATION_LIST, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
