package ru.diasoft.flextera.services.ftfcreportws.type;
import javax.xml.bind.*;
import javax.xml.bind.annotation.*;
import javax.xml.namespace.*;



@XmlRegistry
public class ObjectFactory 
{
    private final static String NAME_SPACE = "http://support.diasoft.ru/type";


    private final static QName _TFCReportListTypeForDSFCReportMassInsert_QNAME = new QName(NAME_SPACE, "TFCReportListTypeForDSFCReportMassInsert", "type");

    private final static QName _TFCReportIDListTypeForDSFCReportMassInsert_QNAME = new QName(NAME_SPACE, "TFCReportIDListTypeForDSFCReportMassInsert", "type");

    private final static QName _TNotificationListTypeForDSFCReportMassInsert_QNAME = new QName(NAME_SPACE, "TNotificationListTypeForDSFCReportMassInsert", "type");

    private final static QName _TFCReportBrowseListTypeForDSFCReportBrowseListByParam_QNAME = new QName(NAME_SPACE, "TFCReportBrowseListTypeForDSFCReportBrowseListByParam", "type");

    private final static QName _TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam_QNAME = new QName(NAME_SPACE, "TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam", "type");

    private final static QName _TInputParamterListTypeForDSFCReportFindInputParameterListByReportID_QNAME = new QName(NAME_SPACE, "TInputParamterListTypeForDSFCReportFindInputParameterListByReportID", "type");

    private final static QName _TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID_QNAME = new QName(NAME_SPACE, "TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID", "type");

    private final static QName _TInstanceIDListTypeForDSFCReportMassDeleteInstance_QNAME = new QName(NAME_SPACE, "TInstanceIDListTypeForDSFCReportMassDeleteInstance", "type");

    private final static QName _TNotificationListTypeForDSFCReportMassDeleteInstance_QNAME = new QName(NAME_SPACE, "TNotificationListTypeForDSFCReportMassDeleteInstance", "type");

    private final static QName _TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam_QNAME = new QName(NAME_SPACE, "TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam", "type");

    public ObjectFactory() 
    {
    }

    public TFCReportListTypeForDSFCReportMassInsert createTFCReportListTypeForDSFCReportMassInsert() 
    {
        return new TFCReportListTypeForDSFCReportMassInsert();
    }

    public TFCReportIDListTypeForDSFCReportMassInsert createTFCReportIDListTypeForDSFCReportMassInsert() 
    {
        return new TFCReportIDListTypeForDSFCReportMassInsert();
    }

    public TNotificationListTypeForDSFCReportMassInsert createTNotificationListTypeForDSFCReportMassInsert() 
    {
        return new TNotificationListTypeForDSFCReportMassInsert();
    }

    public TFCReportBrowseListTypeForDSFCReportBrowseListByParam createTFCReportBrowseListTypeForDSFCReportBrowseListByParam() 
    {
        return new TFCReportBrowseListTypeForDSFCReportBrowseListByParam();
    }

    public TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam createTInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam() 
    {
        return new TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam();
    }

    public TInputParamterListTypeForDSFCReportFindInputParameterListByReportID createTInputParamterListTypeForDSFCReportFindInputParameterListByReportID() 
    {
        return new TInputParamterListTypeForDSFCReportFindInputParameterListByReportID();
    }

    public TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID createTParameterKeyListTypeForDSFCReportFindInputParameterListByReportID() 
    {
        return new TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID();
    }

    public TInstanceIDListTypeForDSFCReportMassDeleteInstance createTInstanceIDListTypeForDSFCReportMassDeleteInstance() 
    {
        return new TInstanceIDListTypeForDSFCReportMassDeleteInstance();
    }

    public TNotificationListTypeForDSFCReportMassDeleteInstance createTNotificationListTypeForDSFCReportMassDeleteInstance() 
    {
        return new TNotificationListTypeForDSFCReportMassDeleteInstance();
    }

    public TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam createTFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam() 
    {
        return new TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam();
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TFCReportListTypeForDSFCReportMassInsert"
    )
    public JAXBElement<TFCReportListTypeForDSFCReportMassInsert> createTFCReportListTypeForDSFCReportMassInsert(TFCReportListTypeForDSFCReportMassInsert value) 
    {
        return new JAXBElement<TFCReportListTypeForDSFCReportMassInsert>(_TFCReportListTypeForDSFCReportMassInsert_QNAME, TFCReportListTypeForDSFCReportMassInsert.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TFCReportIDListTypeForDSFCReportMassInsert"
    )
    public JAXBElement<TFCReportIDListTypeForDSFCReportMassInsert> createTFCReportIDListTypeForDSFCReportMassInsert(TFCReportIDListTypeForDSFCReportMassInsert value) 
    {
        return new JAXBElement<TFCReportIDListTypeForDSFCReportMassInsert>(_TFCReportIDListTypeForDSFCReportMassInsert_QNAME, TFCReportIDListTypeForDSFCReportMassInsert.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TNotificationListTypeForDSFCReportMassInsert"
    )
    public JAXBElement<TNotificationListTypeForDSFCReportMassInsert> createTNotificationListTypeForDSFCReportMassInsert(TNotificationListTypeForDSFCReportMassInsert value) 
    {
        return new JAXBElement<TNotificationListTypeForDSFCReportMassInsert>(_TNotificationListTypeForDSFCReportMassInsert_QNAME, TNotificationListTypeForDSFCReportMassInsert.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TFCReportBrowseListTypeForDSFCReportBrowseListByParam"
    )
    public JAXBElement<TFCReportBrowseListTypeForDSFCReportBrowseListByParam> createTFCReportBrowseListTypeForDSFCReportBrowseListByParam(TFCReportBrowseListTypeForDSFCReportBrowseListByParam value) 
    {
        return new JAXBElement<TFCReportBrowseListTypeForDSFCReportBrowseListByParam>(_TFCReportBrowseListTypeForDSFCReportBrowseListByParam_QNAME, TFCReportBrowseListTypeForDSFCReportBrowseListByParam.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam"
    )
    public JAXBElement<TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam> createTInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam(TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam value) 
    {
        return new JAXBElement<TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam>(_TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam_QNAME, TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TInputParamterListTypeForDSFCReportFindInputParameterListByReportID"
    )
    public JAXBElement<TInputParamterListTypeForDSFCReportFindInputParameterListByReportID> createTInputParamterListTypeForDSFCReportFindInputParameterListByReportID(TInputParamterListTypeForDSFCReportFindInputParameterListByReportID value) 
    {
        return new JAXBElement<TInputParamterListTypeForDSFCReportFindInputParameterListByReportID>(_TInputParamterListTypeForDSFCReportFindInputParameterListByReportID_QNAME, TInputParamterListTypeForDSFCReportFindInputParameterListByReportID.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID"
    )
    public JAXBElement<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID> createTParameterKeyListTypeForDSFCReportFindInputParameterListByReportID(TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID value) 
    {
        return new JAXBElement<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID>(_TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID_QNAME, TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TInstanceIDListTypeForDSFCReportMassDeleteInstance"
    )
    public JAXBElement<TInstanceIDListTypeForDSFCReportMassDeleteInstance> createTInstanceIDListTypeForDSFCReportMassDeleteInstance(TInstanceIDListTypeForDSFCReportMassDeleteInstance value) 
    {
        return new JAXBElement<TInstanceIDListTypeForDSFCReportMassDeleteInstance>(_TInstanceIDListTypeForDSFCReportMassDeleteInstance_QNAME, TInstanceIDListTypeForDSFCReportMassDeleteInstance.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TNotificationListTypeForDSFCReportMassDeleteInstance"
    )
    public JAXBElement<TNotificationListTypeForDSFCReportMassDeleteInstance> createTNotificationListTypeForDSFCReportMassDeleteInstance(TNotificationListTypeForDSFCReportMassDeleteInstance value) 
    {
        return new JAXBElement<TNotificationListTypeForDSFCReportMassDeleteInstance>(_TNotificationListTypeForDSFCReportMassDeleteInstance_QNAME, TNotificationListTypeForDSFCReportMassDeleteInstance.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type", 
          name = "TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam"
    )
    public JAXBElement<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam> createTFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam(TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam value) 
    {
        return new JAXBElement<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam>(_TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam_QNAME, TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam.class, null, value);
    }

}
