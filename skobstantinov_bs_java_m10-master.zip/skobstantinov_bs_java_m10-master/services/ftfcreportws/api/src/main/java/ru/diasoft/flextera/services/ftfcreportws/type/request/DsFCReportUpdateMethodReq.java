package ru.diasoft.flextera.services.ftfcreportws.type.request;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param MethodID Идентификатор метода
 * @param MethodName Имя метода
 * @param ServiceName Имя сервиса, в котором реализован метод
 * @param TableList Список таблиц для хранения ответа метода
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportUpdateMethodReq",
	propOrder = {
		"methodID",
		"methodName",
		"serviceName",
		"tableList"
	}
)
public class DsFCReportUpdateMethodReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_METHOD_ID = "MethodID";
	public static final String PROPERTY_METHOD_NAME = "MethodName";
	public static final String PROPERTY_SERVICE_NAME = "ServiceName";
	public static final String PROPERTY_TABLE_LIST = "TableList";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportUpdateMethodReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_METHOD_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_METHOD_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_SERVICE_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_TABLE_LIST, TTableListTypeForDSFCReportUpdateMethod.class, true, false, false) 
	);

    public DsFCReportUpdateMethodReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор метода
	 */
	@XmlElement(name = PROPERTY_METHOD_ID, required = true)
	public Long getMethodID() {
		return getProperty(PROPERTY_METHOD_ID);
	}

	/**
	 * @param value Идентификатор метода
	 */
	public void setMethodID(Long value) {
		setProperty(PROPERTY_METHOD_ID, value);
	}
	/**
	 * @return Имя метода
	 */
	@XmlElement(name = PROPERTY_METHOD_NAME, required = false)
	public String getMethodName() {
		return getProperty(PROPERTY_METHOD_NAME);
	}

	/**
	 * @param value Имя метода
	 */
	public void setMethodName(String value) {
		setProperty(PROPERTY_METHOD_NAME, value);
	}
	/**
	 * @return Имя сервиса, в котором реализован метод
	 */
	@XmlElement(name = PROPERTY_SERVICE_NAME, required = false)
	public String getServiceName() {
		return getProperty(PROPERTY_SERVICE_NAME);
	}

	/**
	 * @param value Имя сервиса, в котором реализован метод
	 */
	public void setServiceName(String value) {
		setProperty(PROPERTY_SERVICE_NAME, value);
	}
	/**
	 * @return Список таблиц для хранения ответа метода
	 */
	@XmlElement(name = PROPERTY_TABLE_LIST, required = false)
	public List<TTableListTypeForDSFCReportUpdateMethod> getTableList() {
		return getProperty(PROPERTY_TABLE_LIST);
	}

	/**
	 * @param value Список таблиц для хранения ответа метода
	 */
	public void setTableList(List<TTableListTypeForDSFCReportUpdateMethod> value) {
		setProperty(PROPERTY_TABLE_LIST, value);
	}

}
