package ru.diasoft.flextera.services.ftfcreportws.type.request;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportList Основные параметры отчета
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportMassInsertReq",
	propOrder = {
		"FCReportList"
	}
)
public class DsFCReportMassInsertReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_LIST = "FCReportList";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportMassInsertReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_LIST, TFCReportListTypeForDSFCReportMassInsert.class, true, true, false) 
	);

    public DsFCReportMassInsertReq() {
		super(INFO);
	}

	/**
	 * @return Основные параметры отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_LIST, required = true)
	public List<TFCReportListTypeForDSFCReportMassInsert> getFCReportList() {
		return getProperty(PROPERTY_FCREPORT_LIST);
	}

	/**
	 * @param value Основные параметры отчета
	 */
	public void setFCReportList(List<TFCReportListTypeForDSFCReportMassInsert> value) {
		setProperty(PROPERTY_FCREPORT_LIST, value);
	}

}
