package ru.diasoft.flextera.services.ftfcreportws.type.response;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param TOTALCOUNT Общее количество найденных записей
 * @param Result Основная информация о группах отчетов
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportGroupBrowseListByParamRes",
	propOrder = {
		"TOTALCOUNT",
		"result",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportGroupBrowseListByParamRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_TOTALCOUNT = "TOTALCOUNT";
	public static final String PROPERTY_RESULT = "Result";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportGroupBrowseListByParamRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_TOTALCOUNT, Integer.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_RESULT, TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportGroupBrowseListByParamRes() {
		super(INFO);
	}

	/**
	 * @return Общее количество найденных записей
	 */
	@XmlElement(name = PROPERTY_TOTALCOUNT, required = true)
	public Integer getTOTALCOUNT() {
		return getProperty(PROPERTY_TOTALCOUNT);
	}

	/**
	 * @param value Общее количество найденных записей
	 */
	public void setTOTALCOUNT(Integer value) {
		setProperty(PROPERTY_TOTALCOUNT, value);
	}
	/**
	 * @return Основная информация о группах отчетов
	 */
	@XmlElement(name = PROPERTY_RESULT, required = false)
	public List<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam> getResult() {
		return getProperty(PROPERTY_RESULT);
	}

	/**
	 * @param value Основная информация о группах отчетов
	 */
	public void setResult(List<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam> value) {
		setProperty(PROPERTY_RESULT, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
