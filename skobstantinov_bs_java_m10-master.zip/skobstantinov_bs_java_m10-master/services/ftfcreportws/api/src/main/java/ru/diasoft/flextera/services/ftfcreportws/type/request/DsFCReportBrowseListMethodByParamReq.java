package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param FCReportID Идентификатор отчета
 * @param MethodID Идентификатор метода
 * @param ServiceName Имя сервиса, в котором реализован метод
 * @param MethodName Имя метода
 * @param PAGE Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
 * @param ROWSCOUNT Число записей на страницу для постраничной разбивки. По умолчанию 10
 * @param ORDERBY Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportBrowseListMethodByParamReq",
	propOrder = {
		"FCReportID",
		"methodID",
		"serviceName",
		"methodName",
		"PAGE",
		"ROWSCOUNT",
		"ORDERBY"
	}
)
public class DsFCReportBrowseListMethodByParamReq extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_FCREPORT_ID = "FCReportID";
	public static final String PROPERTY_METHOD_ID = "MethodID";
	public static final String PROPERTY_SERVICE_NAME = "ServiceName";
	public static final String PROPERTY_METHOD_NAME = "MethodName";
	public static final String PROPERTY_PAGE = "PAGE";
	public static final String PROPERTY_ROWSCOUNT = "ROWSCOUNT";
	public static final String PROPERTY_ORDERBY = "ORDERBY";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportBrowseListMethodByParamReq.class.getName(),
		new MetaObjectAttribute(PROPERTY_FCREPORT_ID, Long.class, false, true, false), 
		new MetaObjectAttribute(PROPERTY_METHOD_ID, Long.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_SERVICE_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_METHOD_NAME, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_PAGE, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_ROWSCOUNT, Integer.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_ORDERBY, String.class, false, false, false) 
	);

    public DsFCReportBrowseListMethodByParamReq() {
		super(INFO);
	}

	/**
	 * @return Идентификатор отчета
	 */
	@XmlElement(name = PROPERTY_FCREPORT_ID, required = true)
	public Long getFCReportID() {
		return getProperty(PROPERTY_FCREPORT_ID);
	}

	/**
	 * @param value Идентификатор отчета
	 */
	public void setFCReportID(Long value) {
		setProperty(PROPERTY_FCREPORT_ID, value);
	}
	/**
	 * @return Идентификатор метода
	 */
	@XmlElement(name = PROPERTY_METHOD_ID, required = false)
	public Long getMethodID() {
		return getProperty(PROPERTY_METHOD_ID);
	}

	/**
	 * @param value Идентификатор метода
	 */
	public void setMethodID(Long value) {
		setProperty(PROPERTY_METHOD_ID, value);
	}
	/**
	 * @return Имя сервиса, в котором реализован метод
	 */
	@XmlElement(name = PROPERTY_SERVICE_NAME, required = false)
	public String getServiceName() {
		return getProperty(PROPERTY_SERVICE_NAME);
	}

	/**
	 * @param value Имя сервиса, в котором реализован метод
	 */
	public void setServiceName(String value) {
		setProperty(PROPERTY_SERVICE_NAME, value);
	}
	/**
	 * @return Имя метода
	 */
	@XmlElement(name = PROPERTY_METHOD_NAME, required = false)
	public String getMethodName() {
		return getProperty(PROPERTY_METHOD_NAME);
	}

	/**
	 * @param value Имя метода
	 */
	public void setMethodName(String value) {
		setProperty(PROPERTY_METHOD_NAME, value);
	}
	/**
	 * @return Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 */
	@XmlElement(name = PROPERTY_PAGE, required = false)
	public Integer getPAGE() {
		return getProperty(PROPERTY_PAGE);
	}

	/**
	 * @param value Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 */
	public void setPAGE(Integer value) {
		setProperty(PROPERTY_PAGE, value);
	}
	/**
	 * @return Число записей на страницу для постраничной разбивки. По умолчанию 10
	 */
	@XmlElement(name = PROPERTY_ROWSCOUNT, required = false)
	public Integer getROWSCOUNT() {
		return getProperty(PROPERTY_ROWSCOUNT);
	}

	/**
	 * @param value Число записей на страницу для постраничной разбивки. По умолчанию 10
	 */
	public void setROWSCOUNT(Integer value) {
		setProperty(PROPERTY_ROWSCOUNT, value);
	}
	/**
	 * @return Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 */
	@XmlElement(name = PROPERTY_ORDERBY, required = false)
	public String getORDERBY() {
		return getProperty(PROPERTY_ORDERBY);
	}

	/**
	 * @param value Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 */
	public void setORDERBY(String value) {
		setProperty(PROPERTY_ORDERBY, value);
	}

}
