package ru.diasoft.flextera.services.ftfcreportws.type.request;
import javax.xml.bind.*;
import javax.xml.bind.annotation.*;
import javax.xml.namespace.*;



@XmlRegistry
public class ObjectFactory 
{
    private final static String NAME_SPACE = "http://support.diasoft.ru/type/request";


    private final static QName _DsFCReportProcessExecuteBuildingReq_QNAME = new QName(NAME_SPACE, "DsFCReportProcessExecuteBuildingReq", "request");

    private final static QName _DsFCReportMassInsertReq_QNAME = new QName(NAME_SPACE, "DsFCReportMassInsertReq", "request");

    private final static QName _DsFCReportDeleteReq_QNAME = new QName(NAME_SPACE, "DsFCReportDeleteReq", "request");

    private final static QName _DsFCReportUpdateReq_QNAME = new QName(NAME_SPACE, "DsFCReportUpdateReq", "request");

    private final static QName _DsFCReportBrowseListByParamReq_QNAME = new QName(NAME_SPACE, "DsFCReportBrowseListByParamReq", "request");

    private final static QName _DsFCReportFindByIDReq_QNAME = new QName(NAME_SPACE, "DsFCReportFindByIDReq", "request");

    private final static QName _DsFCReportBrowseListInstanceByParamReq_QNAME = new QName(NAME_SPACE, "DsFCReportBrowseListInstanceByParamReq", "request");

    private final static QName _DsFCReportFindInputParameterListByReportIDReq_QNAME = new QName(NAME_SPACE, "DsFCReportFindInputParameterListByReportIDReq", "request");

    private final static QName _DsFCReportFindProtocolByInstanceIDReq_QNAME = new QName(NAME_SPACE, "DsFCReportFindProtocolByInstanceIDReq", "request");

    private final static QName _DsFCReportMassDeleteInstanceReq_QNAME = new QName(NAME_SPACE, "DsFCReportMassDeleteInstanceReq", "request");

    private final static QName _DsFCReportGroupInsertReq_QNAME = new QName(NAME_SPACE, "DsFCReportGroupInsertReq", "request");

    private final static QName _DsFCReportGroupUpdateReq_QNAME = new QName(NAME_SPACE, "DsFCReportGroupUpdateReq", "request");

    private final static QName _DsFCReportGroupDeleteReq_QNAME = new QName(NAME_SPACE, "DsFCReportGroupDeleteReq", "request");

    private final static QName _DsFCReportGroupFindByIDReq_QNAME = new QName(NAME_SPACE, "DsFCReportGroupFindByIDReq", "request");

    private final static QName _DsFCReportGroupBrowseListByParamReq_QNAME = new QName(NAME_SPACE, "DsFCReportGroupBrowseListByParamReq", "request");

    private final static QName _DsOnAfterFCReportExecuteBuildingReq_QNAME = new QName(NAME_SPACE, "DsOnAfterFCReportExecuteBuildingReq", "request");

    public ObjectFactory() 
    {
    }

    public DsFCReportProcessExecuteBuildingReq createDsFCReportProcessExecuteBuildingReq() 
    {
        return new DsFCReportProcessExecuteBuildingReq();
    }

    public DsFCReportMassInsertReq createDsFCReportMassInsertReq() 
    {
        return new DsFCReportMassInsertReq();
    }

    public DsFCReportDeleteReq createDsFCReportDeleteReq() 
    {
        return new DsFCReportDeleteReq();
    }

    public DsFCReportUpdateReq createDsFCReportUpdateReq() 
    {
        return new DsFCReportUpdateReq();
    }

    public DsFCReportBrowseListByParamReq createDsFCReportBrowseListByParamReq() 
    {
        return new DsFCReportBrowseListByParamReq();
    }

    public DsFCReportFindByIDReq createDsFCReportFindByIDReq() 
    {
        return new DsFCReportFindByIDReq();
    }

    public DsFCReportBrowseListInstanceByParamReq createDsFCReportBrowseListInstanceByParamReq() 
    {
        return new DsFCReportBrowseListInstanceByParamReq();
    }

    public DsFCReportFindInputParameterListByReportIDReq createDsFCReportFindInputParameterListByReportIDReq() 
    {
        return new DsFCReportFindInputParameterListByReportIDReq();
    }

    public DsFCReportFindProtocolByInstanceIDReq createDsFCReportFindProtocolByInstanceIDReq() 
    {
        return new DsFCReportFindProtocolByInstanceIDReq();
    }

    public DsFCReportMassDeleteInstanceReq createDsFCReportMassDeleteInstanceReq() 
    {
        return new DsFCReportMassDeleteInstanceReq();
    }

    public DsFCReportGroupInsertReq createDsFCReportGroupInsertReq() 
    {
        return new DsFCReportGroupInsertReq();
    }

    public DsFCReportGroupUpdateReq createDsFCReportGroupUpdateReq() 
    {
        return new DsFCReportGroupUpdateReq();
    }

    public DsFCReportGroupDeleteReq createDsFCReportGroupDeleteReq() 
    {
        return new DsFCReportGroupDeleteReq();
    }

    public DsFCReportGroupFindByIDReq createDsFCReportGroupFindByIDReq() 
    {
        return new DsFCReportGroupFindByIDReq();
    }

    public DsFCReportGroupBrowseListByParamReq createDsFCReportGroupBrowseListByParamReq() 
    {
        return new DsFCReportGroupBrowseListByParamReq();
    }

    public DsOnAfterFCReportExecuteBuildingReq createDsOnAfterFCReportExecuteBuildingReq() 
    {
        return new DsOnAfterFCReportExecuteBuildingReq();
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportProcessExecuteBuildingReq"
    )
    public JAXBElement<DsFCReportProcessExecuteBuildingReq> createDsFCReportProcessExecuteBuildingReq(DsFCReportProcessExecuteBuildingReq value) 
    {
        return new JAXBElement<DsFCReportProcessExecuteBuildingReq>(_DsFCReportProcessExecuteBuildingReq_QNAME, DsFCReportProcessExecuteBuildingReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportMassInsertReq"
    )
    public JAXBElement<DsFCReportMassInsertReq> createDsFCReportMassInsertReq(DsFCReportMassInsertReq value) 
    {
        return new JAXBElement<DsFCReportMassInsertReq>(_DsFCReportMassInsertReq_QNAME, DsFCReportMassInsertReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportDeleteReq"
    )
    public JAXBElement<DsFCReportDeleteReq> createDsFCReportDeleteReq(DsFCReportDeleteReq value) 
    {
        return new JAXBElement<DsFCReportDeleteReq>(_DsFCReportDeleteReq_QNAME, DsFCReportDeleteReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportUpdateReq"
    )
    public JAXBElement<DsFCReportUpdateReq> createDsFCReportUpdateReq(DsFCReportUpdateReq value) 
    {
        return new JAXBElement<DsFCReportUpdateReq>(_DsFCReportUpdateReq_QNAME, DsFCReportUpdateReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportBrowseListByParamReq"
    )
    public JAXBElement<DsFCReportBrowseListByParamReq> createDsFCReportBrowseListByParamReq(DsFCReportBrowseListByParamReq value) 
    {
        return new JAXBElement<DsFCReportBrowseListByParamReq>(_DsFCReportBrowseListByParamReq_QNAME, DsFCReportBrowseListByParamReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportFindByIDReq"
    )
    public JAXBElement<DsFCReportFindByIDReq> createDsFCReportFindByIDReq(DsFCReportFindByIDReq value) 
    {
        return new JAXBElement<DsFCReportFindByIDReq>(_DsFCReportFindByIDReq_QNAME, DsFCReportFindByIDReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportBrowseListInstanceByParamReq"
    )
    public JAXBElement<DsFCReportBrowseListInstanceByParamReq> createDsFCReportBrowseListInstanceByParamReq(DsFCReportBrowseListInstanceByParamReq value) 
    {
        return new JAXBElement<DsFCReportBrowseListInstanceByParamReq>(_DsFCReportBrowseListInstanceByParamReq_QNAME, DsFCReportBrowseListInstanceByParamReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportFindInputParameterListByReportIDReq"
    )
    public JAXBElement<DsFCReportFindInputParameterListByReportIDReq> createDsFCReportFindInputParameterListByReportIDReq(DsFCReportFindInputParameterListByReportIDReq value) 
    {
        return new JAXBElement<DsFCReportFindInputParameterListByReportIDReq>(_DsFCReportFindInputParameterListByReportIDReq_QNAME, DsFCReportFindInputParameterListByReportIDReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportFindProtocolByInstanceIDReq"
    )
    public JAXBElement<DsFCReportFindProtocolByInstanceIDReq> createDsFCReportFindProtocolByInstanceIDReq(DsFCReportFindProtocolByInstanceIDReq value) 
    {
        return new JAXBElement<DsFCReportFindProtocolByInstanceIDReq>(_DsFCReportFindProtocolByInstanceIDReq_QNAME, DsFCReportFindProtocolByInstanceIDReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportMassDeleteInstanceReq"
    )
    public JAXBElement<DsFCReportMassDeleteInstanceReq> createDsFCReportMassDeleteInstanceReq(DsFCReportMassDeleteInstanceReq value) 
    {
        return new JAXBElement<DsFCReportMassDeleteInstanceReq>(_DsFCReportMassDeleteInstanceReq_QNAME, DsFCReportMassDeleteInstanceReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportGroupInsertReq"
    )
    public JAXBElement<DsFCReportGroupInsertReq> createDsFCReportGroupInsertReq(DsFCReportGroupInsertReq value) 
    {
        return new JAXBElement<DsFCReportGroupInsertReq>(_DsFCReportGroupInsertReq_QNAME, DsFCReportGroupInsertReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportGroupUpdateReq"
    )
    public JAXBElement<DsFCReportGroupUpdateReq> createDsFCReportGroupUpdateReq(DsFCReportGroupUpdateReq value) 
    {
        return new JAXBElement<DsFCReportGroupUpdateReq>(_DsFCReportGroupUpdateReq_QNAME, DsFCReportGroupUpdateReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportGroupDeleteReq"
    )
    public JAXBElement<DsFCReportGroupDeleteReq> createDsFCReportGroupDeleteReq(DsFCReportGroupDeleteReq value) 
    {
        return new JAXBElement<DsFCReportGroupDeleteReq>(_DsFCReportGroupDeleteReq_QNAME, DsFCReportGroupDeleteReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportGroupFindByIDReq"
    )
    public JAXBElement<DsFCReportGroupFindByIDReq> createDsFCReportGroupFindByIDReq(DsFCReportGroupFindByIDReq value) 
    {
        return new JAXBElement<DsFCReportGroupFindByIDReq>(_DsFCReportGroupFindByIDReq_QNAME, DsFCReportGroupFindByIDReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsFCReportGroupBrowseListByParamReq"
    )
    public JAXBElement<DsFCReportGroupBrowseListByParamReq> createDsFCReportGroupBrowseListByParamReq(DsFCReportGroupBrowseListByParamReq value) 
    {
        return new JAXBElement<DsFCReportGroupBrowseListByParamReq>(_DsFCReportGroupBrowseListByParamReq_QNAME, DsFCReportGroupBrowseListByParamReq.class, null, value);
    }

    @XmlElementDecl(
          namespace = "http://support.diasoft.ru/type/request", 
          name = "DsOnAfterFCReportExecuteBuildingReq"
    )
    public JAXBElement<DsOnAfterFCReportExecuteBuildingReq> createDsOnAfterFCReportExecuteBuildingReq(DsOnAfterFCReportExecuteBuildingReq value) 
    {
        return new JAXBElement<DsOnAfterFCReportExecuteBuildingReq>(_DsOnAfterFCReportExecuteBuildingReq_QNAME, DsOnAfterFCReportExecuteBuildingReq.class, null, value);
    }

}
