@javax.xml.bind.annotation.XmlSchema(
         namespace = "http://support.diasoft.ru/type/request", 
         elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED
)
package ru.diasoft.flextera.services.ftfcreportws.type.request;