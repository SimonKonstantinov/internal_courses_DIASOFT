package ru.diasoft.flextera.services.ftfcreportws.type.response;
import java.util.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.core.application.dto.*;
import ru.diasoft.core.application.dto.meta.*;
import ru.diasoft.flextera.services.ftfcreportws.type.*;


import ru.diasoft.core.application.dto.Linkable;
import ru.diasoft.core.application.dto.TypeConverter;

/**
 * @param HistoryMessageList Сообщения истории запуска отчета
 * @param ReturnMsg Сообщение
 * @param ReturnCode Код
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(
	name = "DsFCReportHistoryGetByIDRes",
	propOrder = {
		"historyMessageList",
		"returnMsg",
		"returnCode"
	}
)
public class DsFCReportHistoryGetByIDRes extends AbstractTransferObject {

	private static final long serialVersionUID = 1L;

	public static final String PROPERTY_HISTORY_MESSAGE_LIST = "HistoryMessageList";
	public static final String PROPERTY_RETURN_MSG = "ReturnMsg";
	public static final String PROPERTY_RETURN_CODE = "ReturnCode";

	private static final MetaObject INFO = new MetaObject(
		DsFCReportHistoryGetByIDRes.class.getName(),
		new MetaObjectAttribute(PROPERTY_HISTORY_MESSAGE_LIST, THistoryMessageListDSFCReportHistoryGetByID.class, true, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_MSG, String.class, false, false, false), 
		new MetaObjectAttribute(PROPERTY_RETURN_CODE, Long.class, false, false, false) 
	);

    public DsFCReportHistoryGetByIDRes() {
		super(INFO);
	}

	/**
	 * @return Сообщения истории запуска отчета
	 */
	@XmlElement(name = PROPERTY_HISTORY_MESSAGE_LIST, required = false)
	public List<THistoryMessageListDSFCReportHistoryGetByID> getHistoryMessageList() {
		return getProperty(PROPERTY_HISTORY_MESSAGE_LIST);
	}

	/**
	 * @param value Сообщения истории запуска отчета
	 */
	public void setHistoryMessageList(List<THistoryMessageListDSFCReportHistoryGetByID> value) {
		setProperty(PROPERTY_HISTORY_MESSAGE_LIST, value);
	}
	/**
	 * @return Сообщение
	 */
	@XmlElement(name = PROPERTY_RETURN_MSG, required = false)
	public String getReturnMsg() {
		return getProperty(PROPERTY_RETURN_MSG);
	}

	/**
	 * @param value Сообщение
	 */
	public void setReturnMsg(String value) {
		setProperty(PROPERTY_RETURN_MSG, value);
	}
	/**
	 * @return Код
	 */
	@XmlElement(name = PROPERTY_RETURN_CODE, required = false)
	public Long getReturnCode() {
		return getProperty(PROPERTY_RETURN_CODE);
	}

	/**
	 * @param value Код
	 */
	public void setReturnCode(Long value) {
		setProperty(PROPERTY_RETURN_CODE, value);
	}

}
