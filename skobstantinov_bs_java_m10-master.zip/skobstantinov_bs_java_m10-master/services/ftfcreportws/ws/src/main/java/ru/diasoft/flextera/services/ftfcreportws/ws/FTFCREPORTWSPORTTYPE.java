package ru.diasoft.flextera.services.ftfcreportws.ws;
import javax.jws.*;
import javax.jws.soap.*;
import javax.xml.bind.annotation.*;
import ru.diasoft.flextera.services.ftfcreportws.type.request.*;
import ru.diasoft.flextera.services.ftfcreportws.type.response.*;
import ru.diasoft.flextera.services.type.*;


@WebService(
    name = "FTFCREPORTWSPORTTYPE", 
    targetNamespace = "http://support.diasoft.ru"
)
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@XmlSeeAlso({
    ru.diasoft.flextera.services.ftfcreportws.type.ObjectFactory.class,
    ru.diasoft.flextera.services.ftfcreportws.type.request.ObjectFactory.class,
    ru.diasoft.flextera.services.ftfcreportws.type.response.ObjectFactory.class
    
})
public interface FTFCREPORTWSPORTTYPE 
{
    @WebMethod(operationName="DSCALL", action = "http://support.diasoft.ru/DSCALL")
    @WebResult(name = "DSCALLRESPONSE", targetNamespace = "http://support.diasoft.ru", partName = "commandresult")    
    public DSCALLRESPONSE DSCALL(
    		@WebParam(name = "DSCALL", targetNamespace = "http://support.diasoft.ru", partName = "request")
    		DSCALL request
    ) throws DSCALLFAULTException;

    @WebMethod(operationName="DSCALLASYNC", action = "http://support.diasoft.ru/DSCALLASYNC")
    @Oneway
    public void DSCALLASYNC(
    		@WebParam(name = "DSCALLASYNC", targetNamespace = "http://support.diasoft.ru", partName = "request")
    		DSCALLASYNC request
    );

    @WebMethod(operationName="admModuleInfo", action = "http://support.diasoft.ru/admModuleInfo")
    @WebResult(name = "AdmmoduleinfoRes", targetNamespace = "http://support.diasoft.ru", partName = "response")    
    public AdmmoduleinfoRes admmoduleinfo(
    		@WebParam(name = "Admmoduleinfo", targetNamespace = "http://support.diasoft.ru", partName = "request")
    		Admmoduleinfo request
    ) throws Fault;

    @WebMethod(operationName="getversion", action = "http://support.diasoft.ru/getversion")
    @WebResult(name = "GetVersionRes", targetNamespace = "http://support.diasoft.ru", partName = "response")    
    public GetVersionRes getversion(
    		@WebParam(name = "GetVersion", targetNamespace = "http://support.diasoft.ru", partName = "request")
    		GetVersion request
    ) throws Fault;

    @WebMethod(operationName="getHealthInfo", action = "http://support.diasoft.ru/getHealthInfo")
    @WebResult(name = "GetHealthInfoRes", targetNamespace = "http://support.diasoft.ru", partName = "response")    
    public GetHealthInfoRes getHealthInfo(
    		@WebParam(name = "GetHealthInfo", targetNamespace = "http://support.diasoft.ru", partName = "request")
    		GetHealthInfo request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportMassDeleteInstance", action = "http://support.diasoft.ru/dsFCReportMassDeleteInstance")
    @WebResult(name = "DsFCReportMassDeleteInstanceRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportMassDeleteInstanceRes dsFCReportMassDeleteInstance(
    		@WebParam(name = "DsFCReportMassDeleteInstanceReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportMassDeleteInstanceReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportGroupFindByID", action = "http://support.diasoft.ru/dsFCReportGroupFindByID")
    @WebResult(name = "DsFCReportGroupFindByIDRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportGroupFindByIDRes dsFCReportGroupFindByID(
    		@WebParam(name = "DsFCReportGroupFindByIDReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportGroupFindByIDReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportGroupBrowseListByParam", action = "http://support.diasoft.ru/dsFCReportGroupBrowseListByParam")
    @WebResult(name = "DsFCReportGroupBrowseListByParamRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportGroupBrowseListByParamRes dsFCReportGroupBrowseListByParam(
    		@WebParam(name = "DsFCReportGroupBrowseListByParamReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportGroupBrowseListByParamReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportDelete", action = "http://support.diasoft.ru/dsFCReportDelete")
    @WebResult(name = "DsFCReportDeleteRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportDeleteRes dsFCReportDelete(
    		@WebParam(name = "DsFCReportDeleteReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportDeleteReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportUpdate", action = "http://support.diasoft.ru/dsFCReportUpdate")
    @WebResult(name = "DsFCReportUpdateRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportUpdateRes dsFCReportUpdate(
    		@WebParam(name = "DsFCReportUpdateReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportUpdateReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportBrowseListByParam", action = "http://support.diasoft.ru/dsFCReportBrowseListByParam")
    @WebResult(name = "DsFCReportBrowseListByParamRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportBrowseListByParamRes dsFCReportBrowseListByParam(
    		@WebParam(name = "DsFCReportBrowseListByParamReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportBrowseListByParamReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportFindByID", action = "http://support.diasoft.ru/dsFCReportFindByID")
    @WebResult(name = "DsFCReportFindByIDRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportFindByIDRes dsFCReportFindByID(
    		@WebParam(name = "DsFCReportFindByIDReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportFindByIDReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportBrowseListInstanceByParam", action = "http://support.diasoft.ru/dsFCReportBrowseListInstanceByParam")
    @WebResult(name = "DsFCReportBrowseListInstanceByParamRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportBrowseListInstanceByParamRes dsFCReportBrowseListInstanceByParam(
    		@WebParam(name = "DsFCReportBrowseListInstanceByParamReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportBrowseListInstanceByParamReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportFindInputParameterListByReportID", action = "http://support.diasoft.ru/dsFCReportFindInputParameterListByReportID")
    @WebResult(name = "DsFCReportFindInputParameterListByReportIDRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportFindInputParameterListByReportIDRes dsFCReportFindInputParameterListByReportID(
    		@WebParam(name = "DsFCReportFindInputParameterListByReportIDReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportFindInputParameterListByReportIDReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportFindProtocolByInstanceID", action = "http://support.diasoft.ru/dsFCReportFindProtocolByInstanceID")
    @WebResult(name = "DsFCReportFindProtocolByInstanceIDRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportFindProtocolByInstanceIDRes dsFCReportFindProtocolByInstanceID(
    		@WebParam(name = "DsFCReportFindProtocolByInstanceIDReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportFindProtocolByInstanceIDReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportGroupInsert", action = "http://support.diasoft.ru/dsFCReportGroupInsert")
    @WebResult(name = "DsFCReportGroupInsertRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportGroupInsertRes dsFCReportGroupInsert(
    		@WebParam(name = "DsFCReportGroupInsertReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportGroupInsertReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportGroupUpdate", action = "http://support.diasoft.ru/dsFCReportGroupUpdate")
    @WebResult(name = "DsFCReportGroupUpdateRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportGroupUpdateRes dsFCReportGroupUpdate(
    		@WebParam(name = "DsFCReportGroupUpdateReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportGroupUpdateReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportGroupDelete", action = "http://support.diasoft.ru/dsFCReportGroupDelete")
    @WebResult(name = "DsFCReportGroupDeleteRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportGroupDeleteRes dsFCReportGroupDelete(
    		@WebParam(name = "DsFCReportGroupDeleteReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportGroupDeleteReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportMassInsert", action = "http://support.diasoft.ru/dsFCReportMassInsert")
    @WebResult(name = "DsFCReportMassInsertRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportMassInsertRes dsFCReportMassInsert(
    		@WebParam(name = "DsFCReportMassInsertReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportMassInsertReq request
    ) throws Fault;

    @WebMethod(operationName="dsFCReportProcessExecuteBuilding", action = "http://support.diasoft.ru/dsFCReportProcessExecuteBuilding")
    @WebResult(name = "DsFCReportProcessExecuteBuildingRes", targetNamespace = "http://support.diasoft.ru/type/response", partName = "response")    
    public DsFCReportProcessExecuteBuildingRes dsFCReportProcessExecuteBuilding(
    		@WebParam(name = "DsFCReportProcessExecuteBuildingReq", targetNamespace = "http://support.diasoft.ru/type/request", partName = "request")
    		DsFCReportProcessExecuteBuildingReq request
    ) throws Fault;
 
}
