package ru.diasoft.flextera.services.ftfcreportws.ws;
import java.net.*;
import javax.xml.namespace.*;
import javax.xml.ws.*;
import org.apache.log4j.*;


@WebServiceClient(
      name = "FTFCREPORTWSSERVICE", 
      targetNamespace = "http://support.diasoft.ru", 
      wsdlLocation = "webapp/WEB-INF/wsdl/FTFCREPORTWS.wsdl"
)
public class FTFCREPORTWSSERVICE
       extends Service
{

    private final static URL FTFCREPORTWSSERVICE_WSDL_LOCATION;
    private final static Logger logger = Logger.getLogger(ru.diasoft.flextera.services.ftfcreportws.ws.FTFCREPORTWSSERVICE.class.getName());

    static 
    {
        URL url = null;
        
        try {
            url = ru.diasoft.flextera.services.ftfcreportws.ws.FTFCREPORTWSSERVICE.class.getResource(".");
            url = new URL(url, "webapp/WEB-INF/wsdl/FTFCREPORTWS.wsdl");
        } catch (MalformedURLException e) {
            logger.warn("Failed to create URL for the wsdl Location: " + url == null ? "" : url.toString());
            logger.warn(e.getMessage());
        }
        
        FTFCREPORTWSSERVICE_WSDL_LOCATION = url;
    }

    public FTFCREPORTWSSERVICE(URL wsdlLocation, QName serviceName) 
    {
        super(wsdlLocation, serviceName);
    }

    public FTFCREPORTWSSERVICE() {
        super(
           FTFCREPORTWSSERVICE_WSDL_LOCATION, 
           new QName("http://support.diasoft.ru", 
             "FTFCREPORTWSSERVICE"
           )
        );
    }

    @WebEndpoint(name = "FTFCREPORTWSPORT")
    public FTFCREPORTWSPORTTYPE getFTFCREPORTWSPORT() 
    {
        return super.getPort(
             new QName(
                   "http://support.diasoft.ru", 
                   "FTFCREPORTWSPORT"
                 ), 
             FTFCREPORTWSPORTTYPE.class
        );
    }

    @WebEndpoint(name = "FTFCREPORTWSPORT")
    public FTFCREPORTWSPORTTYPE getFTFCREPORTWSPORT(WebServiceFeature... features) 
    {
        return super.getPort(
             new QName(
                  "http://support.diasoft.ru", 
                  "FTFCREPORTWSPORT"
             ), 
             FTFCREPORTWSPORTTYPE.class, 
             features
        );
    }
}
