
package ru.diasoft.flextera.services.ftfcreportws.ws;

import ru.diasoft.flextera.services.ftfcreportws.type.request.*;
import ru.diasoft.flextera.services.ftfcreportws.type.response.*;
import ru.diasoft.flextera.services.ftfcreportws.utils.context.EnvironmentHolder;
import ru.diasoft.flextera.services.ftfcreportws.utils.context.EnvironmentImpl;
import ru.diasoft.flextera.services.type.*;


import java.rmi.RemoteException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceContext;

import org.apache.log4j.Logger;

import ru.diasoft.commons.logging.LogContext;
import ru.diasoft.commons.logging.LogFactory;
import ru.diasoft.commons.logging.ServiceLogManager;
import ru.diasoft.core.application.AbstractService;
import ru.diasoft.core.application.CommandDispatcher;
import ru.diasoft.core.application.command.CommandContext;
import ru.diasoft.core.application.dto.TransferObject;
import ru.diasoft.core.exception.CommonException;
import ru.diasoft.services.config.Config;
import ru.diasoft.utils.ISessionProviderExt;
import ru.diasoft.utils.XMLUtil;

import static java.lang.System.currentTimeMillis;

@HandlerChain(file = "handler-chain.xml")
@javax.jws.WebService(endpointInterface = "ru.diasoft.flextera.services.ftfcreportws.ws.FTFCREPORTWSPORTTYPE",
		wsdlLocation = "WEB-INF/wsdl/ftfcreportws.wsdl", targetNamespace = "http://support.diasoft.ru")
public class FTFCREPORTWSImpl extends AbstractService 
{
    protected Logger logger = Logger.getLogger(FTFCREPORTWSImpl.class.getName());
    
    @Resource
    WebServiceContext wsContext;
    
    private static final String WSNAME = "FTFCREPORTWS";
    
    private static ThreadLocal<Message<? extends TransferObject>> MESSAGE = new ThreadLocal<Message<? extends TransferObject>>();
    
    private static final Integer THREAD_POOL_SIZE = Integer.valueOf(Config.getConfig(WSNAME).getParam("dscallAsyncThreadPoolSize", "10"));
    
    private static final ExecutorService THREAD_POOL = Executors.newFixedThreadPool(THREAD_POOL_SIZE);

    private ServiceLogManager logManager;
    
    public FTFCREPORTWSImpl() throws CommonException 
    {
    }
    
    public static class Message<Input extends TransferObject> {

        private final Input input;
        private final CommandContext commandContext;

        public Message(Input input, CommandContext commandContext) {
            this.input = input;
            this.commandContext = commandContext; 
        }

        public Input getInput() {
            return input;
        }

        public CommandContext getCommandContext() {
            return commandContext;
        }
    }
    
    private class MessageHandler implements Runnable {

        private final Message<? extends TransferObject> msg;

        public MessageHandler(Message<? extends TransferObject> msg) {
            this.msg = msg;
        }

        public void run() {
            try {
                MESSAGE.set(msg);
                XMLUtil.setThreadSessionProvider(new ISessionProviderExt() {
                	
                	@Override
					public String getSessionId() {
						return msg.getCommandContext().getSessionId();
					}
					
					@Override
					public String getLogin() {
						return msg.getCommandContext().getLogin();
					}
					
					@Override
					public String getTenantKey() {
						return "";
					}
					
					@Override
					public void setTenantKey(String tenantKey) {}
					
					@Override
					public void setSessionIdentifier(String sessionID) {}
				});
                call(msg.getCommandContext(), msg.getInput());
            } catch (Exception e) {
                logger.error("Error occured while processing dscall message asynchronously. CommandContext = "+msg.getCommandContext()+", data = "+msg.getInput(), e);
            } finally {
                MESSAGE.remove();
            }
        }

    }
    
	public void DSCALLASYNC(DSCALLASYNC request) {
		final CommandContext commandContext = getCommandContext(Commands.DSCALLASYNC.getCommandName(), request.getContextData(), wsContext);
		final Message<DSCALLASYNC> msg = new Message<DSCALLASYNC>(request, commandContext);
		removeCommandContext();
		THREAD_POOL.execute(new MessageHandler(msg));
	}

	public DSCALLRESPONSE DSCALL(DSCALL request) throws DSCALLFAULTException {
		try {
			long timeStart = currentTimeMillis();
			final CommandContext commandContext = getCommandContext(Commands.DSCALL.getCommandName(), request.getContextData(), wsContext);
			DSCALLRESPONSE ret = call(commandContext, request);
			long timeFinish = currentTimeMillis();
			System.out.println(timeFinish-timeStart);
			return ret;
		} catch (Fault e) {
			// Fault exception should never be thrown in case of DSCALL. 
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * RMI support for dscall
	 */
	@Override
	public Map<String, Object> dscall(String methodName, Map<String, Object> req) throws RemoteException, Exception {
		XMLUtil util = getCommandContext(methodName, null, wsContext).getXmlUtil();
		DSCALL dsCallReq = new DSCALL();
		dsCallReq.setCommandtext(methodName);
		dsCallReq.setCommanddata(util.createXML(req));
		Map<String, Object> res = null;
		try {
			DSCALLRESPONSE dsCallRes = this.DSCALL(dsCallReq);
			res = dsCallRes.toMap(null);
		} catch(Exception e) {
			res = new HashMap<String, Object>();
			XMLUtil.fillMapWithErrorData(res, e, "500", e.getMessage());
		}
		return res;
	}
	
	/**
	 * RMI support for dscallAsync.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Map<String, Object> dscallAsync(String methodName, Map<String, Object> req) throws RemoteException, Exception {
		XMLUtil util = getCommandContext(methodName, null, wsContext).getXmlUtil();
		DSCALLASYNC dsCallAsyncReq = new DSCALLASYNC();
		dsCallAsyncReq.setCommandtext(methodName);
		dsCallAsyncReq.setCommanddata(util.createXML(req));
		this.DSCALLASYNC(dsCallAsyncReq);
		return Collections.EMPTY_MAP;
	}

	public AdmmoduleinfoRes admmoduleinfo(Admmoduleinfo request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.ADM_MODULE_INFO.getCommandName(), request.getContextData(), wsContext);
		return call(commandContext, request);
	}

	public GetVersionRes getversion(GetVersion request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.GETVERSION.getCommandName(), request.getContextData(), wsContext);
		return call(commandContext, request);
	}

	public GetHealthInfoRes getHealthInfo(GetHealthInfo request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.GET_HEALTH_INFO.getCommandName(), request.getContextData(), wsContext);
		return call(commandContext, request);
	}

	public DsFCReportMassDeleteInstanceRes dsFCReportMassDeleteInstance(DsFCReportMassDeleteInstanceReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_MASS_DELETE_INSTANCE.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportGroupFindByIDRes dsFCReportGroupFindByID(DsFCReportGroupFindByIDReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_GROUP_FIND_BY_ID.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportGroupBrowseListByParamRes dsFCReportGroupBrowseListByParam(DsFCReportGroupBrowseListByParamReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_GROUP_BROWSE_LIST_BY_PARAM.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportDeleteRes dsFCReportDelete(DsFCReportDeleteReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_DELETE.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportUpdateRes dsFCReportUpdate(DsFCReportUpdateReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_UPDATE.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportBrowseListByParamRes dsFCReportBrowseListByParam(DsFCReportBrowseListByParamReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_BROWSE_LIST_BY_PARAM.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportFindByIDRes dsFCReportFindByID(DsFCReportFindByIDReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_FIND_BY_ID.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportBrowseListInstanceByParamRes dsFCReportBrowseListInstanceByParam(DsFCReportBrowseListInstanceByParamReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_BROWSE_LIST_INSTANCE_BY_PARAM.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportFindInputParameterListByReportIDRes dsFCReportFindInputParameterListByReportID(DsFCReportFindInputParameterListByReportIDReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_FIND_INPUT_PARAMETER_LIST_BY_REPORT_ID.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportFindProtocolByInstanceIDRes dsFCReportFindProtocolByInstanceID(DsFCReportFindProtocolByInstanceIDReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_FIND_PROTOCOL_BY_INSTANCE_ID.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportGroupInsertRes dsFCReportGroupInsert(DsFCReportGroupInsertReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_GROUP_INSERT.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportGroupUpdateRes dsFCReportGroupUpdate(DsFCReportGroupUpdateReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_GROUP_UPDATE.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportGroupDeleteRes dsFCReportGroupDelete(DsFCReportGroupDeleteReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_GROUP_DELETE.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportMassInsertRes dsFCReportMassInsert(DsFCReportMassInsertReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_MASS_INSERT.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	public DsFCReportProcessExecuteBuildingRes dsFCReportProcessExecuteBuilding(DsFCReportProcessExecuteBuildingReq request) throws Fault {
		final CommandContext commandContext = getCommandContext(Commands.DS_FCREPORT_PROCESS_EXECUTE_BUILDING.getCommandName(), null, wsContext);
		return call(commandContext, request);
	}

	protected <Input extends TransferObject, Output extends TransferObject>
	Output call(CommandContext commandContext, Input input) throws Fault {
	
	LogContext logContext = null;
	try {
		logContext = LogFactory.getLogContext();
		logContext.put(LogContext.LOGIN_NAME, commandContext.getLogin());
		logContext.put(LogContext.UNIQUE_ID, UUID.randomUUID().toString()); 
		commandContext.setWSName(WSNAME);

		//!!!!!!!!!!!!!! 
		//!!!!!!!!!!!!!! 
		//!!! НЕ УДАЛЯТЬ ЭТОТ КОД ПОСЛЕ ГЕНЕРАЦИИ СЕРВИСА !!!
		EnvironmentHolder.setCurrentContext(new EnvironmentImpl(commandContext));
		//!!!!!!!!!!!!!! 
		//!!!!!!!!!!!!!! 
		//!!!!!!!!!!!!!! 
		
		return CommandDispatcher.<Input, Output>executeCommand(commandContext, input);
	} catch (CommonException e) {
		throw new Fault(e.getErrorCode(), e);
	} finally {
		removeCommandContext();
		if(logContext != null) {
			logContext.remove(LogContext.LOGIN_NAME);
        	logContext.remove(LogContext.UNIQUE_ID);
		}
	}
}
    @PostConstruct 
    public void postInit() {
		FTFCREPORTWSActivator.activate();
		FTFCREPORTWSActivator.startRMI(this);
		logManager = new ServiceLogManager();
        logManager.start();
    }
        
    @PreDestroy
    public void preDestroy() {
		FTFCREPORTWSActivator.deactivate();
		FTFCREPORTWSActivator.stopRMI();
		logManager.stop();
    }    
}
