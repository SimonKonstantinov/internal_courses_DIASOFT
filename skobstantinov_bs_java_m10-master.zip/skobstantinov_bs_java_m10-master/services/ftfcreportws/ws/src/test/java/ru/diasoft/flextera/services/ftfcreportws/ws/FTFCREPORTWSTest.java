
package ru.diasoft.flextera.services.ftfcreportws.ws;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import junit.framework.Assert;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.Transaction;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import ru.diasoft.core.application.CommandDispatcher;
import ru.diasoft.core.application.command.CommandContext;
import ru.diasoft.core.application.dto.TransferObject;
import ru.diasoft.core.application.test.CommonTest;
import ru.diasoft.core.application.test.TestAssertResult;
import ru.diasoft.core.application.test.TestAssertStatus;
import ru.diasoft.core.application.test.TestObject;
import ru.diasoft.core.application.test.TestScenario;
import ru.diasoft.core.application.test.TestScenarioRegistry;
import ru.diasoft.core.exception.CommonException;
import ru.diasoft.core.util.sandbox.Sandbox;
import ru.diasoft.flextera.services.type.Fault;
import ru.diasoft.services.config.Config;

//@Ignore
public class FTFCREPORTWSTest {

	private final static Logger logger = Logger.getLogger(FTFCREPORTWSTest.class);
	private List<TestScenario> scenarios;
	private boolean testFailed = false;
	private static boolean skipAll = false;

	public FTFCREPORTWSTest() throws CommonException {
		
	}
	
	@BeforeClass
	public static void checkConfig() {
		try {
			FTFCREPORTWSActivator.activate();
			Sandbox.INSTANCE.singleProvider(DataContext.class);
		} catch (Exception e) {
			logger.warn("Config for DB connection not set properly");
			logger.debug(e);
			skipAll = true;
		}
	}

	private void init() {
		Config config = Config.getConfig("FTFCREPORTWS");
		Properties properties = new Properties();
		properties.putAll(config.getAllParams());
		try {
			new CommonTest(properties);
		} catch (Exception e) {
			Assert.fail(e.getLocalizedMessage());
		}
	}
	
	private Transaction getTransaction() {
		if (Transaction.getThreadTransaction() == null) {
			DataContext dataContext = Sandbox.INSTANCE.singleProvider(DataContext.class);
            Transaction transaction = dataContext.getParentDataDomain().createTransaction();
            Transaction.bindThreadTransaction(transaction);
        }
		return Transaction.getThreadTransaction();
	}
	
	@Before
	public void setUp() {
		if(skipAll)
			return;
		init();
        getTransaction().begin();
	}
	
	@After
	public void tearDown() {
		if(skipAll)
			return;
		printResult();
		try {
			DataContext dataContext = Sandbox.INSTANCE.singleProvider(DataContext.class);
			getTransaction().setRollbackOnly();
			dataContext.rollbackChanges();
			getTransaction().rollback();
			Transaction.bindThreadTransaction(null);
		} catch (Exception e) {
			Assert.fail(e.getLocalizedMessage());
		}
		if (testFailed)
			Assert.fail("Some tests failed");
	}

	private void printResult() {
		StringBuilder sb = new StringBuilder(1024);
		sb.append("Test scenarios count: ").append(scenarios.size()).append("\n");
		for (TestScenario scenario : scenarios) {
			sb.append("\t").append(scenario.getScenarioName()).append("..........").append(scenario.getScenarioAssertResult().getAssertStatus().toString());
		}
		if(scenarios.size() > 0)
			sb.append("\nDetails...\n");
		for (TestScenario scenario : scenarios) {
			sb.append(scenario.getResult());
		}
		logger.fatal(sb.toString());
	}

	@Test
	public void test() {
		scenarios = TestScenarioRegistry.getAllTestScenarios();
		for (TestScenario testScenario : scenarios) {
			TestAssertResult testScenarioAssertResult = new TestAssertResult();
			testScenario.setScenarioAssertResult(testScenarioAssertResult);
			boolean testPassed = false;
			for (TestObject test : testScenario.getScenarioTestList()) {
				TestAssertResult testAssertResult = new TestAssertResult();
				test.setTestAssertResult(testAssertResult);
				CommandContext commandContext = 
					getCommandContext(test.getMethodName(), test.getLogin(), test.getPassword(), test.getSessionId());
				try {
					TransferObject result = call(
						commandContext,
						test.getTestParamsList()
					);
					Map<String, Object> resMap = null;
					if (result != null) {
						resMap = result.toMap(null);
					} else {
						testAssertResult.setAssertStatus(TestAssertStatus.FAIL);
						testAssertResult.setText("Method doesn't return any result");
						break;
					}
					Map<String, Object> testResMap = null;
					if (test.getTestResult() != null) {
						testResMap = test.getTestResult();
					} else {
						if (resMap != null) {
							testAssertResult.setAssertStatus(TestAssertStatus.FAIL);
							testAssertResult.setText("Actual result doesn't match with expected");
							break;
						}
					}

					if (resMap != null && testResMap != null) {
						if (!testResMap.equals(resMap)) {
							testAssertResult.setAssertStatus(TestAssertStatus.FAIL);
							testAssertResult.setText("Actual result doesn't match with expected");
							break;
						}
					}
					testAssertResult.setAssertStatus(TestAssertStatus.SUCCESS);
					testAssertResult.setText("Test passed");
					testPassed = true;
				} catch (Throwable e) {
					testAssertResult.setAssertStatus(TestAssertStatus.FAIL);
					StringBuilder sb = new StringBuilder(512);
					sb.append("Unexpected error: ").append(e.getMessage()).append("\n");
					for (StackTraceElement ste : e.getStackTrace()) {
						sb.append("\t\t\t\t\t\t").append(ste.toString()).append("\n");
					}
					testAssertResult.setText(sb.toString());
					break;
				}
			}
			if (!testPassed) {
				testScenarioAssertResult.setAssertStatus(TestAssertStatus.FAIL);
				testScenarioAssertResult.setText("Test scenario failed");
				testFailed = true;
			} else {
				testScenarioAssertResult.setAssertStatus(TestAssertStatus.SUCCESS);
				testScenarioAssertResult.setText("Test scenario passed");
			}
		}
	}

	private <Input extends TransferObject, Output extends TransferObject> Output call(CommandContext commandContext,
			Map<String, Object> inputData) throws Fault {
		try {
			return CommandDispatcher.<Input, Output> executeCommand(commandContext, inputData);
		} catch (CommonException e) {
			throw new Fault(e.getErrorCode(), e);
		}
	}

    protected CommandContext getCommandContext(String commandName, String login, String password, String sessionId) {
    	CommandContext commandContext = new CommandContext();
    	commandContext.setCommandName(commandName);
    	commandContext.setLogin(login);
    	commandContext.setPassword(password);
    	commandContext.setSessionId(sessionId);
    	return commandContext;
    }
    
}