package ru.diasoft.flextera.services.ftfcreportws.ws;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import junit.framework.TestCase;

import org.junit.Test;

import ru.diasoft.core.application.command.CommandContext;
import ru.diasoft.core.application.dto.TransferObject;

public class ServiceImplTest {

	@Test
	public void checkEnvironmentHolder() throws Exception{
		Method method = FTFCREPORTWSImpl.class.getDeclaredMethod("call", CommandContext.class, TransferObject.class);
		TestCase.assertTrue(Modifier.isProtected(method.getModifiers()));
	}
}
