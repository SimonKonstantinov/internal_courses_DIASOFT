package ru.diasoft.flextera.services.ftfcreportws.command.dao.column;

public class ColumnAlias {

	public interface Fields {
		
		String PARAMETER_NAME = "ParameterName";
		
		String COLUMN_NAME = "ColumnName"; 
		
		String ORDER_BY = "ORDERBY"; 
	}
	
	private String parameterName;
	
	private String columnName;

	private String orderBy;

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	
	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((columnName == null) ? 0 : columnName.hashCode());
		result = prime * result + ((parameterName == null) ? 0 : parameterName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ColumnAlias other = (ColumnAlias) obj;
		if (columnName == null) {
			if (other.columnName != null)
				return false;
		} else if (!columnName.equals(other.columnName))
			return false;
		if (parameterName == null) {
			if (other.parameterName != null)
				return false;
		} else if (!parameterName.equals(other.parameterName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ColumnAlias [parameterName=" + parameterName + ", columnName=" + columnName + ", orderBy=" + orderBy + "]";
	}

	
}
