package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import org.apache.log4j.Logger;import ru.diasoft.core.application.command.CommandException;import ru.diasoft.flextera.services.ftfcreportws.report.builder.ReportBuilder;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportFindInputParameterListByReportIDReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportFindInputParameterListByReportIDRes;
/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportFindInputParameterListByReportID extends DsFCReportFindInputParameterListByReportIDStub {
	
	private static final Logger logger = Logger.getLogger(DsFCReportFindInputParameterListByReportID.class);
	private static final String METHOD_NAME = "dsFCReportBrowseListByParam";	
	/**
	 * Получение информации о входящих параметров необходимых для построения отчета
	 * 
	 * @param FCReportID Идентификатор отчета
	 * 
	 * @return InputParamterList Список входящих параметров
	 * @return CollectionElementList Список входящих элементов
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */
	@Override
	protected void executeCommand() throws CommandException {
		DsFCReportFindInputParameterListByReportIDReq request = getInputData();		DsFCReportFindInputParameterListByReportIDRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());		}		try {						Long reportID = request.getFCReportID();						ReportBuilder reportBuilder = ReportBuilder.getInstance();			reportBuilder.createInputParametersStructure(reportID, response);						if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());			}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);			CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}			}
}
