package ru.diasoft.flextera.services.ftfcreportws.utils.external;

import java.lang.reflect.Constructor;
import java.util.Map;

import ru.diasoft.flextera.services.ftfcreportws.utils.ConfigUtils;
import ru.diasoft.utils.XMLUtil;

@SuppressWarnings("unchecked")
public abstract class ExternalService {
	
    private static ExternalService instance;
    
    static {
		ExternalService externalService = null;

		String implementationClassName = ConfigUtils.getProjectProperty(
				"ExternalService");

		if (implementationClassName != null) {
			try {
				Class<? extends ExternalService> clazz =
						(Class<? extends ExternalService>) Class.forName(implementationClassName);

				Constructor<? extends ExternalService> constructor =
						clazz.getConstructor();
				externalService = (ExternalService) constructor.newInstance();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (externalService == null) {
			externalService = new ExternalServiceImpl();
		}
        instance = externalService;

    }
    
    public static ExternalService getInstance(){
    	return instance;
    }
	
    public abstract Map<String, Object> callExternalService(XMLUtil xmlUtil, String serviceName, String methodName, 
    		Map<String, Object> params) throws Exception;
    
    public long getNewId(String entityName) throws Exception{
		return getNewIds(entityName, 1);
	}

	public abstract long getNewIds(String entityName, int quantity) throws Exception;


}
