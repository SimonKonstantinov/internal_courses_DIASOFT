package ru.diasoft.flextera.services.ftfcreportws.utils;

import ru.diasoft.flextera.services.ftfcreportws.i18n.FTFCReportMessage;

public enum RetCode {
	// Класс регистрации бизнес-ошибок
	// Код ошибки регистрируется в системе DsArch
	// Текст ошибки локализован в ресурсных файлах проекта FTFCReportMessage_ru(en).properties и связан с ключевым словом
	
	// Связь(КодОшибки, КлючСообщения)
	REQUIRED_PARAM_NOT_FOUND             (134545410L, "required.parameter.not.found"),
	REPORT_SYSNAME_ALREADY_EXISTS        (134545411L, "report.sysname.already.exists"),
	REPORT_NAME_ALREADY_EXISTS           (134545412L, "report.name.already.exists"),
	OBJECT_NOT_FOUND                     (134545413L, "object.not.found.by.id"),	
	CALL_EXTERNAL_API_ERROR              (134545416L, "call.external.api.service.error"),
	INCORRECT_INPUT_PARAMETERS_XML       (134545417L, "incorrect.input.parameters.xml"),
	REPORT_TEMPLATE_FILE_NOT_FOUND       (134545418L, "protocol.report.template.file.not.found"	),
	INCORRECT_REPORT_CONFIG_FILE_TEMPLATE(134545419L, "incorrect.config.template"),
	REPORT_HISTORY_CREATE_ERROR          (134545420L, "report.history.create.error"),	
	REPORT_HISTORY_MODIFY_ERROR          (134545421L, "report.history.modify.error"),	
	PROTOCOL_CREATE_ERROR                (134545422L, "report.protocol.create.error"),	
	PROTOCOL_MODIFY_ERROR                (134545423L, "report.protocol.modify.error"),
	REPORT_CONFIG_FILE_NOT_FOUND         (134545424L, "report.config.file.not.found"),
	CALL_REPORT_TEMPLATE_ERROR           (134545425L, "protocol.building.report.error"),	
	CREATE_TABLE_ERROR                   (134545426L, "protocol.create.table.error"),
	ALTER_TABLE_ERROR                    (134545427L, "protocol.modify.table.error"),
	INCORRECT_TEMPLATE_EXTENSION		 (134545428L, "protocol.incorrect.template.extension"),
	REPORT_GROUP_DELETE_LINK_EXISTS      (134545429L, "reportgroup.delete.link.exists"),
	REPORT_GROUP_NAME_ALREADY_EXISTS     (134545430L, "reportgroup.name.already.exists"),
	REPORT_GROUP_SYSNAME_ALREADY_EXISTS  (134545431L, "reportgroup.sysname.already.exists");
	
	
	private Long code;
	private String key;
	
	private RetCode(Long code, String key) {
		this.code = code;
		this.key = key; 
	}

	public Long getCode() {
		return code;
	}
	
	private String getKey() {
		return key;
	}	
	
	public String getMessage(Object ... args) {
		String Msg = FTFCReportMessage.formatLocalizedString(getKey(), args); 
		return Msg; 
	}
}
