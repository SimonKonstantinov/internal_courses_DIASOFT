package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;

public class MergeLeftJoin extends AbstractJoinAction {

	private Logger logger = Logger.getLogger(MergeLeftJoin.class);

	public static interface Constanst {
		String TYPE  = "type";
		String INPUT = "input";
		String PARAM = "param";
		String ON    = "on";
	}

	public MergeLeftJoin(String valueON, ActionInputParameter actionInputParameter, Long processID) {
		this.actionInputParameter = actionInputParameter;
		this.processID = processID;
		this.valueON = valueON;		
	}

	@Override
	public void execute(Map<String, Object> inputParams) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("execute action " + APIActionType.LEFTJOIN.name() + ". ActionInputParameters = " + actionInputParameter + "; inputParams = " + inputParams);
		}

		try {
			// Протокол "Вызов действия"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL, APIActionType.LEFTJOIN.name(), actionInputParameter.getName());			
		
			List<Map<String, Object>> resultLeftJoinList = executeJoin(inputParams);

			if (logger.isDebugEnabled()) {
				logger.debug("execute action " + APIActionType.LEFTJOIN.name() + " Name = " + actionInputParameter.getName() + ". Result: " + resultLeftJoinList);
			}		
		} // try
		catch (Exception e) {			
			// Протокол "Ошибка выполнения действия"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL_ERROR, APIActionType.LEFTJOIN.name(), actionInputParameter.getName(), e.getMessage());			
			throw new Exception(e);
		}
	}

	@Override
	public void join(List<Map<String, Object>> resultLeftJoinList, List<Map<String, Object>> sourceList1, List<Map<String, Object>> sourceList2, String relList1Key, String relList2Key) {
		// Джойним два списка (LEFT JOIN)
		if (sourceList1 != null && sourceList2 != null) {
			if (logger.isDebugEnabled()) {					
				logger.debug("merge action");
			}
			
			for (Map<String, Object> rowList1 : sourceList1) {
				// Значение ключевого поля из списка 1
				Object relList1KeyValue = rowList1.get(relList1Key);
				Map<String, Object> resultRowNull = new HashMap<String, Object>();					
				boolean findRow = false;
			
				for (Map<String, Object> rowList2 : (List<? extends Map<String, Object>>) sourceList2) {
					// Значение ключевого поля из списка 2
					Object relList2KeyValue = rowList2.get(relList2Key);
				
					// Проверка условия соединения ON					
					if (relList1KeyValue.equals(relList2KeyValue)) {
						findRow = true;
						Map<String, Object> resultRow = new HashMap<String, Object>();						
						resultRow.putAll(rowList2);
						resultRow.putAll(rowList1);
					
						resultLeftJoinList.add(resultRow);
					}						
				}
				if (!findRow){
					// Все поля из первого списка
					resultRowNull.putAll(rowList1);
					// Все поля с null значением из второго списка						
					if(sourceList2.size() > 0){
						List<Map<String, Object>> srcList = sourceList2;
						
						Map<String, Object> rowList = srcList.get(0);
						
						for (Map.Entry<String, Object> entry : rowList.entrySet()) {
							String key = entry.getKey();
							if (!rowList1.containsKey(key)) {
								resultRowNull.put(key, null);
							}
						}						
					}
					resultLeftJoinList.add(resultRowNull);
				}
			}			
		}
		else if (sourceList1 != null) {
			resultLeftJoinList.addAll(sourceList1);
		}
		else if (sourceList2 != null) {
			resultLeftJoinList.addAll(sourceList2);
		}			
		else {
			if (logger.isDebugEnabled()) {					
				logger.debug("skip action");
			}				
		}
	}
}
