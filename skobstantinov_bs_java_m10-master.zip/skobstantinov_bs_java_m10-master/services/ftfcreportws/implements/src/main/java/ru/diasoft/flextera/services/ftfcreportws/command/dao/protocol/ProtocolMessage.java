package ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol;


import ru.diasoft.flextera.services.ftfcreportws.i18n.FTFCReportMessage;

public enum ProtocolMessage {
	// Класс регистрации сообщений протокола
	// Текст сообщения локализован в ресурсных файлах проекта FTFCReportMessage_ru(en).properties и связан с ключевым словом

	INCORRECT_CONFIG_TEMPLATE      ("protocol.incorrect.config.template"     ), //"Неверный формат конфигурационного файла отчета"
	INVALID_CONFIG_TEMPLATE        ("protocol.invalid.config.template"       ), //"Неверный формат конфигурационного файла отчета (XSD)"	
	CONFIG_FILE_NOT_FOUND          ("protocol.report.config.file.not.found"  ), //"Не найден конфигурационный файл"
	CONFIG_FILE_FOUND              ("protocol.report.config.file.found"      ), //"Найден конфигурационный файл"
	TEMPLATE_FILE_NOT_FOUND        ("protocol.report.template.file.not.found"), //"Не найден шаблон отчета"
	TEMPLATE_FILE_FOUND            ("protocol.report.template.file.found"    ), //"Найден шаблон отчета"
	REPORT_PROCESS_ID              ("protocol.report.process.id"             ), //"Запущен процесс с идентификатором"
	INCORRECT_INPUT_PARAMETERS_XML ("protocol.incorrect.input.parameters.xml"), //"Неверный формат входящих параметров"
	SUCCESS_INPUT_PARAMETERS_XML   ("protocol.success.input.parameters.xml"  ), //"Успешно определены входящие параметры"
	METHOD_CALL                    ("protocol.method.call"                   ), //"Вызов метода"
	METHOD_CALL_ERROR              ("protocol.method.call.error"             ), //"Ошибка вызова метода"
	BUILDING_REPORT_START          ("protocol.building.report.start"         ), //"Запущено выполнение шаблона отчета"
	BUILDING_REPORT_ERROR          ("protocol.building.report.error"         ), //"Ошибка запуска шаблона отчета"
	BUILDING_REPORT_DONE           ("protocol.building.report.done"          ), //"Файл отчета сформирован"
	CREATE_TABLE                   ("protocol.create.table"                  ), //"Создана таблица"
	CREATE_TABLE_ERROR             ("protocol.create.table.error"            ), //"Ошибка создания таблицы"
	ALTER_TABLE_ERROR              ("protocol.modify.table.error"            ), //"Ошибка изменения структуры таблицы"
	METHOD_SAVE_OUTPUT_TABLE       ("protocol.method.save.output.table"      ), //"Ответ метода записан в таблицу"
	SQL_SAVE_OUTPUT_TABLE          ("protocol.sql.save.output.table"      	 ), //"Результат sql-запроса записан в таблицу"
	INCORRECT_TEMPLATE_EXTENSION   ("protocol.incorrect.template.extension"  ), //"Неверное расширение шаблона отчета"
	DELETE_TEMP_DATA               ("protocol.delete.temp.data"              ), //"Удаление временных данных для процесса"
	CALL_EXTERNAL_API_ERROR        ("call.external.api.service.error"        ), //"Ошибка вызова внешнего API-метода"
	ACTION_CALL                    ("protocol.action.call"                   ), //"Вызов действия"
	ACTION_CALL_ERROR              ("protocol.action.call.error"             ); //"Ошибка вызова действия"	
	
	private String key;	
	
	private ProtocolMessage(String key) {		
		this.key = key;
	}
	
	private String getKey() {
		return key;
	}
	
	public String getMessage(Object ... args) {
		String Msg = "";
		try {
			Msg = FTFCReportMessage.formatLocalizedString(getKey(), args);	
		} 
		catch (Exception e) {
			Msg = "ErrorProtocolMessage. Check params for key = " + getKey() ;
	    }
		 
		return Msg; 
	}
	

}
