package ru.diasoft.flextera.services.ftfcreportws.command.dao.report;

public class ReportException extends Exception{
	
	private static final long serialVersionUID = 4739337391076941865L;
	private Long   returnCode;
	private String returnMessage;

	public ReportException(Long retCode, String retMsg){
		setReturnCode(retCode);
		setReturnMessage(retMsg);
	}

	private void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}

	public String getReturnMessage() {
		return returnMessage;
	}


	private void setReturnCode(Long returnCode) {
		this.returnCode = returnCode;
	}

	public Long getReturnCode() {
		return returnCode;
	}
	
	
}
