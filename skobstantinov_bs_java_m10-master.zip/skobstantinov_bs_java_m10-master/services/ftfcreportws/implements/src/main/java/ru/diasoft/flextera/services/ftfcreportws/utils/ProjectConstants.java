package ru.diasoft.flextera.services.ftfcreportws.utils;

public class ProjectConstants {

	public static final String RET_CODE = "RetCode";
	
	public static final String PARAMETER_PASSWORD = "password";
	public static final String PARAMETER_USER_NAME = "userName";
	public static final String PARAMETER_MAX_CON = "maxCon";
	public static final String PARAMETER_MIN_CON = "minCon";
	public static final String PARAMETER_DATA_SOURCE_URL = "dataSourceUrl";
	public static final String PARAMETER_JDBC_DRIVER = "jdbcDriver";


	public static final String PAGE = "PAGE";
	public static final String ROWSCOUNT = "ROWSCOUNT";
	public static final String TOTALCOUNT = "TOTALCOUNT";
	public static final String ROWSCOUNT_DEFAULT_VALUE = "100";
	
	public static final String SERVICE_NAME = "ftfcreportws";
}
