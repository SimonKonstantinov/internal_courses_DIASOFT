package ru.diasoft.flextera.services.ftfcreportws.report.api;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.report.method.APIAction;

public class APIActionExecutor {

	private Logger logger = Logger.getLogger(APIActionExecutor.class);
	private Map<String, Object> inputParams;
	private List<APIAction> actionList;	
	
	public static APIActionExecutor getInstance(Map<String, Object> inputParams, List<APIAction> actionList){
		return new APIActionExecutor(inputParams, actionList);
	}
	
	
	public APIActionExecutor(Map<String, Object> inputParams, List<APIAction> actionList) {
		this.inputParams = inputParams;
		this.actionList = actionList;		
	}


	public void execute() throws Exception{
		if(logger.isDebugEnabled()){
			logger.debug("callAPI: inputParams = " + inputParams + ", methodList = " + actionList);
		}
		
		if(actionList != null && actionList.size() > 0){
			for (APIAction action : actionList) {
				action.execute(inputParams);
			}
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("callAPI method executed successfully");
		}
	}
}
