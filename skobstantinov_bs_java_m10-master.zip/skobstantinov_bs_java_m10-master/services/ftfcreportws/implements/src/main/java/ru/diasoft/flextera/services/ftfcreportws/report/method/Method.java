package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.Converter;
import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;
import ru.diasoft.flextera.services.ftfcreportws.report.database.DataLoader;
import ru.diasoft.flextera.services.ftfcreportws.utils.ConfigUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtilsParamIllegalTypeException;
import ru.diasoft.flextera.services.ftfcreportws.utils.ProjectConstants;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.ExternalService;
import ru.diasoft.utils.XMLUtil;
import ru.diasoft.utils.text.StringUtils;

public class Method extends APIAction implements Serializable{

	private static final long serialVersionUID = -1696900420809535524L;

	private Logger logger = Logger.getLogger(Method.class);

	public static interface Constanst {
		String SERVICE = "service";
		String NAME = "name";
		String INPUT = "input";
		String OUTPUT = "output";
		String FOREACH = "foreach";
		String BATCH = "batch";
		String BATCH_SIZE = "size";
	}
	
	private String service;
	
	private String methodName;
	
	private List<ActionInputParameter> inputParameterList;
	
	private List<MethodOutputParameter> outputParameterList;
	
	private XMLUtil xmlUtil;
	
	private Long processID;
	
	private boolean repeatable;
	
	private Integer batchSize;
	
	private boolean isFirstBatchProcessing;

	public Method(){
	}
	
	public Method(String service, String methodName, List<ActionInputParameter> inputParameterList, List<MethodOutputParameter> outputParameterList, XMLUtil xmlUtil, Long processID, boolean repeatable, Integer batchSize) {
		this.service = service;
		this.methodName = methodName;
		this.inputParameterList = inputParameterList;
		this.outputParameterList = outputParameterList;
		this.xmlUtil = xmlUtil;
		this.processID = processID;
		this.repeatable = repeatable;
		this.batchSize = batchSize;
	}
	
	@Override
	public void execute(Map<String, Object> inputParams) throws Exception{
		if(logger.isDebugEnabled()){
			logger.debug("execute Method " + getMethodName() + " with inputParams = " + inputParams);
		}	
		
		try {
			// Протокол "Вызов метода"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.METHOD_CALL, getMethodName(), getService());			
			
			Map<String, Object> callParameters = processInputParameters(inputParams);
			
			if(!repeatable){
				if(batchSize != null && batchSize > 0){
					if(logger.isDebugEnabled()){
						logger.debug("before batch call");
					}
					batchCall(inputParams, callParameters);
				} else {
					if(logger.isDebugEnabled()){
						logger.debug("before single call");
					}
					callMethod(inputParams, callParameters, false);
				}
				
			} else {
				if(logger.isDebugEnabled()){
					logger.debug("before miltiple call");
				}
				
				multipleCall(inputParams, callParameters);
			}
			
		} catch (Exception e) {
			String errorMessage = "Execute method: " + service + "?" + methodName + " error";
			logger.error(errorMessage, e);
			
			// Протокол "Ошибка вызова метода"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.METHOD_CALL_ERROR, getMethodName(), getService(), e.getMessage());			
			
			throw new Exception(e);
		}
		
	}

	private void callMethod(Map<String, Object> inputParams, Map<String, Object> callParameters, boolean isRepeatable) throws Exception,
			MapUtilsParamIllegalTypeException {
		
		// PAGE и ROWSCOUNT для BrowseList
		callParameters.put(ProjectConstants.PAGE, Integer.valueOf(0));
		callParameters.put(ProjectConstants.ROWSCOUNT, ConfigUtils.getRowsCountParam());
		
		if(logger.isDebugEnabled()){
			logger.debug("Before call service: " +  service + "?" + methodName + ", callParameters = " + callParameters);
		}		
		
		Map<String, Object> result = ExternalService.getInstance().callExternalService(getXmlUtil(), service, 
				methodName, callParameters);

		if(logger.isDebugEnabled()){
			logger.debug("After call service: " +  service + "?" + methodName + ", result = " + result);
		}
		
		Integer retCode = MapUtils.asInteger(result, "RetCode", 0); 
		if(retCode != 0){;
			throw new Exception(methodName + " returned RetCode = " + retCode);
		}
		
		// Дочитка для Browse
		Integer totalCount = MapUtils.asInteger(result, ProjectConstants.TOTALCOUNT, 0);
		if (totalCount > 0) {
			if(logger.isDebugEnabled()){
				logger.debug("Method " + methodName + " is browse list");
			}			
			callMethodForEachPage(callParameters, result);
		}		
		
		if(!repeatable){
			processOutputParameters(inputParams, result);
		}else {
			processRepeatableOutputParameters(inputParams, result);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void callMethodForEachPage(Map<String, Object> callParameters, Map<String, Object> result) throws Exception,
			MapUtilsParamIllegalTypeException {
		int totalCount = MapUtils.asInteger(result, ProjectConstants.TOTALCOUNT, 0).intValue();
		
		if(outputParameterList != null && outputParameterList.size() > 0) {
			for (MethodOutputParameter outputParameter : outputParameterList) {
				String outputParameterName = outputParameter.getName();
				String outputParameterSysname = outputParameter.getSysname();
				Object parameterValue = result.get(outputParameterName);
				
				// RESULT LIST
				if (parameterValue != null && parameterValue instanceof List && ((List)parameterValue).size() > 0) {
					int resultSize = ((List)parameterValue).size();

					if(logger.isDebugEnabled()) {
						logger.debug("callMethodForEachPage: LIST = " + outputParameterSysname + " PAGE = 0 TOTALCOUNT = " + totalCount + " Size = " + resultSize);
					}
					
					// Если метод вернул не все записи, выполним повторно для каждой страницы  
					if (resultSize < totalCount) {
						// возврат ближайшего большего целого						
						double pageCount = Math.ceil((double)totalCount / (double)resultSize);

						if(logger.isDebugEnabled()) {
							logger.debug("callMethodForEachPage: pageCount = " + pageCount);
						}
						
						// Делаем столько вызовов API, сколько требуется страниц для получения всех записей.
						// PAGE индексируется с 0
						for(int page = 1; page < pageCount; page++) {							
							callParameters.put(ProjectConstants.PAGE, Integer.valueOf(page));
							
							if(logger.isDebugEnabled()){
								logger.debug("callMethodForEachPage: PAGE = " + page);
								logger.debug("Before call service: " +  service + "?" + methodName + ", callParameters = " + callParameters);
							}							
							
							Map<String, Object> pageResult = ExternalService.getInstance().callExternalService(getXmlUtil(), service, 
									methodName, callParameters);
							
							Integer retCode = MapUtils.asInteger(pageResult, "RetCode", 0); 
							if(retCode != 0){;
								throw new Exception(methodName + "PAGE = " + page + " returned RetCode = " + retCode);
							}

							// Добавляем постраничный результат в общий Result метода
							List<Map<String, Object>> listPageResult = MapUtils.asList(pageResult, outputParameterName, null);
							((List)parameterValue).addAll(listPageResult);

							if(logger.isDebugEnabled()){
								logger.debug("After call service: " +  service + "?" + methodName + ", LIST = " + outputParameterSysname + " PAGE = " + page + " Size = " + listPageResult.size());
							}						
							
						}
						
					}
					else {
						if(logger.isDebugEnabled()) {
							logger.debug("callMethodForEachPage: not required");
						}						
					}
					break;
				}
				
			}
		}
		
	}

	private void multipleCall(Map<String, Object> inputParams, Map<String, Object> callParameters) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("multipleCall has started [inputParams = " + inputParams + ", callParameters = " + callParameters + "]");
		}
		
		List<Map<String, Object>> listToIterate = null;
		String key = null;
		
		if(inputParameterList != null && inputParameterList.size() > 0){
			key = inputParameterList.get(0).getName();
			listToIterate = MapUtils.asList(callParameters, key, null);
		}
		
		if(listToIterate != null && listToIterate.size() > 0){
			if(logger.isDebugEnabled()){
				logger.debug("List element to iterate has found. Key = " + key + ", listToIterate = " + listToIterate);
			}
			
			//Делаем столько вызовов API, сколько элементов в найденном листе.
			callParameters.remove(key);
			for (Map<String, Object> parametersRow : listToIterate) {
				callParameters.putAll(parametersRow);
				
				callMethod(inputParams, callParameters, true);
				
				callParameters.keySet().removeAll(parametersRow.keySet());
			}
			
		} else {
			callMethod(inputParams, callParameters, false);
		}
		
	}
	
	private void batchCall(Map<String, Object> inputParams, Map<String, Object> callParameters) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("batchCall has started [inputParams = " + inputParams + ", callParameters = " + callParameters + "]");
		}
		
		List<Map<String, Object>> listToBatchCall = null;
		String key = null;
		
		if(inputParameterList != null && inputParameterList.size() > 0){
			key = inputParameterList.get(0).getName();
			listToBatchCall = MapUtils.asList(callParameters, key, null);
			
			if(logger.isDebugEnabled()){
				logger.debug("batch parameter [key =  " + key + ", value = " + listToBatchCall + " ]");
			}
		}
		
		if(listToBatchCall != null && listToBatchCall.size() > 0){
			
			for (int i = 0; i < listToBatchCall.size(); i += batchSize) {
				if(i == 0){
					isFirstBatchProcessing = true;
				}
				
				int toIndex = i + batchSize;
				if(toIndex > listToBatchCall.size()){
					toIndex = listToBatchCall.size();
				}
				
				List<Map<String, Object>> subList = listToBatchCall.subList(i, toIndex); 
				callParameters.put(key, subList);
				
				if(logger.isDebugEnabled()){
					logger.debug("batch call [subList = " + subList + "]");
				}
				callMethod(inputParams, callParameters, false);
				
				isFirstBatchProcessing = false;
			}
			
			
		} else {
			if(logger.isDebugEnabled()){
				logger.debug("callMethod without batch");
			}
			
			callMethod(inputParams, callParameters, false);
		}
	}
	
	
	private void processOutputParameters(Map<String, Object> inputParams, Map<String, Object> result) throws Exception {
		if(outputParameterList != null && outputParameterList.size() > 0){
			for (MethodOutputParameter outputParameter : outputParameterList) {
				processOutputParameter(inputParams, result, outputParameter);
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void processOutputParameter(Map<String, Object> inputParams, Map<String, Object> result, MethodOutputParameter outputParameter)
			throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Processing output paramater: " + outputParameter);
		}
		
		String outputParameterName = outputParameter.getName();
		String outputParameterSysname = outputParameter.getSysname();
		
		Object parameterValue = result.get(outputParameterName);
		if(batchSize == null || batchSize == 0){
			inputParams.put(outputParameterSysname, parameterValue);
		} else {
			if(logger.isDebugEnabled()){
				logger.debug("Processing output paramater for batch call: " + outputParameter);
			}
			
			Object currentValue = inputParams.get(outputParameterSysname);
			if(!isFirstBatchProcessing && currentValue != null && currentValue instanceof List && parameterValue instanceof List){
				((List<Map<String, Object>>)currentValue).addAll((List<Map<String, Object>>) parameterValue);
			} else {
				inputParams.put(outputParameterSysname, parameterValue);
			}
		}
		
		String outputParameterTableName = outputParameter.getTableName();
		if(!StringUtils.isEmpty(outputParameterTableName) && parameterValue != null 
				&& ((parameterValue instanceof List && ((List)parameterValue).size() > 0) || !(parameterValue instanceof List))
				&& ((parameterValue instanceof Map && ((Map)parameterValue).size() > 0) || !(parameterValue instanceof Map))){
			DataLoader.getInstance().load(outputParameterTableName, parameterValue, processID);
			// Протокол "Ответ метода записан в таблицу"
			ProtocolDAO.getInstance().addReportProtocol(processID, ProtocolMessage.METHOD_SAVE_OUTPUT_TABLE, methodName, outputParameterTableName);						
		}
	}
	
	@SuppressWarnings({ "rawtypes"})
	private void processRepeatableOutputParameters(Map<String, Object> inputParams, Map<String, Object> result) throws Exception {
		
		if(outputParameterList != null && outputParameterList.size() > 0){
			
			boolean isSimpleParameterProcessed = false;
			for (MethodOutputParameter outputParameter : outputParameterList) {
				if(logger.isDebugEnabled()){
					logger.debug("Processing repetable output paramater: " + outputParameter);
				}
				
				String outputParameterName = outputParameter.getName();
				String outputParameterSysname = outputParameter.getSysname();
				
				Object parameterValue = result.get(outputParameterName);
				
				if(parameterValue != null || isSimpleParameterProcessed){
					processComplexRepeatableOutputParam(inputParams, outputParameterSysname, parameterValue);
				} else {
					isSimpleParameterProcessed = true;
					parameterValue = processSimpleRepeatableOutputParam(inputParams, result, outputParameterSysname);
				}
				
				String outputParameterTableName = outputParameter.getTableName();
				if(!StringUtils.isEmpty(outputParameterTableName) && parameterValue != null 
						&& ((parameterValue instanceof List && ((List)parameterValue).size() > 0) || !(parameterValue instanceof List))
						&& ((parameterValue instanceof Map && ((Map)parameterValue).size() > 0) || !(parameterValue instanceof Map))){
					DataLoader.getInstance().load(outputParameterTableName, parameterValue, processID);
					// Протокол "Ответ метода записан в таблицу"
					ProtocolDAO.getInstance().addReportProtocol(processID, ProtocolMessage.METHOD_SAVE_OUTPUT_TABLE, methodName, outputParameterTableName);						
				}
			}
		}
		
	}

	private Object processSimpleRepeatableOutputParam(Map<String, Object> inputParams, Map<String, Object> result,
			String outputParameterSysname) throws MapUtilsParamIllegalTypeException {
		
		Object parameterValue = null;
		
		Map<String, Object> mapToSave = new HashMap<String, Object>();
		
		for (Map.Entry<String, Object> entry : result.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			if(value != null && !(value instanceof List) && !(value instanceof Map)){
				mapToSave.put(key, value);
			}
		}
		
		if(!mapToSave.isEmpty()){
			List<Map<String, Object>> listParameter = MapUtils.asList(inputParams, outputParameterSysname, null);
			List<Map<String, Object>> newParamsList = new ArrayList<Map<String,Object>>();
			
			if(listParameter != null){
				newParamsList.add(mapToSave);
				listParameter.addAll(newParamsList);
			} else {
				newParamsList.add(mapToSave);
				inputParams.put(outputParameterSysname, newParamsList);
			}
			
			parameterValue = newParamsList;
		}
		return parameterValue;
	}

	@SuppressWarnings("unchecked")
	private void processComplexRepeatableOutputParam(Map<String, Object> inputParams, String outputParameterSysname, Object parameterValue)
			throws MapUtilsParamIllegalTypeException {
		List<Map<String, Object>> listParameter = null;
		if(parameterValue instanceof List){
			listParameter = MapUtils.asList(inputParams, outputParameterSysname, null);
			if(listParameter != null){
				listParameter.addAll((List<Map<String, Object>>) parameterValue);
			} else {
				inputParams.put(outputParameterSysname, parameterValue);
			}
		} else if(parameterValue instanceof Map){
			listParameter = MapUtils.asList(inputParams, outputParameterSysname, null);
			
			if(listParameter != null){
				listParameter.add((Map<String, Object>) parameterValue);
			} else {
				List<Map<String, Object>> newParamsList = new ArrayList<Map<String,Object>>();
				newParamsList.add((Map<String, Object>) parameterValue);
				inputParams.put(outputParameterSysname, newParamsList);
			}
			
		}
	}

	private Map<String, Object> processInputParameters(Map<String, Object> inputParams) throws Exception {
		Map<String, Object> callParameters = new HashMap<String, Object>();
		if(inputParameterList != null && inputParameterList.size() > 0){
			for (ActionInputParameter methodInputParameter : inputParameterList) {
				String parameterName = methodInputParameter.getName();
				String parameterStringValue = methodInputParameter.getValue();
				List<ActionInputParameter> subParametersList = methodInputParameter.getSubParametersList();
				
				if(logger.isDebugEnabled()){
					logger.debug("Processing input parameter: " + parameterName + ", parameterStringValue = " + parameterStringValue);
				}
				
				if(!StringUtils.isEmpty(parameterName) && !StringUtils.isEmpty(parameterStringValue)){
					Object value = null; 
					if(parameterStringValue.startsWith("@") && parameterStringValue.endsWith("@")){
						String key = parameterStringValue.replaceAll("@", "");
						value = inputParams.get(key);
						
						if(logger.isDebugEnabled()){
							logger.debug("method input parameter value: " + value);
						}

						if(value != null && subParametersList != null && subParametersList.size() > 0){
							value = processInputSubParameters(subParametersList, value);
						}
						
					}else{
						value = convertValue(parameterStringValue, methodInputParameter.getType());
					}
					callParameters.put(parameterName, value);
				}
			}
		}
		return callParameters;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public List<ActionInputParameter> getInputParameterList() {
		return inputParameterList;
	}

	public void setInputParameterList(List<ActionInputParameter> inputParameterList) {
		this.inputParameterList = inputParameterList;
	}

	public List<MethodOutputParameter> getOutputParameterList() {
		return outputParameterList;
	}

	public void setOutputParameterList(List<MethodOutputParameter> outputParameterList) {
		this.outputParameterList = outputParameterList;
	}
	
	public XMLUtil getXmlUtil() {
		return xmlUtil;
	}

	public void setXmlUtil(XMLUtil xmlUtil) {
		this.xmlUtil = xmlUtil;
	}
	
	public Long getProcessID() {
		return processID;
	}

	public void setProcessID(Long processID) {
		this.processID = processID;
	}

	public boolean isRepeatable() {
		return repeatable;
	}

	public void setRepeatable(boolean repeatable) {
		this.repeatable = repeatable;
	}


	public Integer getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(Integer batchSize) {
		this.batchSize = batchSize;
	}

	@Override
	public String toString() {
		return "Method [logger=" + logger + ", service=" + service + ", methodName=" + methodName + ", inputParameterList="
				+ inputParameterList + ", outputParameterList=" + outputParameterList + ", xmlUtil=" + xmlUtil + ", processID=" + processID
				+ ", repeatable=" + repeatable + ", batchSize=" + batchSize + "]";
	}

	@SuppressWarnings("unchecked")
	private Object processInputSubParameters(List<ActionInputParameter> subParametersList,
			Object value) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Processing input sub parameters: " + subParametersList);
		}
		
		Object convertedValue = null;
		if(value instanceof List){
			List<Map<String, Object>> listValue = (List<Map<String, Object>>) value;
			List<Map<String, Object>> convertedList = new ArrayList<Map<String,Object>>();
			
			for (Map<String, Object> map : listValue) {
				Map<String, Object> convertedMap = convertMapBySubParameters(subParametersList, map);
				convertedList.add(convertedMap);
			}
			
			convertedValue = convertedList;
		} else if (value instanceof Map) {
			Map<String, Object> mapValue = (Map<String, Object>) value;
			Map<String, Object> convertedMap = convertMapBySubParameters(subParametersList, mapValue);
			convertedValue = convertedMap;
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("converted value: " + convertedValue);
		}
		
		return convertedValue;
	}

	private Map<String, Object> convertMapBySubParameters(List<ActionInputParameter> subParametersList, Map<String, Object> map) throws Exception {
		Map<String, Object> convertedMap = new HashMap<String, Object>();
		for (ActionInputParameter subInputParameter : subParametersList) {
			String subParameterName = subInputParameter.getName();
			String subParameterStringValue = subInputParameter.getValue();
			String subParameterType = subInputParameter.getType();
			
			if(!StringUtils.isEmpty(subParameterName) && !StringUtils.isEmpty(subParameterStringValue)){
				
				if(subParameterStringValue.startsWith("@") && subParameterStringValue.endsWith("@")){
					String key = subParameterStringValue.replaceAll("@", "");
					convertedMap.put(subParameterName, map.get(key));
				} else {
					convertedMap.put(subParameterName, convertValue(subParameterStringValue, subParameterType));
				}
			}
		}
		
		return convertedMap;
	}

	private Object convertValue(String parameterStringValue, String type) throws Exception {
        try {
    		if (parameterStringValue != null && !StringUtils.isEmpty(type)) {
                Class<?> clazz = Class.forName(type);
            	Converter converter = ConvertUtils.lookup(clazz);
                if (converter == null) {
                    converter = ConvertUtils.lookup(String.class);
                }
                return converter.convert(clazz, parameterStringValue);
            } else {
                return parameterStringValue;
            }
		} catch (Exception e) {
			String errorMessage = "Error was occured while converting input parameter: value = " + parameterStringValue + ", type = " + type; 
			logger.error(errorMessage, e);
			throw new Exception(errorMessage, e);
		}
	}

}
