package ru.diasoft.flextera.services.ftfcreportws.utils.event;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.core.application.dto.AbstractTransferObject;
import ru.diasoft.core.util.sandbox.Sandbox;
import ru.diasoft.fa.registry.client.RegistryClient;
import ru.diasoft.flextera.services.ftfcreportws.utils.context.EnvironmentHolder;

public class EventFacadeClientRegisterImpl implements EventFacade{

    private Logger logger = Logger.getLogger(EventFacadeClientRegisterImpl.class);

	@Override
	public Map<String, Object> triggerEvent(boolean isAsync, String eventName, AbstractTransferObject eventParams) {
        if (logger.isDebugEnabled()){
            logger.debug("Event name = " + eventName +", isAsync = " + isAsync + " with params = "
                    + eventParams);
        }
		
		Map<String, Object> mapParams = new HashMap<String, Object>();
		eventParams.toMap(mapParams);
		
        RegistryClient registryClient = Sandbox.INSTANCE.singleProvider(RegistryClient.class);
        Map<String, Object> result = registryClient.fireEvent(EnvironmentHolder.currentContext().getXmlUtil(), eventName, isAsync, null, mapParams);
        if (logger.isDebugEnabled()){
            logger.debug("Result = " + result);
        }
        
        return result;
	}

}
