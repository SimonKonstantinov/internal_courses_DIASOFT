package ru.diasoft.flextera.services.ftfcreportws.report.database.creator;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataBaseType;

public class SimpleTableUpdater extends TableUpdater{

	public SimpleTableUpdater(Object value, Long processID, ResultSet tableResultSet, DataBaseType dataBaseType) throws Exception {
		super(value, processID, tableResultSet, dataBaseType);
	}

	@Override
	protected TableColumns createOrModifyTableColumns(Object value, ResultSet columnsResultSet) throws Exception {
		TableColumns tableColumns = null;
		if(columnsResultSet == null){
			tableColumns = create(value);
		} else {
			tableColumns = modify(value, columnsResultSet);
		}
		
		return tableColumns;
	}

	@Override
	protected List<String> prepareInsertQuery(String schemaName, String tableName, Object parameterValue) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Prepare insert query: tableName = " + tableName + ", parameterValue = " + parameterValue) ;
		}
		
		List<String> result = new ArrayList<String>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(DatabaseConstants.VALUE, parameterValue);
		createInsertStringByMap(schemaName, tableName, result, map);		
		
		return result;
	}

	private TableColumns create(Object parameterValue) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Creation of tableColumns object has started. ParameterValue = " + parameterValue);
		}
		
		if(parameterValue == null){
			throw new SQLException("parameterValue is empty. Could not create new table.");
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(DatabaseConstants.VALUE, parameterValue);
		TableColumns tableColumns = createTableColumnsByMap(map);		
		return tableColumns;
	}

	private TableColumns modify(Object parameterValue, ResultSet columnsResultSet) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Modifying of tableColumns object has started. ParameterValue = " + parameterValue);
		}
		
		TableColumns tableColumns = null;
		if(parameterValue != null){
			Map<String, Object> map = new HashMap<String, Object>();
			map.put(DatabaseConstants.VALUE, parameterValue);
			tableColumns = modifyTableColumnsByMap(columnsResultSet, map);
		}
		
		return tableColumns;
	}

}
