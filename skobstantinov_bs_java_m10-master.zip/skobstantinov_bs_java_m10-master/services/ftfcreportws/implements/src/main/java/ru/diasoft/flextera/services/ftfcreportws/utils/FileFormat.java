package ru.diasoft.flextera.services.ftfcreportws.utils;

public enum FileFormat {

	XLS(1, "xls"),
	PDF(2, "pdf"),
	RTF(3, "rtf");

	private Integer formatCode;
	private String methodName;
	
	private FileFormat(Integer formatCode, String methodName) {
		this.formatCode = formatCode;
		this.methodName = methodName;
	}

	public Integer getFormatCode() {
		return formatCode;
	}

	public String getMethodName() {
		return methodName;
	}

	public static String getMethodNameByCode(int code){
		String value = null;
		switch (code) {
		case 1:
			value = XLS.getMethodName();
			break;
		case 2:
			value = PDF.getMethodName();
			break;
		case 3:
			value = RTF.getMethodName();
			break;
		default:
			throw new UnsupportedOperationException("Unsupported file format with code = " + code);
		}
		return value;
	}
}
