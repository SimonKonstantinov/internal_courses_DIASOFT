package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Element;

import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportProcessExecuteBuildingRes;
import ru.diasoft.flextera.services.ftfcreportws.utils.ConfigUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.context.EnvironmentHolder;
import ru.diasoft.utils.text.StringUtils;

public class APIActionFactory {

	private static APIActionFactory instance = new APIActionFactory();
	
	private static final String LIST_ITEM_PARAMS = "ListItems/Item/param";
	private static final String PARAM_CHILD = "./param";
	private static final String PARAM_ELEMENT = "param";
	private static final String TYPE_ELEMENT = "type";	

	private Logger logger = Logger.getLogger(APIActionFactory.class);

	public static APIActionFactory getInstance() {
		return instance;
	}
	
	private APIActionFactory(){
	}

	public APIAction createAction(Element actionElement, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		APIAction action = null;
		
		if (APIActionType.METHOD.name().equals(actionElement.getName().toUpperCase())) {
			action = createMethodAction(actionElement, response);
		} else if (APIActionType.MERGE.name().equals(actionElement.getName().toUpperCase())) {
			String type = actionElement.attributeValue(TYPE_ELEMENT).trim().toUpperCase();
			
			if (APIActionType.UNION.name().equals(type)) {
				action = createMergeUnionAction(actionElement, response);
			} else if (APIActionType.JOIN.name().equals(type)) {
				action = createMergeJoinAction(actionElement, response);
			} else if (APIActionType.LEFTJOIN.name().equals(type.replaceAll(" ", ""))) {
				action = createMergeLeftJoinAction(actionElement, response);				
			} else {
				throw new Exception("Unsupported merge type: " + type);	
			}
		} else if(APIActionType.SQL.name().equals(actionElement.getName().toUpperCase())){	
			action = createSQLAction(actionElement, response);
		} else if(APIActionType.CREATEINDEX.name().equals(actionElement.getName().toUpperCase())){	
			action = createIndexAction(actionElement, response);
		} else {
			throw new Exception("Unsupported action: " + actionElement.getName());
		}
		
		return action;
	}

	private APIAction createMergeUnionAction(Element actionElement, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		Element inputParametersElement = actionElement.element(MergeUnion.Constanst.PARAM);
		ActionInputParameter actionInputParameter = getMergeParameter(inputParametersElement);

		APIAction actionUnion = new MergeUnion(actionInputParameter, response.getProcessID());
		
		return actionUnion;
	}
	
	private APIAction createMergeJoinAction(Element actionElement, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		Element inputParametersElement = actionElement.element(MergeJoin.Constanst.PARAM);
		ActionInputParameter actionInputParameter = getMergeParameter(inputParametersElement);
		
		Element onElement = actionElement.element(MergeJoin.Constanst.ON);
		String valueON = onElement.getText();		
		if(valueON != null){
			valueON = valueON.trim();
		}

		APIAction actionJoin = new MergeJoin(valueON, actionInputParameter, response.getProcessID());		
		
		return actionJoin;
	}
	
	private APIAction createMergeLeftJoinAction(Element actionElement, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		Element inputParametersElement = actionElement.element(MergeJoin.Constanst.PARAM);
		ActionInputParameter actionInputParameter = getMergeParameter(inputParametersElement);
		
		Element onElement = actionElement.element(MergeJoin.Constanst.ON);
		String valueON = onElement.getText();		
		if(valueON != null){
			valueON = valueON.trim();
		}

		APIAction actionLeftJoin = new MergeLeftJoin(valueON, actionInputParameter, response.getProcessID());		
		
		return actionLeftJoin;
	}	

	private APIAction createMethodAction(Element actionElement, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		String methodName = actionElement.attributeValue(Method.Constanst.NAME);
		String service = actionElement.attributeValue(Method.Constanst.SERVICE);
		
		Element inputParametersElement = actionElement.element(Method.Constanst.INPUT);
		Element foreachElement = inputParametersElement.element(Method.Constanst.FOREACH);
		Element batchElement = inputParametersElement.element(Method.Constanst.BATCH);
		
		boolean isRepeatable = false;
		if(foreachElement != null){
			isRepeatable = true;
			inputParametersElement = foreachElement; 
		}
		
		Integer batchSize = 0;
		if(batchElement != null){
			inputParametersElement = batchElement;
			String batchSizeValue = inputParametersElement.attributeValue(Method.Constanst.BATCH_SIZE);
			if(batchSizeValue != null){
				batchSize = Integer.valueOf(batchSizeValue);
			} else {
				batchSize = ConfigUtils.getRowsCountParam();
			}
		}
		
		List<ActionInputParameter> inputParameters = getInputParameters(inputParametersElement);
		List<MethodOutputParameter> outputParameters = getOutputParameters(actionElement.element(Method.Constanst.OUTPUT));
		
		APIAction actionMethod = new Method(service, methodName, inputParameters, outputParameters, EnvironmentHolder.currentContext().getXmlUtil(), response.getProcessID(), isRepeatable, batchSize);
		return actionMethod;
	}

	private APIAction createSQLAction(Element actionElement, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		Element inputParametersElement = actionElement.element(Method.Constanst.INPUT);		
		Element expressionElement = actionElement.element(SqlAction.Constants.EXPRESSION);
		String expression = expressionElement.getText().trim();
		
		if(StringUtils.isEmpty(expression)){
			throw new Exception("Missing expression for sql action");
		}
		
		
		List<ActionInputParameter> inputParameters = getInputParameters(inputParametersElement);
		
		MethodOutputParameter outputParameter = null;
		List<MethodOutputParameter> outputParameters = getOutputParameters(actionElement.element(Method.Constanst.OUTPUT));
		if(outputParameters != null && outputParameters.size() > 0){
			outputParameter = outputParameters.get(0);
		} else {
			throw new Exception("Missing output parameter for sql action");
		}
		
		APIAction actionMethod = new SqlAction(expression, outputParameter, inputParameters, response.getProcessID());
		return actionMethod;
	}
	
	@SuppressWarnings("unchecked")
	private APIAction createIndexAction(Element actionElement, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		String tableName = actionElement.attributeValue(CreateIndexAction.Constanst.TABLE_NAME);
		if(StringUtils.isEmpty(tableName)){
			throw new Exception("Missing tableName attribute for createIndex action");
		}
		
		String indexName = actionElement.attributeValue(CreateIndexAction.Constanst.INDEX_NAME);
		if(StringUtils.isEmpty(tableName)){
			throw new Exception("Missing indexName attribute for createIndex action");
		}
		
		List<Element> columnElementList = actionElement.selectNodes(CreateIndexAction.Constanst.COLUMN_ELEMENT);
		
		List<String> columnNameList = new ArrayList<String>();
		if(columnElementList != null && columnElementList.size() > 0){
			for (Element columnElement : columnElementList) {
				String columnName = columnElement.attributeValue(CreateIndexAction.Constanst.NAME);
				columnNameList.add(columnName.toUpperCase());
			}
		} else {
			throw new Exception("Missing column element for createIndex action");
		}
		
		APIAction createIndexAction = new CreateIndexAction(tableName.toUpperCase(), indexName.toUpperCase(), columnNameList, response.getProcessID());
		return createIndexAction;
	}


	@SuppressWarnings("unchecked")
	private List<MethodOutputParameter> getOutputParameters(Element outputParameterElement) {
		List<MethodOutputParameter> parameterList = null;
		if(outputParameterElement != null){
			if(logger.isDebugEnabled()){
				logger.debug("parse outputParameter: content = \n" + outputParameterElement.asXML());
			}
			parameterList = new LinkedList<MethodOutputParameter>();
			
			List<Element> paramElementList = outputParameterElement.selectNodes(PARAM_ELEMENT);
			
			for (Element paramElement : paramElementList) {
				String name = paramElement.attributeValue(MethodOutputParameter.Constants.NAME);
				String type = paramElement.attributeValue(MethodOutputParameter.Constants.TYPE);
				String sysname = paramElement.attributeValue(MethodOutputParameter.Constants.SYSNAME);
				if(StringUtils.isEmpty(sysname)){
					sysname = name;
				}
				
				String tableName = paramElement.attributeValue(MethodOutputParameter.Constants.TABLENAME);
				String value = paramElement.getText();
				
				MethodOutputParameter methodParameter = new MethodOutputParameter(name, type, sysname, tableName, value);
				parameterList.add(methodParameter);
			}
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("getInputParameters() result = " + parameterList);
		}
		
		return parameterList;
	}

	@SuppressWarnings("unchecked")
	private List<ActionInputParameter> getInputParameters(Element inputParameterElement) throws Exception {
		List<ActionInputParameter> parameterList = null;
		if(inputParameterElement != null){
			if(logger.isDebugEnabled()){
				logger.debug("parse inputParameter: content = \n" + inputParameterElement.asXML());
			}
			parameterList = new LinkedList<ActionInputParameter>();
			
			List<Element> paramElementList = inputParameterElement.selectNodes(PARAM_CHILD);
			for (Element paramElement : paramElementList) {
				ActionInputParameter methodParameter = createActionInputParameterFromElement(paramElement);
				parameterList.add(methodParameter);
			}
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("getInputParameters() result = " + parameterList);
		}
		
		return parameterList;
	}

	private ActionInputParameter createActionInputParameterFromElement(Element paramElement) throws Exception {
		String name = paramElement.attributeValue(ActionInputParameter.Constants.NAME);
		String type = paramElement.attributeValue(ActionInputParameter.Constants.TYPE);
		String value = paramElement.getText();
		if(value != null){
			value = value.trim();
		}
		List<ActionInputParameter> subParametersList = parseListItems(paramElement);
		
		ActionInputParameter methodParameter = new ActionInputParameter(name, type, value, subParametersList);
		return methodParameter;
	}

	@SuppressWarnings("unchecked")
	private List<ActionInputParameter> parseListItems(Element paramElement) throws Exception {
		List<ActionInputParameter> subParametersList = new ArrayList<ActionInputParameter>();

		if(logger.isDebugEnabled()){
			logger.debug("Parsing ListItems for element: " + paramElement.asXML());
		}
		
		List<Element> listItemsElement = paramElement.selectNodes(LIST_ITEM_PARAMS);
		for (Element element : listItemsElement) {
			
			String name = element.attributeValue(ActionInputParameter.Constants.NAME);
			String type = element.attributeValue(ActionInputParameter.Constants.TYPE);
			String value = element.getText();
			
			ActionInputParameter subInputParameter = new ActionInputParameter(name, type, value, null);
			subParametersList.add(subInputParameter);
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("Parsing ListItems result: " + subParametersList);
		}

		return subParametersList;
	}
	
	private ActionInputParameter getMergeParameter(Element inputParametersElement) throws Exception {
		ActionInputParameter actionInputParameter = createActionInputParameterFromElement(inputParametersElement);
		return actionInputParameter;
	}
	
}
