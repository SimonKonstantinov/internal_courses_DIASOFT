package ru.diasoft.flextera.services.ftfcreportws.command.dao.history;

import java.sql.Types;

import org.apache.cayenne.map.DbAttribute;
import org.apache.cayenne.map.DbEntity;

import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;

public class ReportHistoryDBEntity {

	public static final String TABLENAME = "FCR_REPORTHISTORY";
	
	public interface Field {
		String REPORTHISTORYID = "REPORTHISTORYID";
		String REPORTID = "REPORTID";
		String PROCESSID = "PROCESSID";
		String USERLOGIN = "USERLOGIN";
		String STARTDATE = "STARTDATE";
		String ENDDATE = "ENDDATE";
		String EXECUTESTATUS = "EXECUTESTATUS";
		String REPORTFILEPATH = "REPORTFILEPATH";
	}

	private static DbEntity dbEntity = null;
	
	public static DbEntity getDbEntity() {
		if (dbEntity == null) {
			dbEntity = new DbEntity();
			dbEntity.setName(TABLENAME);
			dbEntity.setDataMap(DataUtils.getCommonUserMap());
			dbEntity.addAttribute(new DbAttribute(Field.REPORTHISTORYID, Types.BIGINT, dbEntity));			
			dbEntity.addAttribute(new DbAttribute(Field.REPORTID, Types.BIGINT, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.PROCESSID, Types.BIGINT, dbEntity));			            
			dbEntity.addAttribute(new DbAttribute(Field.USERLOGIN, Types.VARCHAR, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.STARTDATE, Types.BIGINT, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.ENDDATE, Types.BIGINT, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.EXECUTESTATUS, Types.INTEGER, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.REPORTFILEPATH, Types.VARCHAR, dbEntity));            
		}		
		return dbEntity;
	}
	
}
