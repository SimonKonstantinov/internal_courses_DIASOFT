package ru.diasoft.flextera.services.ftfcreportws.report.parser;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import ru.diasoft.flextera.services.ftfcreportws.type.TInputParamterListTypeForDSFCReportFindInputParameterListByReportID;
import ru.diasoft.flextera.services.ftfcreportws.type.TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID;
import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportFindInputParameterListByReportIDRes;
import ru.diasoft.utils.text.StringUtils;

public class InputParametersParser {

	private static final String MISSING_REQUIRED_PARAMETER_MESSAGE_SIMPLE = "Missing required parameter: sysname/name/type for simple inputParameter";
	private static final String MISSING_REQUIRED_PARAMETER_MESSAGE_COLLECTION = "Missing required parameter: sysname/name/type for simple collectionParameter";
	private Logger logger = Logger.getLogger(InputParametersParser.class);
	private static InputParametersParser INSTANCE = new InputParametersParser();
	private static final String INPUT_PARAMETERS = "//inputParameters";
	private static final String PARAMETER = "parameter";
	private static final String CHILD_PARAMETERS = ".//parameter";

	private static final String LIST = "java.util.list";

	public static InputParametersParser getInstance() {
		return INSTANCE;
	}

	private InputParametersParser() {
	}

	@SuppressWarnings("unchecked")
	public void createInputParametersFromFile(File file, DsFCReportFindInputParameterListByReportIDRes response) throws Exception {
		SAXReader reader = new SAXReader();
		Document document = reader.read(file);
		Node inputParamsNode = document.selectSingleNode(INPUT_PARAMETERS);

		List<Element> paramsList = inputParamsNode.selectNodes(PARAMETER);
		if (paramsList.size() > 0) {
			List<TInputParamterListTypeForDSFCReportFindInputParameterListByReportID> inputParameterList = new ArrayList<TInputParamterListTypeForDSFCReportFindInputParameterListByReportID>();
			List<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID> collectionParameterList = new ArrayList<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID>();

			for (Element currentElement : paramsList) {
				
				TInputParamterListTypeForDSFCReportFindInputParameterListByReportID parameterType = processSimpleInputParameter(currentElement); 
				inputParameterList.add(parameterType);
				
				if (parameterType.getInputParameterType().equalsIgnoreCase(LIST)) {
					List<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID> currentCollectionParameterList = processCollectionInputParameters(currentElement);
					if(currentCollectionParameterList != null && currentCollectionParameterList.size() > 0){
						collectionParameterList.addAll(currentCollectionParameterList);
					}
				}

			}

			response.setInputParamterList(inputParameterList);
			response.setParameterKeyList(collectionParameterList);
		}

	}

	private TInputParamterListTypeForDSFCReportFindInputParameterListByReportID processSimpleInputParameter(Element currentElement) throws Exception {
		TInputParamterListTypeForDSFCReportFindInputParameterListByReportID parameterType;
		parameterType = new TInputParamterListTypeForDSFCReportFindInputParameterListByReportID();
		String sysname = currentElement.attributeValue(InputParameter.Fields.SYSNAME);
		String name = currentElement.attributeValue(InputParameter.Fields.NAME);
		String type = currentElement.attributeValue(InputParameter.Fields.TYPE);

		if (StringUtils.isEmpty(sysname) || StringUtils.isEmpty(name) || StringUtils.isEmpty(type)) {
			if (logger.isDebugEnabled()) {
				logger.error(MISSING_REQUIRED_PARAMETER_MESSAGE_SIMPLE);
			}
			throw new Exception(MISSING_REQUIRED_PARAMETER_MESSAGE_SIMPLE);
		}
		parameterType.setInputParameterSysName(sysname);
		parameterType.setInputParameterName(name);
		parameterType.setInputParameterType(type);

		String requiredValue = currentElement.attributeValue(InputParameter.Fields.REQUIRED);
		if (requiredValue != null && requiredValue.equalsIgnoreCase(Boolean.TRUE.toString())) {
			parameterType.setInputParameterRequiredFlag(true);
		} else {
			parameterType.setInputParameterRequiredFlag(false);
		}
		parameterType.setInputParameterDefaultValue(currentElement.attributeValue(InputParameter.Fields.DEFAULT_VALUE));
		return parameterType;
	}

	@SuppressWarnings("unchecked")
	private List<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID> processCollectionInputParameters(Element currentElement) throws Exception {
		List<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID> collectionParameterList = new ArrayList<TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID>();
		
		List<Element> collectionElementList = currentElement.selectNodes(CHILD_PARAMETERS);
		if(collectionElementList != null && collectionElementList.size() > 0){
			for(Element currentCollectionElement : collectionElementList){
				TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID elementListType = new TParameterKeyListTypeForDSFCReportFindInputParameterListByReportID();
				elementListType.setInputParameterSysName(currentElement.attributeValue(InputParameter.Fields.SYSNAME));
				
				String collectionElementSysname = currentCollectionElement.attributeValue(InputParameter.Fields.SYSNAME);
				String collectionElementName = currentCollectionElement.attributeValue(InputParameter.Fields.NAME);
				String collectionElementType = currentCollectionElement.attributeValue(InputParameter.Fields.TYPE);
				
				if (StringUtils.isEmpty(collectionElementSysname) || StringUtils.isEmpty(collectionElementName) || StringUtils.isEmpty(collectionElementType)) {
					if (logger.isDebugEnabled()) {
						logger.error(MISSING_REQUIRED_PARAMETER_MESSAGE_COLLECTION);
					}
					throw new Exception(MISSING_REQUIRED_PARAMETER_MESSAGE_COLLECTION);
				}
				
				elementListType.setParameterKeySysName(collectionElementSysname);
				elementListType.setParameterKeyName(collectionElementName);
				elementListType.setParameterKeyType(collectionElementType);
				
				String requiredValue = currentCollectionElement.attributeValue(InputParameter.Fields.REQUIRED);
				if (requiredValue != null && requiredValue.equalsIgnoreCase(Boolean.TRUE.toString())) {
					elementListType.setParameterKeyRequiredFlag(true);
				} else {
					elementListType.setParameterKeyRequiredFlag(false);
				}

				collectionParameterList.add(elementListType);
			}
		}
		return collectionParameterList;
	}
}
