package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.util.List;
import java.util.Map;

import ru.diasoft.utils.text.StringUtils;

public abstract class APIAction {

	public abstract void execute(Map<String, Object> inputParams) throws Exception;

	protected void renameParameters(ActionInputParameter actionInputParameter, List<Map<String, Object>> resultUnionList) {
		if (resultUnionList == null) {
			return;
		}
		
		for (ActionInputParameter actionInputParam : actionInputParameter.getSubParametersList()) {
			
			String actionInputParamValue = actionInputParam.getValue();
			if (!StringUtils.isEmpty(actionInputParamValue) && actionInputParamValue.startsWith("@") && actionInputParamValue.endsWith("@")) {
				actionInputParamValue = actionInputParamValue.replaceAll("@", "");
				
				for (Map<String, Object> row : resultUnionList) {
					row.put(actionInputParam.getName(), row.get(actionInputParamValue));
				}
			}
		}

	}

}
