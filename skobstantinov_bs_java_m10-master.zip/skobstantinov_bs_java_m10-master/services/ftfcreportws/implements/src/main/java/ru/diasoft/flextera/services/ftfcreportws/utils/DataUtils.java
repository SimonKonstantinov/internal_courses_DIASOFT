package ru.diasoft.flextera.services.ftfcreportws.utils;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.cayenne.QueryResponse;
import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.Transaction;
import org.apache.cayenne.map.DataMap;
import org.apache.cayenne.query.NamedQuery;
import org.apache.cayenne.query.Query;
import org.apache.log4j.Logger;

import ru.diasoft.core.util.sandbox.Sandbox;
import ru.diasoft.services.common.QueryBuilder;

public class DataUtils {

    public static final String TOTALCOUNT = "TOTALCOUNT";
    
	private static Logger logger = Logger.getLogger(DataUtils.class);
	
	public static DataContext getDataContext() {
		return Sandbox.INSTANCE.singleProvider(DataContext.class);
	}

	public static DataMap getCommonUserMap() {
		DataDomain dataDomain = Sandbox.INSTANCE.singleProvider(DataDomain.class);
		return dataDomain.getMap("CommonUserMap");
	}
	
	@SuppressWarnings("unchecked")
	public static List<Map<String, Object>> performQuery(String queryName, Map<String, Object> queryParams) throws Exception {
		List<Map<String, Object>> result = null;
		Transaction tx = Transaction.getThreadTransaction();
		try {			
			Transaction.bindThreadTransaction(null);
			result = getDataContext().performQuery(new NamedQuery(queryName, queryParams));
		}
		finally {
			Transaction.bindThreadTransaction(tx);
		}
		return result; 
	}
	
	public static int[] performCommitQuery(String queryName, Map<String, Object> queryParams) throws Exception {
		int[] result = null;
		Transaction tx = Transaction.getThreadTransaction();
		try {			
			Transaction.bindThreadTransaction(null);
			result = getDataContext().performNonSelectingQuery(new NamedQuery(queryName, queryParams));
		}
		finally {
			Transaction.bindThreadTransaction(tx);
		}
		return result;
	}
	
	public static QueryResponse performGenericQuery(Query query) throws Exception {
		QueryResponse result = null;
		Transaction tx = Transaction.getThreadTransaction();
		try {			
			Transaction.bindThreadTransaction(null);
			result = getDataContext().performGenericQuery(query);
		}
		finally {
			Transaction.bindThreadTransaction(tx);
		}
		return result;
	}
	
	public static Long getNewId(String forTable) throws Exception {
		return QueryBuilder.getNewIdLong(forTable, 1);
	}
	
    @SuppressWarnings("unchecked")
	public static List<Map<String, Object>> getListFromResultMap(Map<String, Object> data) {
        List<Map<String, Object>> list = null;
        if (data != null) {
            list = (List<Map<String, Object>>) data.get("Result");
        }

        return list;
    }

	public static Map<String, Object> getList(String countQuery, String selectQuery,
			Map<String, Object> params) throws Exception {
		Map<String, Object> result = QueryBuilder.getList(getDataContext(), countQuery, selectQuery, params);
		return result;
	}

    public static DataBaseType getCurrentDBType(DataSource dataSource) {
        DataBaseType result = DataBaseType.UNKNOWN;
        Connection connection = null;

        try {
        	if(dataSource == null){
            	dataSource = ConfigUtils.getProductDataSource();
        	}
        	
        	connection = dataSource.getConnection();
        	DatabaseMetaData metaData = connection.getMetaData();
            String dbName = metaData.getDatabaseProductName();

            if (dbName.toUpperCase().contains("ORACLE")) {
                result = DataBaseType.ORACLE;
            } else {
                if (dbName.toUpperCase().contains("MICROSOFT SQL SERVER")) {
                    result = DataBaseType.MSSQL;
                } else {
                    if (dbName.toUpperCase().contains("DB2")) {
                        result = DataBaseType.DB2;
                    } else {
                    	if(dbName.toUpperCase().contains("H2")){
                    		result = DataBaseType.H2;
                    	} else {
                            String driver = metaData.getDriverName();
                            if (driver != null && driver.toLowerCase().startsWith("jtds")) {
                                String url = metaData.getURL();
                                if (url != null && url.toLowerCase().startsWith("jdbc:jtds:sybase:")) {
                                    result = DataBaseType.SYBASE;
                                }
                            } else {
                                if (dbName.toUpperCase().contains("ADAPTIVE SERVER")) {
                                    result = DataBaseType.SYBASE;
                                }
                            }
                        }

                    } 
                }
            }
        } catch (Exception e) {
            logger.error("Error occurred while retrieving database type: ", e);
        } finally{
        	if(connection != null){
        		try {
					connection.close();
				} catch (SQLException e) {
					logger.error("Error occurred while retrieving database type (close connection): ", e);
				}
        	}
        }
        return result;
    }

}
