package ru.diasoft.flextera.services.ftfcreportws.report.database.creator;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;

public class TableColumns implements Serializable{

	private static final long serialVersionUID = -8420346175970699202L;
	
	private Map<String, String> columnsMap = null;
	
	private String columnsForCreateTable;
	
	public TableColumns(Map<String, String> columnsMap, String columnsForCreateTable) {
		super();
		this.columnsMap = columnsMap;
		this.columnsForCreateTable = columnsForCreateTable;
	}

	public Map<String, String> getColumnsMap() {
		return columnsMap;
	}

	public void setColumnsMap(Map<String, String> columnsMap) {
		this.columnsMap = columnsMap;
	}

	public String getColumnsForCreateTable() {
		return columnsForCreateTable;
	}

	public void setColumnsForCreateTable(String columnsForCreateTable) {
		this.columnsForCreateTable = columnsForCreateTable;
	}
	
	public String getColumnNamesForInsertQuery(){
		StringBuilder columnNames = new StringBuilder();
		for (Iterator<String> iterator = columnsMap.keySet().iterator(); iterator.hasNext();) {
			String key = iterator.next();
			columnNames.append(key);
			
			if(iterator.hasNext()){
				columnNames.append(", ");
			}
		}
		
		return columnNames.toString();
	}
	
}
