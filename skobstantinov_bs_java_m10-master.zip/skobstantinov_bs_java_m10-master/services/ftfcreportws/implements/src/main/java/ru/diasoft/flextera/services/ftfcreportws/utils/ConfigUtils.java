package ru.diasoft.flextera.services.ftfcreportws.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import ru.diasoft.services.config.Config;
import ru.diasoft.services.config.exception.ConfigException;
import ru.diasoft.utils.text.StringUtils;

public class ConfigUtils {
	
	public static final String WS_CONFIG = "ftfcreportws";
	public static final String PROPERTIES_FILE = "project.properties";
	
	public static final String PATH_TO_REPORT_CONFIG = "pathToReportConfig";
	private static String pathToReportConfig;

	public static final String PATH_TO_REPORT_DIRECTORY = "pathToReportDirectory";
	private static String pathToReportDirectory;
	
	public static final String ROWS_COUNT = "rowsCount";
	private static Integer rowsCountParam;

	private static final String COREWS = "corews";
	private static final String COREWS_DEFAULT = "[corews]";
	
	private static final String REPORTWS = "reportws";
	private static final String REPORTWS_DEFAULT = "[reportws]";

	private static final String CRMWS = "crmws";
	private static final String CRMWS_DEFAULT = "[crmws]";
	
	private static DataSource dataSource;
	
	private static Map<String, Object> projectConfigMap;
	
	private static Logger logger = Logger.getLogger(ConfigUtils.class); 

	public static String getCoreWS() {		
		return Config.getConfig(WS_CONFIG).getParam(COREWS, COREWS_DEFAULT);
	}
	
	public static String getReportWS() {
		return Config.getConfig(WS_CONFIG).getParam(REPORTWS, REPORTWS_DEFAULT);	
	}

	public static String getCrmWS() {
		return Config.getConfig(WS_CONFIG).getParam(CRMWS, CRMWS_DEFAULT);	
	}
	
	public static String getPathToReportConfig(){
		if(pathToReportConfig == null){
			pathToReportConfig = Config.getConfig(WS_CONFIG).getParam(PATH_TO_REPORT_CONFIG, "");
		}
		return pathToReportConfig;
	}

	public static String getPathToReportDirectory() {
		if(pathToReportDirectory == null){
			pathToReportDirectory = Config.getConfig(WS_CONFIG).getParam(PATH_TO_REPORT_DIRECTORY, "");
		}
		return pathToReportDirectory;
	}

	
    public static String getProjectProperty(String propertyName) {
    	return getProjectProperty(propertyName, true);
    }

    public static String getProjectProperty(String propertyName, boolean checkRequired) {
    	String result;
    	
		try {
			result = getPropertyFromResource(PROPERTIES_FILE, propertyName);
		} 
		catch (IOException e) {
			throw new RuntimeException(e); 
		}
    	
    	if (checkRequired && StringUtils.isEmpty(result)) {
    		throw new IllegalArgumentException(
    				"File " + PROPERTIES_FILE + " property is not set '" + 
    						propertyName + "'.");
    	}
    	
    	return result;
    }

    public static String getPropertyFromResource(final String resource, String name) throws IOException {
    	String result = null;
    	
        InputStream inputStream = getResourceAsStream(resource);
        if (inputStream == null) {
            throw new IllegalArgumentException("Not specified file 'project.properties' for the project.");
        }
        try {
            Properties properties = new Properties();
            properties.load(inputStream);
            result = properties.getProperty(name);
        } finally {
            inputStream.close();
        }
        
        return result;
    }

    /**
     * Gets the resource as stream.
     * 
     * @param resource the resource
     * 
     * @return the resource as stream
     */
    public static InputStream getResourceAsStream(final String resource) {
        final String stripped = resource.startsWith("/") ? resource.substring(1) : resource;

        InputStream stream = null;
        final ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        if (classLoader != null) {
            stream = classLoader.getResourceAsStream(stripped);
        }
        if (stream == null) {
            stream = ConfigUtils.class.getResourceAsStream(resource);
        }
        if (stream == null) {
            stream = ConfigUtils.class.getClassLoader().getResourceAsStream(stripped);
        }
        if (stream == null) {
            // Если не нашли внутри сборки , попробуем найти файл на сервере.
            File file = new File(resource);
            if (file != null) {
                try {
                    stream = new FileInputStream(file);
                } catch (FileNotFoundException e) {
                	logger.error(e.getLocalizedMessage(), e);
                }
            }
        }
        return stream;
    }
    
    public static DataSource getProductDataSource() throws ConfigException{
    	if(dataSource == null){
    		dataSource = Config.getConfig(ConfigUtils.WS_CONFIG).getDataSource();
    	}
    	return dataSource;
    }

	public static Map<String, Object> getProjectConfigMap() {
		if(projectConfigMap == null){
			projectConfigMap = Config.getConfig(ConfigUtils.WS_CONFIG).getAllParams();
		}
		return projectConfigMap;
	}

	public static int getRowsCountParam() {
		if(rowsCountParam == null){
			rowsCountParam = Integer.valueOf(Config.getConfig(ConfigUtils.WS_CONFIG).getParam(ROWS_COUNT, ProjectConstants.ROWSCOUNT_DEFAULT_VALUE));
		}
		return rowsCountParam;
	}

	/**
	 * For Unit-tests
	 * @param rowsCountParam
	 */
	public static void setRowsCountParam(Integer rowsCountParam) {
		ConfigUtils.rowsCountParam = rowsCountParam;
	}

	
}
