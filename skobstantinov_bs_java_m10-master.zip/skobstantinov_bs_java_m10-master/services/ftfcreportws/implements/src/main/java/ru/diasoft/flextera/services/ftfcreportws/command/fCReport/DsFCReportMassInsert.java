package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import org.apache.log4j.Logger;import ru.diasoft.core.application.command.CommandException;import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportDAO;import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportMassInsertResult;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportMassInsertReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportMassInsertRes;
/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportMassInsert extends DsFCReportMassInsertStub {
	
	private static final Logger logger = Logger.getLogger(DsFCReportMassInsert.class);	public static final String METHOD_NAME = "dsFCReportMassInsert";		/**
	 * Метод добавления пользовательских отчетов
	 * 
	 * @param FCReportList Основные параметры отчета
	 * 
	 * @return FCReportIDList Список идентификаторов отчетов
	 * @return NotificationList Список ошибок
	 */
	@Override
	protected void executeCommand() throws CommandException {
		DsFCReportMassInsertReq request = getInputData();		DsFCReportMassInsertRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());		}		try {			ReportMassInsertResult massInsertResult = ReportDAO.getInstance().massInsert(request.getFCReportList(), getContext().getLogin());			response.setFCReportIDList(massInsertResult.getReportIDList());			response.setNotificationList(massInsertResult.getReportNtfList());			response.setReturnCode(massInsertResult.getReturnCode());			response.setReturnMsg(massInsertResult.getReturnMsg());						if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());			}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);			CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}
	}
}
