package ru.diasoft.flextera.services.ftfcreportws.report.database.creator;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import ru.diasoft.flextera.services.ftfcreportws.utils.DataBaseType;

public class TableUpdaterFactory {

	public static TableUpdater getTableUpdater(Object value, Long processID, ResultSet columnsResultSet, DataBaseType dataBaseType) throws Exception {
		if(value instanceof Map){
			return new MapTableUpdater(value, processID, columnsResultSet, dataBaseType);
		}else if(value instanceof List) {
			return new ListTableUpdater(value, processID, columnsResultSet, dataBaseType);
		}else {
			return new SimpleTableUpdater(value, processID, columnsResultSet, dataBaseType);
		}
	}
}
