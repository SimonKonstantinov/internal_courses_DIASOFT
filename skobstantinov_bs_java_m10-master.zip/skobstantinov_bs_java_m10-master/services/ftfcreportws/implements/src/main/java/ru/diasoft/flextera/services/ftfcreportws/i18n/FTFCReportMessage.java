package ru.diasoft.flextera.services.ftfcreportws.i18n;

import java.util.Locale;
import java.util.ResourceBundle;

import ru.diasoft.flextera.services.ftfcreportws.utils.context.EnvironmentHolder;
import ru.diasoft.utils.text.StringUtils;

public class FTFCReportMessage {
	
	public static String getLocalizedString(String keyString, String localeString) {   
		String result = keyString;
		
		Locale locale = null;
		if(!StringUtils.isEmpty(localeString)){
			locale = new Locale(localeString);
		} else {
			locale = EnvironmentHolder.currentContext().getLocale();
		}
		
        ResourceBundle bundle = ResourceBundle.getBundle("i18n.FTFCReportMessage", locale);
        if (bundle.containsKey(keyString)) {
            result = bundle.getString(keyString);
        }
        return result;
    }
	
	public static String formatLocalizedString(String keyString, Object ... args) {  
		return String.format(getLocalizedString(keyString, null), args);
	}
	
}
