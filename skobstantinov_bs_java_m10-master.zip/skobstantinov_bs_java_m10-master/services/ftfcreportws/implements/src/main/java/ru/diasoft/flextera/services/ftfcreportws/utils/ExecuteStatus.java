package ru.diasoft.flextera.services.ftfcreportws.utils;

public enum ExecuteStatus {

	IN_PROCESS(1),
	DONE(2),
	ERROR(3);
	
	private int stateCode;
	
	private ExecuteStatus(int stateCode) {
		this.stateCode = stateCode;
	}

	public int getStateCode() {
		return stateCode;
	}
}
