package ru.diasoft.flextera.services.ftfcreportws.report.method;

public enum APIActionType {

	METHOD,
	MERGE,
	UNION,
	JOIN,
	LEFTJOIN,
	SQL,
	CREATEINDEX;
}
