package ru.diasoft.flextera.services.ftfcreportws.utils.event;

import java.util.Map;

import ru.diasoft.core.application.dto.AbstractTransferObject;

public interface EventFacade {

	public Map<String, Object> triggerEvent(boolean isAsync, String eventName, AbstractTransferObject eventParams);

}
