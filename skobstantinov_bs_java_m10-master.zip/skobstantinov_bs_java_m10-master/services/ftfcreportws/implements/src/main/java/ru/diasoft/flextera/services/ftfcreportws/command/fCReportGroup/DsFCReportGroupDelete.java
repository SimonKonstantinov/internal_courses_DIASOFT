package ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroupDAO;import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroupDeleteResult;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportGroupDeleteReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportGroupDeleteRes;
import org.apache.log4j.Logger;
import ru.diasoft.core.application.command.CommandException;

/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportGroupDelete extends DsFCReportGroupDeleteStub {
	
	/**
	 * Удаление группы пользовательских отчетов
	 * 
	 * @param FCReportGroupID Идентификатор группы пользовательских отчетов
	 * 
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */		private static final Logger logger = Logger.getLogger(DsFCReportGroupDelete.class);	private static final String METHOD_NAME = "dsFCReportGroupDelete";	
	@Override
	protected void executeCommand() throws CommandException {		DsFCReportGroupDeleteReq request = getInputData();		DsFCReportGroupDeleteRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());					}		try {			ReportGroupDeleteResult result = ReportGroupDAO.getInstance().delete(request.getFCReportGroupID());			response.setReturnCode(result.getReturnCode());			response.setReturnMsg(result.getReturnMsg());								} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);						CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}		
		
	}
}
