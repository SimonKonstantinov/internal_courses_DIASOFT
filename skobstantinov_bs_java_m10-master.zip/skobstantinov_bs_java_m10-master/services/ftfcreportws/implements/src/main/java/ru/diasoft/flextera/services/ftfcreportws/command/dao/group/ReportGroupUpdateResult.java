package ru.diasoft.flextera.services.ftfcreportws.command.dao.group;

public class ReportGroupUpdateResult {
	private Long   returnCode;
	private String returnMsg;

	private Long   reportGroupID;

	public Long getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Long returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public Long getReportGroupID() {
		return reportGroupID;
	}

	public void setReportGroupID(Long reportGroupID) {
		this.reportGroupID = reportGroupID;
	}
}
