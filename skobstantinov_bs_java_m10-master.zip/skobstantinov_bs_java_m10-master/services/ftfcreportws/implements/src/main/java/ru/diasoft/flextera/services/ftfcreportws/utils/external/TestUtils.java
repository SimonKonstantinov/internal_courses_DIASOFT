package ru.diasoft.flextera.services.ftfcreportws.utils.external;

import java.util.HashMap;
import java.util.Map;

public class TestUtils {

	private static Map<TestResponseKey,Map<String, Object>> testResponses = new HashMap<TestResponseKey,Map<String, Object>>();

	public static Map<TestResponseKey, Map<String, Object>> getTestResponses() {
		return testResponses;
	}

	/**
	 * Добавление ответа от метода в зависимости от того, какие в него переданы
	 * параметры
	 * 
	 * @param serviceName
	 * @param methodName
	 * @param input
	 * @param methodResponse
	 */
	public static void addMethodResponseByParams(String serviceName,
			String methodName, Map<String, Object> input, Map<String, Object> methodResponse) {

		putTestResponseByParams(getCombinedName(serviceName, methodName), input, methodResponse);

	}
	
	public static void addMethodResponse(String serviceName, String methodName,
			Map<String, Object> methodResponse) {

		putTestResponse(getCombinedName(serviceName, methodName),
				methodResponse);
	}
	
	public static String getCombinedName(String serviceName, String methodName) {
        if (serviceName.startsWith("[") && serviceName.endsWith("]")) {
            serviceName = serviceName.substring(1,serviceName.length()-1);
        }
        return serviceName + "$" + methodName;
    }
	
	/**
	 * Сохранение ответа от сервиса в зависимости от переданных в него параметром
	 * @param key
	 * @param input
	 * @param value
	 */
	public static void putTestResponseByParams(String key, Map<String, Object> input ,Map<String, Object> value) {
		TestResponseKey trKey = new TestResponseKey(key, input);
		testResponses.put(trKey, value);
	}

	public static void putTestResponse(String key, Map<String, Object> value) {
		putTestResponseByParams(key, null, value);
	}
	
	public static Map<String, Object> getMethodResponse(String serviceName, String methodName, Map<String, Object> params) {
		// сначала попробуем получить подходящий ответ от метода по входным
		// параметрам
		Map<String, Object> result = getMethodResponseByParams(serviceName,
				methodName, params);

		if (result == null) {
			// попробуем взять хоть какой то ответ "по умолчанию"
			result = getMethodResponseByParams(serviceName, methodName, null);
		}
		return result;
	}
	
	/**
	 * Метод возвращает ответ от вызываемого сервиса по переданным в него параметрам
	 * @param serviceName
	 * @param methodName
	 * @param input - параметры вызова внешнего сервиса
	 * @return
	 */
	private static Map<String, Object> getMethodResponseByParams(String serviceName,
			String methodName, Map<String, Object> input) {
		TestResponseKey key = new TestResponseKey(getCombinedName(serviceName, methodName), input);
		return getTestResponses().get(key);

	}
	
	
	private static class TestResponseKey {
		private String method;
		private Map<String, Object> input;

		private TestResponseKey(String method, Map<String, Object> input) {
			this.method = method;
			this.input = input;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;

			TestResponseKey that = (TestResponseKey) o;

			if (input != null ? !input.equals(that.input) : that.input != null) return false;
			if (method != null ? !method.equals(that.method) : that.method != null) return false;

			return true;
		}

		@Override
		public int hashCode() {
			int result = method != null ? method.hashCode() : 0;
			result = 31 * result + (input != null ? input.hashCode() : 0);
			return result;
		}
	}
	
}
