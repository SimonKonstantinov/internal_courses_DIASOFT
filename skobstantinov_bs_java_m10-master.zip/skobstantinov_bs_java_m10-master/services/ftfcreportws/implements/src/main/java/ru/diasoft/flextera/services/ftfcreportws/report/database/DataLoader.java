package ru.diasoft.flextera.services.ftfcreportws.report.database;

import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.BIG_DECIMAL_PRECISION_28;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.BIG_DECIMAL_SCALE_10;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.BOOLEAN_PRECISION_25;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DATE_PRECISION_21;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DATE_SCALE_0;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DELETE_FROM;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.FCR;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.INT;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.INTEGER_ORACLE_PRECISION;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.LONG_PRECISION_19;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.NUM;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.STRING_PRECISION_3500;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.VARCHAR;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.WHERE_PROCESSID;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.SCIENTIFIC_ZERO;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.cayenne.access.DataDomain;
import org.apache.log4j.Logger;

import ru.diasoft.core.util.sandbox.Sandbox;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;
import ru.diasoft.flextera.services.ftfcreportws.i18n.FTFCReportMessage;
import ru.diasoft.flextera.services.ftfcreportws.report.database.creator.TableUpdater;
import ru.diasoft.flextera.services.ftfcreportws.report.database.creator.TableUpdaterFactory;
import ru.diasoft.flextera.services.ftfcreportws.report.method.ActionInputParameter;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataBaseType;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;
import ru.diasoft.utils.text.StringUtils;

public class DataLoader {

	public static final String INDEX_NAME = "INDEX_NAME";
	private static final String CREATE_INDEX = "CREATE INDEX %s ON %s (%s)";
	private static Logger logger = Logger.getLogger(DataLoader.class);
	private static DataSource dataSource = null;
	
	static {
		DataDomain domain = Sandbox.INSTANCE.singleProvider(DataDomain.class);
		dataSource = domain.getNode(DatabaseConstants.NODE_NAME).getDataSource(); 
	}
	
	public static DataLoader getInstance() {
		return new DataLoader();
	}


	/**
	 * Only for test purpose!
	 * 
	 * @param dataSource
	 */
	public static void setDataSource(DataSource dataSource) {
		DataLoader.dataSource = dataSource;
	}
	
	public static DataSource getDataSource() {
		return dataSource;
	}

	private DataLoader(){
	}

	public void load(String tableName, Object parameterValue, Long processID) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Load data into table " + tableName + ", value = " + parameterValue);
		}
		
		if(parameterValue == null){
			if(logger.isDebugEnabled()){
				logger.debug("parameterValue is null. Skip loading.");
			}
			return;
		}
		
		if(StringUtils.isEmpty(tableName)){
			if(logger.isDebugEnabled()){
				logger.debug("tableName is empty. Skip loading.");
			}
			return;
		}
		
		tableName = tableName.toUpperCase();
		
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			
			DataBaseType dataBaseType = DataUtils.getCurrentDBType(dataSource);
			boolean isOracle = DataBaseType.ORACLE.equals(dataBaseType);
			
			String catalog = connection.getCatalog();
			DatabaseMetaData databaseMetaData = connection.getMetaData();
			String schemaName = null;
			if(isOracle){
				schemaName = databaseMetaData.getUserName();
			}
			ResultSet tablesResultSet = databaseMetaData.getTables(catalog, schemaName, tableName, null);
			
			TableUpdater tableUpdater = null;
			if(tablesResultSet.next()){
				
				if(logger.isDebugEnabled()){
					logger.debug("Table " + tableName + " exists.");
				}
				ResultSet columnsResultSet = databaseMetaData.getColumns(catalog, schemaName, tableName, null);
				
				try {
					tableUpdater = TableUpdaterFactory.getTableUpdater(parameterValue, processID, columnsResultSet, dataBaseType);
					tableUpdater.modifyTable(connection, schemaName, tableName, parameterValue);
				} catch (Exception e) {
					// Протокол "Ошибка изменения структуры таблицы"
					ProtocolDAO.getInstance().addReportProtocol(processID, ProtocolMessage.ALTER_TABLE_ERROR, tableName);
				
					logger.error(FTFCReportMessage.formatLocalizedString("protocol.modify.table.error", tableName));
					throw new Exception(e);					
				}				
				
			} else {
				if(logger.isDebugEnabled()){
					logger.debug("Table " + tableName + " doesn't exist.");
				}
				try {
					tableUpdater = TableUpdaterFactory.getTableUpdater(parameterValue, processID, null, dataBaseType);
					tableUpdater.createTable(connection, schemaName, tableName, parameterValue);
					// Протокол "Создана таблица"
					ProtocolDAO.getInstance().addReportProtocol(processID, ProtocolMessage.CREATE_TABLE, tableName);
				} catch (Exception e) {
					// Протокол "Ошибка создания таблицы"
					ProtocolDAO.getInstance().addReportProtocol(processID, ProtocolMessage.CREATE_TABLE_ERROR, tableName);
					
					logger.error(FTFCReportMessage.formatLocalizedString("protocol.create.table.error", tableName));
					throw new Exception(e);					
				}
			}
			
			//TODO: перед добавлением проверять, соотвествуют ли типы столбцов переданным данным.
			tableUpdater.insertData(connection, schemaName, tableName, parameterValue);
			
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
			throw new Exception(e);
		}finally{
			if(connection != null){
				connection.close();
			}
		}
	}
	
	public void deleteTempData(Set<String> tableNames, Long processID) throws SQLException{
		if(logger.isDebugEnabled()){
			logger.debug("deleteTempData has started, tableNames = " + tableNames + " processID = " + processID);
		}
		
		Connection connection = null;
		Statement statement = null;
		try {
			connection = dataSource.getConnection();
			
			boolean hasBatch = false;
			statement = connection.createStatement();
			for (String tableName : tableNames) {
				ResultSet tablesResultSet = getTablesResultSet(connection, tableName);
				if(!tableName.startsWith(FCR) && tablesResultSet.next()){
					hasBatch = true;
					
					String deleteQuery = DELETE_FROM + tableName + WHERE_PROCESSID + processID;
					
					if(logger.isDebugEnabled()){
						logger.debug("clear temp data from table : " + tableName + "; sql = " + deleteQuery);
					}
					
					statement.addBatch(deleteQuery);
				}
			}
			
			if(hasBatch){
				statement.executeBatch();
				
				if(!connection.getAutoCommit()){
					connection.commit();
				}
			}
			
		} finally{
			if(statement != null){
				statement.close();
			}
			if(connection != null){
				connection.close();
			}
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("deleteTempData has finished");
		}
		
	}
	
	
	private String replaceQueryParams(String expression,List<ActionInputParameter> inputParameterList,
			Map<String, Object> inputParams) {
			if (inputParameterList!=null ) {
			for (ActionInputParameter inputParam : inputParameterList) {
				String paramName = inputParam.getName();

				String parameterStringValue = inputParam.getValue();
				Object value = null; 

				if(parameterStringValue.startsWith("@") && parameterStringValue.endsWith("@")
						&& inputParams!=null){
					String key = parameterStringValue.replaceAll("@", "");
					value = inputParams.get(key);
					
					if(logger.isDebugEnabled()){
						logger.debug("method input parameter value: " + value);
					}
					
				}
				
				String sqlParamValue=TableUpdater.convertParamValueToSQLString(value);
				StringBuilder replaceParamName = new StringBuilder("@").append(
						paramName.toUpperCase()).append("@");
				expression = expression.toUpperCase().replaceAll(
						replaceParamName.toString(), sqlParamValue);

			}
		}
		return expression;
		
	}

	public List<Map<String, Object>> executeQuery(String expression, Long processID, List<ActionInputParameter> inputParameterList,
			Map<String, Object> inputParams) throws Exception{
		List<Map<String, Object>> result = new ArrayList<Map<String,Object>>();
		
		if(logger.isDebugEnabled()){
			logger.debug("Execute sql query " + expression);
		}
		
		if(StringUtils.isEmpty(expression)){
			throw new Exception("Missing required parameter [expression]");
		}
		
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			
			String schemaName = getSchemaName(connection);
			if(schemaName == null){
				schemaName = "";
			} else {
				schemaName += ".";
			}
			
			expression = expression.toUpperCase().replaceAll("@PROCESSID@", String.valueOf(processID));
			expression = expression.toUpperCase().replaceAll("@SCHEMA@.", schemaName);
			
			expression= replaceQueryParams(expression, inputParameterList, inputParams);
			
			if(logger.isDebugEnabled()){
				logger.debug("Processed query = " + expression);
			}
			PreparedStatement query = connection.prepareStatement(expression);
			
			ResultSet resultSet = query.executeQuery();
			ResultSetMetaData rsMetadata = resultSet.getMetaData();
			int columnsCount = rsMetadata.getColumnCount();
			
			while(resultSet.next()){
				Map<String, Object> row = new HashMap<String, Object>(columnsCount);
				for (int i = 1; i <= columnsCount; i++) {
					if(logger.isDebugEnabled()){
						logger.debug("process column [" + rsMetadata.getColumnName(i) + "]");
					}
					row.put(rsMetadata.getColumnName(i),
							convertObjectType(resultSet.getObject(i), rsMetadata.getColumnTypeName(i), rsMetadata.getPrecision(i),
									rsMetadata.getScale(i)));
				}
				result.add(row);
			}
			
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
			throw new Exception(e);
		}finally{
			if(connection != null){
				connection.close();
			}
		}
		
		return result;

	}
	
	public boolean createIndexIfNeeded(String tableName, String indexName, List<String> columnNameList, Long processID) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("CREATE INDEX " + indexName + " ON " + tableName + "(" + columnNameList + ")");
		}
		
		if(StringUtils.isEmpty(tableName) || StringUtils.isEmpty(indexName) || columnNameList.isEmpty()){
			throw new Exception("Missing required parameter for index creation");
		}
		
		boolean result = false;
		boolean isIndexExist = false;
		
		Connection connection = null;
		try {
			connection = dataSource.getConnection();
			
			String schemaName = getSchemaName(connection);
			String catalog = connection.getCatalog();
			
			ResultSet indexResultSet = connection.getMetaData().getIndexInfo(catalog, schemaName, tableName, false, false);
			while(indexResultSet.next()){
				if(indexName.equals(indexResultSet.getString(INDEX_NAME))){
					isIndexExist = true;
					
					if (logger.isDebugEnabled()) {
						logger.debug("Index " + indexName + "for table " + tableName + "is already exist");
					}
					
					break;
				}
			} 
			
			if (!isIndexExist) {
				StringBuilder columnListBuilder = new StringBuilder(); 
				for (String columnName : columnNameList) {
					columnListBuilder.append(columnName).append(" ASC,");
				}
				
				String expression = String.format(CREATE_INDEX, indexName, tableName, columnListBuilder.toString().substring(0, columnListBuilder.length() - 1)); 
				
				if(logger.isDebugEnabled()){
					logger.debug("Creation of index: " + expression);
				} 
				
				PreparedStatement indexStatement = connection.prepareStatement(expression);
				indexStatement.execute();
				
				if(!connection.getAutoCommit()){
					connection.commit();
				}
				result = true;

			}			
		
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
			throw new Exception(e);
		}finally{
			if(connection != null){
				connection.close();
			}
		}
		
		return result;
	}


	private String getSchemaName(Connection connection) throws SQLException {
		String schemaName = null;
		DataBaseType dataBaseType = DataUtils.getCurrentDBType(dataSource);
		boolean isOracle = DataBaseType.ORACLE.equals(dataBaseType);
		DatabaseMetaData databaseMetaData = connection.getMetaData();
		if(isOracle){
			schemaName = databaseMetaData.getUserName() ;
		}
		return schemaName;
	}

	
	private Object convertObjectType(Object valueFromDB, String columnTypeName, int precision, int scale) {
		if(valueFromDB == null){
			
			if(logger.isDebugEnabled()){
				logger.debug("Value from database == null");
			}
			return null;
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("Value from database: [columnTypeName = " + columnTypeName + ", precision = " + precision + ", scale = " + scale
					+ ", value = " + valueFromDB + "]");
		}
		Object result = valueFromDB;
		
		if(columnTypeName.toUpperCase().startsWith(VARCHAR) && precision == STRING_PRECISION_3500){
			result = valueFromDB;
		} else if(columnTypeName.toUpperCase().startsWith(VARCHAR) && precision == BOOLEAN_PRECISION_25){
			result = Boolean.valueOf(valueFromDB.toString());	
		} else if(columnTypeName.toUpperCase().startsWith(NUM) && precision == BIG_DECIMAL_PRECISION_28 && scale == BIG_DECIMAL_SCALE_10){
			valueFromDB = convertValueIfScientificZero(valueFromDB);
			result = new BigDecimal(valueFromDB.toString());
		} else if(columnTypeName.equalsIgnoreCase(INT) || (columnTypeName.toUpperCase().startsWith(NUM) && precision == INTEGER_ORACLE_PRECISION)){ 
			valueFromDB = convertValueIfScientificZero(valueFromDB);
			result = Integer.valueOf(valueFromDB.toString());
		} else if(columnTypeName.toUpperCase().startsWith(NUM) && precision == LONG_PRECISION_19){
			valueFromDB = convertValueIfScientificZero(valueFromDB);
			result = Long.valueOf(valueFromDB.toString());
		} else if(columnTypeName.toUpperCase().startsWith(NUM) && precision == DATE_PRECISION_21 && scale == DATE_SCALE_0){
			valueFromDB = convertValueIfScientificZero(valueFromDB);
			result = new Date(Long.valueOf(valueFromDB.toString()));
		} 
		
		if(logger.isDebugEnabled()){
			logger.debug("Converted object [className " + result.getClass().getName() + "] + value [ " +  result + "]");
		}
		return result;
	}


	private Object convertValueIfScientificZero(Object valueFromDB) {
		if(valueFromDB.toString().equalsIgnoreCase(SCIENTIFIC_ZERO)){
			valueFromDB = "0";
		}
		return valueFromDB;
	}


	private ResultSet getTablesResultSet(Connection connection, String tableName) throws SQLException{
		connection = dataSource.getConnection();
		
		DataBaseType dataBaseType = DataUtils.getCurrentDBType(dataSource);
		boolean isOracle = DataBaseType.ORACLE.equals(dataBaseType);
		
		String catalog = connection.getCatalog();
		DatabaseMetaData databaseMetaData = connection.getMetaData();
		String schemaName = null;
		if(isOracle){
			schemaName = databaseMetaData.getUserName();
		}
		ResultSet tablesResultSet = databaseMetaData.getTables(catalog, schemaName, tableName, null);
		
		return tablesResultSet;

	}

}
