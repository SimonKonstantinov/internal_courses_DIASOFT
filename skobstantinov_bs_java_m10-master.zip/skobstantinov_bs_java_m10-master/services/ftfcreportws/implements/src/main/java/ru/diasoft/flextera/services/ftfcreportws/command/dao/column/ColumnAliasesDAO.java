package ru.diasoft.flextera.services.ftfcreportws.command.dao.column;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;

public class ColumnAliasesDAO {

	public static ColumnAliasesDAO getInstance() {
		return new ColumnAliasesDAO();
	}

	private Logger logger = Logger.getLogger(ColumnAliasesDAO.class);

	public List<ColumnAlias> getColumnAliasByParams(ColumnAlias columnAlias) throws Exception{
		if(logger.isDebugEnabled()) {
			logger.debug("Searching column alias by params " + columnAlias);
		}
		
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put(ColumnAlias.Fields.COLUMN_NAME, columnAlias.getColumnName());
		queryParams.put(ColumnAlias.Fields.PARAMETER_NAME, columnAlias.getParameterName());
		queryParams.put(ColumnAlias.Fields.ORDER_BY, columnAlias.getOrderBy());
		
		Map<String, Object> resultMap = DataUtils.getList("columnAliasCreateGetListByParamsCount", "columnAliasCreateGetListByParams", queryParams);
		List<Map<String, Object>> queryResultList = DataUtils.getListFromResultMap(resultMap);
		
		List<ColumnAlias> columnAliasesList = new ArrayList<ColumnAlias>();
		for (Map<String, Object> row : queryResultList) {
			ColumnAlias alias = new ColumnAlias();
			alias.setColumnName(MapUtils.asString(row, ColumnAlias.Fields.COLUMN_NAME));
			alias.setParameterName(MapUtils.asString(row, ColumnAlias.Fields.PARAMETER_NAME));
			columnAliasesList.add(alias);
		}
		
		return columnAliasesList;
	}
	
	public void createColumnAlias(ColumnAlias columnAlias) throws Exception{
		
		if(logger.isDebugEnabled()) {
			logger.debug("Creating column alias: " + columnAlias);
		}
		
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put(ColumnAlias.Fields.COLUMN_NAME, columnAlias.getColumnName());
		queryParams.put(ColumnAlias.Fields.PARAMETER_NAME, columnAlias.getParameterName());
		DataUtils.performQuery("columnAliasCreate", queryParams);

		if(logger.isDebugEnabled()) {
			logger.debug("Column alias created");
		}
	}

}
