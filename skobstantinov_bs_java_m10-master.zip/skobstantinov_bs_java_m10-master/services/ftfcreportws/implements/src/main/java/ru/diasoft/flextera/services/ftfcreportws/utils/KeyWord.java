package ru.diasoft.flextera.services.ftfcreportws.utils;

public class KeyWord {
	// Класс регистрации зарезервированных слов

//	COMMENT             ("COMMENT"),
//	DATE                ("DATE"),
//	GROUP               ("GROUP"),
//	SYSDATE             ("SYSDATE"),	
//	USER                ("USER"),
//	NUMBER              ("NUMBER"),
//	VALUES              ("VALUES");
	
	
//	private String word;
//	
//	private KeyWord(String word) {		
//		this.word = word; 
//	}
//	
//	public String getWord() {
//		return word;
//	}	
	
	public static boolean isReservedWord(String keyWord){
		String upperCaseKeyWord = keyWord.toUpperCase();
		
		if (upperCaseKeyWord.equals("COMMENT")  ||
		    upperCaseKeyWord.equals("DATE")     ||
		    upperCaseKeyWord.equals("GROUP")    ||
		    upperCaseKeyWord.equals("SYSDATE")  ||
		    upperCaseKeyWord.equals("USER")     ||
		    upperCaseKeyWord.equals("NUMBER")   ||
		    upperCaseKeyWord.equals("VALUES")) {		
		  return true;		
		}
		return false;
	}
	
}
