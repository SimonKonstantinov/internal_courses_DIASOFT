package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;

public class MergeJoin extends AbstractJoinAction {

	private Logger logger = Logger.getLogger(MergeJoin.class);

	public static interface Constanst {
		String TYPE  = "type";
		String INPUT = "input";
		String PARAM = "param";
		String ON    = "on";
	}

	public MergeJoin(String valueON, ActionInputParameter actionInputParameter, Long processID) {
		this.actionInputParameter = actionInputParameter;
		this.processID = processID;
		this.valueON = valueON;		
	}

	@Override
	public void execute(Map<String, Object> inputParams) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("execute action " + APIActionType.JOIN.name() + ". ActionInputParameters = " + actionInputParameter + "; inputParams = " + inputParams);
		}
		
		try {
			// Протокол "Вызов действия"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL, APIActionType.JOIN.name(), actionInputParameter.getName());			
		
			List<Map<String, Object>> resultJoinList = executeJoin(inputParams);

			if (logger.isDebugEnabled()) {
				logger.debug("execute action " + APIActionType.JOIN.name() + " Name = " + actionInputParameter.getName() + ". Result: " + resultJoinList);
			}
		
		} // try
		catch (Exception e) {			
			// Протокол "Ошибка выполнения действия"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL_ERROR, APIActionType.JOIN.name(), actionInputParameter.getName(), e.getMessage());			
			throw new Exception(e);
		}

	}

	@Override
	public void join(List<Map<String, Object>> resultJoinList, List<Map<String, Object>> sourceList1,
			List<Map<String, Object>> sourceList2, String relList1Key, String relList2Key) {
		
		// Джойним два списка (JOIN)
		if (sourceList1 != null && sourceList2 != null) {
			if (logger.isDebugEnabled()) {					
				logger.debug("merge action");
			}
			
			for (Map<String, Object> rowList1 : sourceList1) {
				// Значение ключевого поля из списка 1
				Object relList1KeyValue = rowList1.get(relList1Key);
			
				for (Map<String, Object> rowList2 : sourceList2) {
					// Значение ключевого поля из списка 2
					Object relList2KeyValue = rowList2.get(relList2Key);
				
					// Проверка условия соединения ON					
					if (relList1KeyValue.equals(relList2KeyValue)) {
						Map<String, Object> resultRow = new HashMap<String, Object>();						
						resultRow.putAll(rowList2);
						resultRow.putAll(rowList1);
					
						resultJoinList.add(resultRow);
					}						
				}	
			}

		} else {
			if (logger.isDebugEnabled()) {					
				logger.debug("skip join action");
			}				
		}
			

	}
}
