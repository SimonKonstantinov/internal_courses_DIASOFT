package ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol;

import java.util.List;

import ru.diasoft.flextera.services.ftfcreportws.type.TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam;

public class ProtocolBrowseListResult {
	
	private List<TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam> resultList;
	private Integer totalCount;	
	private Long    returnCode;
	private String  returnMsg;
	
	public List<TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam> getResultList() {
		return resultList;
	}
	public void setResultList(List<TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam> resultList) {
		this.resultList = resultList;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public void setReturnCode(Long returnCode) {
		this.returnCode = returnCode;
	}
	public Long getReturnCode() {
		return returnCode;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	public String getReturnMsg() {
		return returnMsg;
	}	

}
