package ru.diasoft.flextera.services.ftfcreportws.command.dao.group;

import java.util.List;

import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam;

public class ReportGroupBrowseListResult {
	private List<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam> resultList;
	private Integer totalCount;	
	private Long    returnCode;
	private String  returnMsg;
	
	public List<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam> getResultList() {
		return resultList;
	}
	public void setResultList(List<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam> resultList) {
		this.resultList = resultList;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public Long getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(Long returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMsg() {
		return returnMsg;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	
	
}
