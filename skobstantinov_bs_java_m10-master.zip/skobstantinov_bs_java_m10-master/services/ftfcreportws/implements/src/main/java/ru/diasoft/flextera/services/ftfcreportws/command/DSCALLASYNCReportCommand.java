package ru.diasoft.flextera.services.ftfcreportws.command;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import ru.diasoft.core.application.CommandDispatcher;
import ru.diasoft.core.application.command.CommandContext;
import ru.diasoft.core.application.command.CommandException;
import ru.diasoft.core.exception.CommonException;
import ru.diasoft.flextera.services.command.DSCALLASYNCCommandStub;
import ru.diasoft.flextera.services.type.ContextData;
import ru.diasoft.utils.exception.XMLParseException;

public class DSCALLASYNCReportCommand extends DSCALLASYNCCommandStub {

	private Logger logger = Logger.getLogger(DSCALLASYNCReportCommand.class);
	@SuppressWarnings("deprecation")
	protected void executeCommand() throws CommonException {
		// creating new context for requested command
		CommandContext context = new CommandContext();
		
		// filling new context with 'dscall' context
		context.fromMap(getContext().toMap(null));
		
		// overriding some context params with legacy ContextData
		ContextData cd = getInputData().getContextData();
		if (cd != null) {
			if(!StringUtils.isBlank(cd.getSessionId()))
				context.setSessionId(cd.getSessionId());
			if(!StringUtils.isBlank(cd.getLocale()))
				context.setLocale(cd.getLocale());
			if(cd.getProcessId() != null)
				context.setProcessId(cd.getProcessId());
			if(!StringUtils.isBlank(cd.getFromSystem()))
				context.setFromSystem(cd.getFromSystem());
			if(!StringUtils.isBlank(cd.getToSystem()))
				context.setToSystem(cd.getToSystem());
		}
		
		// setting command name from 'dscall'
		context.setCommandName(getInputData().getCommandtext());
		
		// parsing input params from 'dscall'
		Map<String, Object> params = null;
		try {
			params = context.getXmlUtil().parse(getInputData().getCommanddata());
		} catch (XMLParseException e) {
			throw new CommandException(String.format("Failed to parse input params for DSCALL command '%s'", getInputData().getCommandtext()), e);
		}
		
		// executing requested command
		Map<String, Object> res = null;
		try {
			res = CommandDispatcher.executeCommand(context, params).toMap(null);
			if(logger.isDebugEnabled()){
				logger.debug("async call result = " + res);
			}
			//logging
		} catch (CommonException e) {
			logger.error("Exception while calling async method " + e.getLocalizedMessage(), e);
		}
	}
	
	
}
