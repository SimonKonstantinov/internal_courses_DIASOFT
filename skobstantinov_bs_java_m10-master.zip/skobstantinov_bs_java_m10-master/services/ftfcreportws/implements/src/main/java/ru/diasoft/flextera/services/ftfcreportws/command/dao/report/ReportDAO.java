package ru.diasoft.flextera.services.ftfcreportws.command.dao.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.query.InsertBatchQuery;
import org.apache.cayenne.query.QueryChain;
import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroup;
import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportBrowseListTypeForDSFCReportBrowseListByParam;
import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportIDListTypeForDSFCReportMassInsert;
import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportListTypeForDSFCReportMassInsert;
import ru.diasoft.flextera.services.ftfcreportws.type.TNotificationListTypeForDSFCReportMassInsert;
import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportBrowseListByParamReq;
import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportUpdateReq;
import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportDeleteRes;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.ReportType;
import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.ExternalService;
import ru.diasoft.utils.text.StringUtils;

public class ReportDAO {
	
	private static final char DOT = '.';
	private Logger logger = Logger.getLogger(ReportDAO.class);
	
	public static ReportDAO getInstance() {
		return new ReportDAO();
	}

	private ReportDAO(){
	}
	
	public Report getByID(Long reportID) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(Report.Fields.REPORTID, reportID);
		
		if(logger.isDebugEnabled()) {
			logger.debug("ReportDAO.getByID reportID = " + Long.toString(reportID));
		}		
		
		List<Map<String, Object>> resultList = DataUtils.performQuery("reportGetById", params);
		
		Report report = null; 
		if(resultList.size() > 0) {
			report = new Report();
			report.setReportID(MapUtils.asLong(resultList.get(0), Report.Fields.REPORTID, null));
			report.setReportName(MapUtils.asString(resultList.get(0), Report.Fields.REPORTNAME, null));
			report.setReportSysname(MapUtils.asString(resultList.get(0), Report.Fields.REPORTSYSNAME, null));
			report.setDeleteDataFlag(MapUtils.asBoolean(resultList.get(0), Report.Fields.DELETEDATAFLAG, null));
			report.setFileFormat(MapUtils.asInteger(resultList.get(0), Report.Fields.FILEFORMAT, null));
			report.setUserLogin(MapUtils.asString(resultList.get(0), Report.Fields.USERLOGIN, null));
			report.setTemplateName(MapUtils.asString(resultList.get(0), Report.Fields.TEMPLATENAME, null));
			report.setConfigPath(MapUtils.asString(resultList.get(0), Report.Fields.CONFIGPATH, null));
			report.setReportGroupID(MapUtils.asLong(resultList.get(0), Report.Fields.REPORTGROUPID, null));
			report.setReportGroupName(MapUtils.asString(resultList.get(0), Report.Fields.REPORTGROUPNAME, null));
		}
		
		if(logger.isDebugEnabled()) {
			if(report != null) {
				logger.debug("ReportDAO.getByID report = " + report.toString());
			} else {
				logger.error("Report not found by id = " + reportID);
			}
		}
		
		return report;
	}
		
	public Long delete(Long reportID) throws Exception {
		if(logger.isDebugEnabled()) {
			logger.debug("ReportDAO.delete ReportID = " + Long.toString(reportID));
		}
		
		Long retVal = 0L;

		// Объект по идентификатору не найден
		Report report = getByID(reportID);		
		if (report == null) {			
			retVal = RetCode.OBJECT_NOT_FOUND.getCode();
		}	

		if (retVal == 0L) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(Report.Fields.REPORTID, reportID);
			
			// DELETE
			List<Map<String, Object>> resultList = DataUtils.performQuery("reportDelete", params);

			if(resultList.size() > 0) {
				retVal = MapUtils.asLong(resultList.get(0), DsFCReportDeleteRes.PROPERTY_RETURN_CODE);			
			}
		}
		if(logger.isDebugEnabled()){
			logger.debug("ReportDAO.delete RetVal = " + Long.toString(retVal));
		}
		
		return retVal;
	}
	
	@SuppressWarnings("unused")
	public ReportUpdateResult update(DsFCReportUpdateReq request) throws Exception {
		ReportUpdateResult result = new ReportUpdateResult();
		result.setReturnCode(Long.valueOf(0));
		result.setReturnMsg("");		

		if(logger.isDebugEnabled()) {
			logger.debug("ReportDAO.update ReportID = " + Long.toString(request.getFCReportID()));
		}

		try {		
			Map<String, Object> params = new HashMap<String, Object>();
			request.toMap(params);		
				
			// Объект по идентификатору не найден
			Report report = getByID(request.getFCReportID());		
			if (report == null) {
				throw new ReportException(RetCode.OBJECT_NOT_FOUND.getCode(), RetCode.OBJECT_NOT_FOUND.getMessage());				
			}	
		
			// Расширение файла шаблона отчета
			if (!StringUtils.isEmpty(request.getTemplatePathName())) {
				String templateName = request.getTemplatePathName();
			
				if ((!templateName.endsWith(ReportType.JRXML.getExtension())) && (!templateName.endsWith(ReportType.TPR.getExtension()))) {
					String fileExtension = "";
					if(templateName.contains(".")){
						fileExtension = templateName.substring(templateName.lastIndexOf(DOT) + 1);
					}
					String errorMessage = "Incorrect report template [" + templateName + "] file extension [" + fileExtension + "]"; 
					logger.error(errorMessage);
				
					// Ошибка. Не указано расширение файла шаблона отчета
					throw new ReportException(RetCode.INCORRECT_TEMPLATE_EXTENSION.getCode(), RetCode.INCORRECT_TEMPLATE_EXTENSION.getMessage(templateName, fileExtension));
				}			
			}
		
			// Отчет с указанным наименованием уже существует
			if (!StringUtils.isEmpty(request.getFCReportName())) { 
				List<Map<String, Object>> resultList = DataUtils.performQuery("reportCheckExistsByName", params);			
				if(resultList.size() > 0) {
					throw new ReportException(RetCode.REPORT_NAME_ALREADY_EXISTS.getCode(), RetCode.REPORT_NAME_ALREADY_EXISTS.getMessage());					
				}
			}
			
			// Отчет с указанным системным наименованием уже существует
			if (!StringUtils.isEmpty(request.getFCReportSysName())) {
				List<Map<String, Object>> resultList = DataUtils.performQuery("reportCheckExistsBySysName", params);			
				if(resultList.size() > 0) {
					throw new ReportException(RetCode.REPORT_SYSNAME_ALREADY_EXISTS.getCode(), RetCode.REPORT_SYSNAME_ALREADY_EXISTS.getMessage());					
				}
			}
		
			// Идентификатор группы отчетов
			if (request.getFCReportGroupID() == null ) {
				params.put(Report.Fields.REPORTGROUPID, null);
			}		
		
			// UPDATE			
			List<Map<String, Object>> resultList = DataUtils.performQuery("reportModify", params);
			
		
			if(logger.isDebugEnabled()) {
				logger.debug("ReportDAO.update has successful");
			}		
		}
		catch (ReportException e) {
			// Бизнес-ошибка
			result.setReturnCode(e.getReturnCode());
			result.setReturnMsg(e.getReturnMessage());
			if(logger.isDebugEnabled()){
				logger.error("business error ReportDAO.update " + e.getMessage(), e);
			}
			
		}	
		catch (Exception e) {
			if(logger.isDebugEnabled()){
				logger.error("error ReportDAO.update " + e.getMessage(), e);
			}
			throw e;
		}		
		
		return result;
	}

	public ReportBrowse getBrowseListByParam(DsFCReportBrowseListByParamReq request) throws Exception {
		
		Map<String, Object> params = new HashMap<String, Object>();
		request.toMap(params);

		String reportSysname = request.getFCReportSysName();
		if(!StringUtils.isEmpty(reportSysname)) {
			params.put(Report.Fields.REPORTSYSNAME, reportSysname + "%");	
		}
		
		String reportName = request.getFCReportName();
		if(!StringUtils.isEmpty(reportName)) {
			params.put(Report.Fields.REPORTNAME, reportName + "%");	
		}		
		
		String userLogin = request.getUserLogin();
		if(!StringUtils.isEmpty(userLogin)) {
			params.put(Report.Fields.USERLOGIN, userLogin + "%");	
		}
		
		// По умолчанию номер страницы = 1
		if (request.getPAGE() == null ) {
			params.put(Report.Fields.PAGE, 0);
		}	
		
		// По умолчанию число записей на страницу = 10
		if (request.getROWSCOUNT() == null) {
			params.put(Report.Fields.ROWSCOUNT, 10);
		}
		
		// По умолчанию сортировка по первому полю выходного набора
		if (request.getORDERBY() == null) {
			params.put(ReportGroup.Fields.ORDERBY, "FCReportID DESC");
		}				
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ReportDAO.getBrowseListByParam" + " params = " + params.toString());
		}		
		
		// QUERY
		Map<String, Object> resultMap = DataUtils.getList("reportGetListByParamsCount", "reportGetListByParams", params); 
		List<Map<String, Object>> resultList = DataUtils.getListFromResultMap(resultMap);
		
		ReportBrowse reportBrowse = new ReportBrowse();
		
		List<TFCReportBrowseListTypeForDSFCReportBrowseListByParam> reportResultList = new ArrayList<TFCReportBrowseListTypeForDSFCReportBrowseListByParam>();
		for (Map<String, Object> reportRow : resultList) {
			TFCReportBrowseListTypeForDSFCReportBrowseListByParam param = new TFCReportBrowseListTypeForDSFCReportBrowseListByParam();
			param.setFCReportID(MapUtils.asLong(reportRow, Report.Fields.REPORTID, 0L));
			param.setFCReportName(MapUtils.asString(reportRow, Report.Fields.REPORTNAME, ""));
			param.setFCReportSysName(MapUtils.asString(reportRow, Report.Fields.REPORTSYSNAME, ""));
			param.setDeleteDataFlag(MapUtils.asBoolean(reportRow, Report.Fields.DELETEDATAFLAG, null));
			param.setUserLogin(MapUtils.asString(reportRow, Report.Fields.USERLOGIN, ""));
			param.setTemplatePathName(MapUtils.asString(reportRow, Report.Fields.TEMPLATENAME, ""));
			param.setConfigPathName(MapUtils.asString(reportRow, Report.Fields.CONFIGPATH, ""));
			param.setFCReportGroupID(MapUtils.asLong(reportRow, Report.Fields.REPORTGROUPID, 0L));
			param.setFCReportGroupName(MapUtils.asString(reportRow, Report.Fields.REPORTGROUPNAME, ""));
			reportResultList.add(param);
		}

		reportBrowse.setResultList(reportResultList);
		reportBrowse.setTotalCount(MapUtils.asInteger(resultMap, DataUtils.TOTALCOUNT));
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ReportDAO.getBrowseListByParam" + " ResultList = " + reportResultList.toString());
		}		
		return reportBrowse;
	}

	public ReportMassInsertResult massInsert(List<TFCReportListTypeForDSFCReportMassInsert> reportList, String login) throws Exception{
		if(logger.isDebugEnabled()){			
			logger.debug("ReportDAO.massInsert" + " ReportList = " + reportList.toString());
		}
		
		ReportMassInsertResult result = new ReportMassInsertResult();
		Long   RetValItem = 0L;
		String RetMsgItem = "";		
		
		// Формируем список параметров для массовой вставки
		InsertBatchQuery insertBatchQuery = new InsertBatchQuery(ReportDBEntity.getDbEntity(), reportList.size());
		// Исходящий набор FCReportIDList
		List<TFCReportIDListTypeForDSFCReportMassInsert> reportResultList = new ArrayList<TFCReportIDListTypeForDSFCReportMassInsert>();
		// Исходящий набор NotificationList
		List<TNotificationListTypeForDSFCReportMassInsert> reportNotificationList = new ArrayList<TNotificationListTypeForDSFCReportMassInsert>();
		
		try {
			for (TFCReportListTypeForDSFCReportMassInsert insertRow: reportList) {
				Map<String, Object> queryParams = new HashMap<String, Object>();
				Long reportID = ExternalService.getInstance().getNewId(ReportDBEntity.TABLENAME);

				RetValItem = 0L;
				RetMsgItem = "";
				
				queryParams.put(ReportDBEntity.Field.REPORTID, reportID);
				if (insertRow.getFCReportSysName() == null) {
					// Ошибка. Не передан обязательный параметр
					RetValItem = RetCode.REQUIRED_PARAM_NOT_FOUND.getCode(); 
					RetMsgItem = RetCode.REQUIRED_PARAM_NOT_FOUND.getMessage("FCReportSysName");
				} else {
					queryParams.put(ReportDBEntity.Field.REPORTSYSNAME, insertRow.getFCReportSysName());
				}	

				if (insertRow.getFCReportName() == null) {
					// Ошибка. Не передан обязательный параметр <Имя параметра>
					RetValItem = RetCode.REQUIRED_PARAM_NOT_FOUND.getCode();
					RetMsgItem = RetCode.REQUIRED_PARAM_NOT_FOUND.getMessage("FCReportName");
				} else {
					queryParams.put(ReportDBEntity.Field.REPORTNAME, insertRow.getFCReportName());
				}
			
				queryParams.put(ReportDBEntity.Field.USERLOGIN, login);								
				
				if (insertRow.getTemplatePathName() == null) {
					// Ошибка. Не передан обязательный параметр
					RetValItem = RetCode.REQUIRED_PARAM_NOT_FOUND.getCode(); 
					RetMsgItem = RetCode.REQUIRED_PARAM_NOT_FOUND.getMessage("TemplatePathName");					
				} else {
					String templateName = insertRow.getTemplatePathName();
					
					if ((templateName.endsWith(ReportType.JRXML.getExtension())) || (templateName.endsWith(ReportType.TPR.getExtension()))) {
						queryParams.put(ReportDBEntity.Field.TEMPLATENAME, templateName);	
					} else {
						String fileExtension = "";
						if(templateName.contains(".")){
							fileExtension = templateName.substring(templateName.lastIndexOf(DOT) + 1);
						}
						String errorMessage = "Incorrect report template [" + templateName + "] file extension [" + fileExtension + "]"; 
						logger.error(errorMessage);
						
						// Ошибка. Не указано расширение файла шаблона отчета
						RetValItem = RetCode.INCORRECT_TEMPLATE_EXTENSION.getCode();
						RetMsgItem = RetCode.INCORRECT_TEMPLATE_EXTENSION.getMessage(templateName, fileExtension);						
					}					
				}	
			
				if (insertRow.getFileFormat() == null) {
					queryParams.put(ReportDBEntity.Field.FILEFORMAT, 1); // по умолчанию 1 - xls
				} else {	
					queryParams.put(ReportDBEntity.Field.FILEFORMAT, insertRow.getFileFormat());
				}	
			
				if (insertRow.getDeleteDataFlag() == null) {
					queryParams.put(ReportDBEntity.Field.DELETEDATAFLAG, false);
				} else {	
					queryParams.put(ReportDBEntity.Field.DELETEDATAFLAG, insertRow.getDeleteDataFlag());
				}	
			
				if (insertRow.getConfigPathName() == null) {
					queryParams.put(ReportDBEntity.Field.CONFIGPATH, "");
				} else {	
					queryParams.put(ReportDBEntity.Field.CONFIGPATH, insertRow.getConfigPathName());
				}
				
				if (insertRow.getFCReportGroupID() == null ) {
					queryParams.put(ReportDBEntity.Field.REPORTGROUPID, null);
				} else {
					queryParams.put(ReportDBEntity.Field.REPORTGROUPID, insertRow.getFCReportGroupID());
				}
			
				insertBatchQuery.add(queryParams);
			
				// сразу пишем в исходящий набор FCReportIDList (LinkID, FCReportID)
				TFCReportIDListTypeForDSFCReportMassInsert insertReportItem = new TFCReportIDListTypeForDSFCReportMassInsert();
				insertReportItem.setFCReportID(reportID);
				insertReportItem.setLinkID(insertRow.getLinkID());
				reportResultList.add(insertReportItem);
				
				// ошибки пишем в исходящий набор NotificationList (LinkID, NTFID, NTFMessage)
				if (RetValItem > 0) {
					TNotificationListTypeForDSFCReportMassInsert insertNotificationItem = new TNotificationListTypeForDSFCReportMassInsert();
					insertNotificationItem.setLinkID(insertRow.getLinkID());
					insertNotificationItem.setNTFID(RetValItem);
					insertNotificationItem.setNTFMessage(RetMsgItem);
					reportNotificationList.add(insertNotificationItem);
				}
			}
	        // Если есть ошибки, прервем выполнение
			if (reportNotificationList.size() > 0) {
				result.setReportNtfList(reportNotificationList);
				throw new ReportException(reportNotificationList.get(0).getNTFID(), reportNotificationList.get(0).getNTFMessage());				
			}
		
			QueryChain insertQueryChain = new QueryChain();
			insertQueryChain.addQuery(insertBatchQuery);
			
			// QUERY MASS INSERT			
			try {
				DataUtils.performGenericQuery(insertQueryChain);	
				result.setReportIDList(reportResultList);		
			} 
			catch (Exception e) {
				// SQL ошибка insert duplicate key
				// Отчет с указанным системным наименованием уже существует
				// Вернем код ошибки
				logger.error("ReportDAO.massInsert " + e.getMessage(), e);
				//throw new ReportException(BusinessErrors.REPORT_SYSNAME_ALREADY_EXISTS, "Failed to add records to the table FCR_Report");
				throw new ReportException(5000L, "Failed to add records to the table FCR_Report " + e.getMessage());
			}
		
		} catch (ReportException e) {			
			result.setReturnCode(e.getReturnCode());
			result.setReturnMsg(e.getReturnMessage());	
		}		
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ReportDAO.massInsert" + " result = " + result.toString());
		}		
		
		return result;
	}
}
