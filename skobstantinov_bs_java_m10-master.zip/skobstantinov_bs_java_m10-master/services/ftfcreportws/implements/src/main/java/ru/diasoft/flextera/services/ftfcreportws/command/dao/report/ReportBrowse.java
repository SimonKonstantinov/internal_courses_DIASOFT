package ru.diasoft.flextera.services.ftfcreportws.command.dao.report;

import java.util.List;

import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportBrowseListTypeForDSFCReportBrowseListByParam;

public class ReportBrowse {

	private Integer totalCount;
	private List<TFCReportBrowseListTypeForDSFCReportBrowseListByParam> resultList;
	
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public List<TFCReportBrowseListTypeForDSFCReportBrowseListByParam> getResultList() {
		return resultList;
	}
	public void setResultList(List<TFCReportBrowseListTypeForDSFCReportBrowseListByParam> resultList) {
		this.resultList = resultList;
	}

}
