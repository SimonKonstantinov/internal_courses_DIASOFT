package ru.diasoft.flextera.services.ftfcreportws.command.dao.group;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.Report;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportException;
import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam;
import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportGroupBrowseListByParamReq;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.ExternalService;
import ru.diasoft.utils.text.StringUtils;

public class ReportGroupDAO {
	private Logger logger = Logger.getLogger(ReportGroupDAO.class);
	
	private ReportGroupDAO(){
	}
	
	public static ReportGroupDAO getInstance() {
		return new ReportGroupDAO();
	}
	
	public ReportGroup getByID(Long reportGroupID) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(ReportGroup.Fields.REPORTGROUPID, reportGroupID);		
		
		if(logger.isDebugEnabled()) {
			logger.debug("ReportGroupDAO.getByID reportGroupID = " + Long.toString(reportGroupID));
		}		
		
		List<Map<String, Object>> resultList = DataUtils.performQuery("reportGroupFindById", params);
		
		ReportGroup reportGroup = null; 
		if(resultList.size() > 0) {
			reportGroup = new ReportGroup();
			reportGroup.setReportGroupID(MapUtils.asLong(resultList.get(0), ReportGroup.Fields.REPORTGROUPID, null));
			reportGroup.setReportGroupName(MapUtils.asString(resultList.get(0), ReportGroup.Fields.NAME, null));
			reportGroup.setReportGroupSysName(MapUtils.asString(resultList.get(0), ReportGroup.Fields.SYSNAME, null));
			reportGroup.setReportGroupDescription(MapUtils.asString(resultList.get(0), ReportGroup.Fields.DESCRIPTION, null));		

		}
		
		if(logger.isDebugEnabled()) {
			if(reportGroup != null) {
				logger.debug("ReportGroupDAO.getByID reportGroupID = " + reportGroup.toString());
			} else {
				logger.error("Report group not found by id = " + reportGroupID);
			}
		}
		
		return reportGroup;
	}

	public ReportGroupInsertResult insert(ReportGroup reportGroup) throws Exception {		
		ReportGroupInsertResult result = new ReportGroupInsertResult();
		result.setReportGroupID(Long.valueOf(0));
		result.setReturnCode(Long.valueOf(0));
		result.setReturnMsg("");
		
		try {
			Long reportGroupID = ExternalService.getInstance().getNewId("FCR_REPORTGROUP");			
			
			// Параметры
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(ReportGroup.Fields.REPORTGROUPID, reportGroupID);
			params.put(ReportGroup.Fields.SYSNAME, reportGroup.getReportGroupSysName());
			params.put(ReportGroup.Fields.NAME, reportGroup.getReportGroupName());
			params.put(ReportGroup.Fields.DESCRIPTION, reportGroup.getReportGroupDescription());
			
			if(logger.isDebugEnabled()) {
				logger.debug("ReportGroupDAO.insert params: " + reportGroup.toString());
			}			

			// Группа отчетов с указанным наименованием уже существует
			if (!StringUtils.isEmpty(reportGroup.getReportGroupName())) { 
				List<Map<String, Object>> resultList = DataUtils.performQuery("reportGroupCheckExistsByName", params);			
				if(resultList.size() > 0) {
					throw new ReportException(RetCode.REPORT_GROUP_NAME_ALREADY_EXISTS.getCode(), RetCode.REPORT_GROUP_NAME_ALREADY_EXISTS.getMessage());
				}
			}
	        // Группа отчетов с указанным системным наименованием уже существует
			if (!StringUtils.isEmpty(reportGroup.getReportGroupSysName())) {
				List<Map<String, Object>> resultList = DataUtils.performQuery("reportGroupCheckExistsBySysName", params);			
				if(resultList.size() > 0) {
					throw new ReportException(RetCode.REPORT_GROUP_SYSNAME_ALREADY_EXISTS.getCode(), RetCode.REPORT_GROUP_SYSNAME_ALREADY_EXISTS.getMessage());					
				}
			}			

			// INSERT
			DataUtils.performQuery("reportGroupInsert", params);	
			
			if(logger.isDebugEnabled()){
				logger.debug("ReportGroupDAO.insert success");
			}			

			// Идентификатор группы отчетов 
			result.setReportGroupID(reportGroupID);
			
		}
		catch (ReportException e) {
			// Бизнес-ошибка
			result.setReturnCode(e.getReturnCode());
			result.setReturnMsg(e.getReturnMessage());
			result.setReportGroupID(Long.valueOf(0));
			if(logger.isDebugEnabled()){
				logger.error("business error ReportGroupDAO.insert " + e.getMessage(), e);
			}	
			
		}	
		catch (Exception e) {
			if(logger.isDebugEnabled()){
				logger.error("error ReportGroupDAO.insert " + e.getMessage(), e);
			}	
			result.setReportGroupID(Long.valueOf(0));
			throw e;
		}		
		
		return result;
	}
		
	public ReportGroupUpdateResult update(ReportGroup reportGroup) throws Exception {
		ReportGroupUpdateResult result = new ReportGroupUpdateResult();
		result.setReturnCode(Long.valueOf(0));
		result.setReturnMsg("");

		try {
			// Параметры
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(ReportGroup.Fields.REPORTGROUPID, reportGroup.getReportGroupID());
			params.put(ReportGroup.Fields.SYSNAME, reportGroup.getReportGroupSysName());
			params.put(ReportGroup.Fields.NAME, reportGroup.getReportGroupName());
		    // Description удаляем, если передали пустое значение (или не передали) 
			if (reportGroup.getReportGroupDescription() == null) {
				params.put(ReportGroup.Fields.DESCRIPTION, "");
			} else {
				params.put(ReportGroup.Fields.DESCRIPTION, reportGroup.getReportGroupDescription());				
			}
			
			if(logger.isDebugEnabled()) {
				logger.debug("ReportGroupDAO.update params: " + reportGroup.toString());
			}			

			// Объект по идентификатору не найден
			ReportGroup reportGroupFind = getByID(reportGroup.getReportGroupID());		
			if (reportGroupFind == null) {
				throw new ReportException(RetCode.OBJECT_NOT_FOUND.getCode(), RetCode.OBJECT_NOT_FOUND.getMessage());				
			}	
			
			// Группа отчетов с указанным наименованием уже существует
			if (!StringUtils.isEmpty(reportGroup.getReportGroupName())) { 
				List<Map<String, Object>> resultList = DataUtils.performQuery("reportGroupCheckExistsByName", params);			
				if(resultList.size() > 0) {
					throw new ReportException(RetCode.REPORT_GROUP_NAME_ALREADY_EXISTS.getCode(), RetCode.REPORT_GROUP_NAME_ALREADY_EXISTS.getMessage());
				}
			}
	        // Группа отчетов с указанным системным наименованием уже существует
			if (!StringUtils.isEmpty(reportGroup.getReportGroupSysName())) {
				List<Map<String, Object>> resultList = DataUtils.performQuery("reportGroupCheckExistsBySysName", params);			
				if(resultList.size() > 0) {
					throw new ReportException(RetCode.REPORT_GROUP_SYSNAME_ALREADY_EXISTS.getCode(), RetCode.REPORT_GROUP_SYSNAME_ALREADY_EXISTS.getMessage());					
				}
			}			

			// UPDATE
			DataUtils.performQuery("reportGroupUpdate", params);			

			if(logger.isDebugEnabled()){
				logger.debug("ReportGroupDAO.update success");				
			}
			
		}
		catch (ReportException e) {
			// Бизнес-ошибка
			result.setReturnCode(e.getReturnCode());
			result.setReturnMsg(e.getReturnMessage());
			if(logger.isDebugEnabled()){
				logger.error("business error ReportGroupDAO.update " + e.getMessage(), e);
			}
			
		}	
		catch (Exception e) {
			if(logger.isDebugEnabled()){
				logger.error("error ReportGroupDAO.update " + e.getMessage(), e);
			}
			throw e;
		}		
		
		return result;
	}
	
	public ReportGroupDeleteResult delete(Long reportGroupID) throws Exception {
		ReportGroupDeleteResult result = new ReportGroupDeleteResult();
		result.setReturnCode(Long.valueOf(0));
		result.setReturnMsg("");

		try {
			// Параметры
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(ReportGroup.Fields.REPORTGROUPID, reportGroupID);
			
			if(logger.isDebugEnabled()) {
				logger.debug("ReportGroupDAO.delete reportGroupID = " + reportGroupID);
			}			

			// Объект по идентификатору не найден
			ReportGroup reportGroupFind = getByID(reportGroupID);		
			if (reportGroupFind == null) {
				throw new ReportException(RetCode.OBJECT_NOT_FOUND.getCode(), RetCode.OBJECT_NOT_FOUND.getMessage());				
			}
			
			// Удаление невозможно. Существуют отчеты, привязанные к удаляемой группе       
			List<Map<String, Object>> resultList = DataUtils.performQuery("reportGroupCheckReportLink", params);			
			if(resultList.size() > 0) {
				if (MapUtils.asLong(resultList.get(0), Report.Fields.REPORTID, 0L) > 0L){ 
					throw new ReportException(RetCode.REPORT_GROUP_DELETE_LINK_EXISTS.getCode(), RetCode.REPORT_GROUP_DELETE_LINK_EXISTS.getMessage());
				}
			}			
			
			// DELETE
			DataUtils.performQuery("reportGroupDelete", params);			

			if(logger.isDebugEnabled()){
				logger.debug("ReportGroupDAO.delete success");				
			}			
			
		}
		catch (ReportException e) {
			// Бизнес-ошибка
			result.setReturnCode(e.getReturnCode());
			result.setReturnMsg(e.getReturnMessage());
			if(logger.isDebugEnabled()){
				logger.error("business error ReportGroupDAO.delete " + e.getMessage(), e);
			}
			
		}	
		catch (Exception e) {
			if(logger.isDebugEnabled()){
				logger.error("error ReportGroupDAO.delete " + e.getMessage(), e);
			}
			throw e;
		}		
		
		return result;		
	}
	
	public ReportGroupBrowseListResult getBrowseListByParam(DsFCReportGroupBrowseListByParamReq request) throws Exception {
		
		Map<String, Object> params = new HashMap<String, Object>();
		request.toMap(params);
		
		Long reportGroupID = request.getFCReportGroupID(); 		

		String reportGroupSysname = request.getFCReportGroupSysName();
		if(!StringUtils.isEmpty(reportGroupSysname)) {
			params.put(ReportGroup.Fields.SYSNAME, reportGroupSysname + "%");	
		}
		
		String reportGroupName = request.getFCReportGroupName();
		if(!StringUtils.isEmpty(reportGroupName)) {
			params.put(ReportGroup.Fields.NAME, reportGroupName + "%");	
		}		
		
		// По умолчанию номер страницы = 1
		if (request.getPAGE() == null ) {
			params.put(ReportGroup.Fields.PAGE, 0);
		}	
		
		// По умолчанию число записей на страницу = 10
		if (request.getROWSCOUNT() == null) {
			params.put(ReportGroup.Fields.ROWSCOUNT, 10);
		}
		
		// По умолчанию сортировка по первому полю выходного набора
		if (request.getORDERBY() == null) {
			params.put(ReportGroup.Fields.ORDERBY, "FCReportGroupID DESC");
		}		
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ReportGroupDAO.getBrowseListByParam" + " params = " + params.toString());
		}		
		
		// QUERY BROWSELIST
		Map<String, Object> resultMap = DataUtils.getList("reportGroupBrowseListByParamCount", "reportGroupBrowseListByParam", params); 
		List<Map<String, Object>> resultList = DataUtils.getListFromResultMap(resultMap);
		
		ReportGroupBrowseListResult reportGroupBrowseListResult = new ReportGroupBrowseListResult();
		
		List<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam> reportGroupResultList = new ArrayList<TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam>();
		for (Map<String, Object> reportGroupRow : resultList) {
			TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam param = new TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam();
			
			param.setFCReportGroupID(MapUtils.asLong(reportGroupRow, ReportGroup.Fields.REPORTGROUPID, null));
			param.setFCReportGroupName(MapUtils.asString(reportGroupRow, ReportGroup.Fields.NAME, null));
			param.setFCReportGroupSysName(MapUtils.asString(reportGroupRow, ReportGroup.Fields.SYSNAME, null));
			param.setFCReportGroupDescription(MapUtils.asString(reportGroupRow, ReportGroup.Fields.DESCRIPTION, null));			

			reportGroupResultList.add(param);
		}

		reportGroupBrowseListResult.setResultList(reportGroupResultList);
		reportGroupBrowseListResult.setTotalCount(MapUtils.asInteger(resultMap, DataUtils.TOTALCOUNT, null));
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ReportGroupDAO.getBrowseListByParam" + " ResultList = " + reportGroupResultList.toString());
		}
		
		// Бизнес ошибка, если объект не найден по переданному идентификатору
     	if (reportGroupID != null && reportGroupID > 0L) {
     		if (reportGroupResultList.size() > 0) {
     			TFCReportGroupBrowseListTypeForDSFCReportGroupBrowseListByParam resultParam = reportGroupResultList.get(0);     			
     			if (!reportGroupID.equals(resultParam.getFCReportGroupID())){
     				reportGroupBrowseListResult.setReturnCode(RetCode.OBJECT_NOT_FOUND.getCode());
     				reportGroupBrowseListResult.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());
					if(logger.isDebugEnabled()){
						logger.debug("ReportGroupDAO.getBrowseListByParam" + " Object by ID not found");
					}
     			}
     		} else {
     			reportGroupBrowseListResult.setReturnCode(RetCode.OBJECT_NOT_FOUND.getCode());
     			reportGroupBrowseListResult.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());
				if(logger.isDebugEnabled()){
					logger.debug("ReportGroupDAO.getBrowseListByParam" + " Object by ID not found");
				}				
     		}
     	}		
		
		return reportGroupBrowseListResult;
	}
	
}
