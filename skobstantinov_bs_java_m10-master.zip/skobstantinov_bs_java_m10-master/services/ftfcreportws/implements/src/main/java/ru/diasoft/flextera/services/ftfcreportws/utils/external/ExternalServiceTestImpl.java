package ru.diasoft.flextera.services.ftfcreportws.utils.external;

import java.util.HashMap;
import java.util.Map;

import ru.diasoft.utils.XMLUtil;

public class ExternalServiceTestImpl extends ExternalService{

    private static Map<String, Integer> ids = new HashMap<String, Integer>();
	
	@Override
	public Map<String, Object> callExternalService(XMLUtil xmlUtil, String serviceName, String methodName, Map<String, Object> params) throws Exception {
        return TestUtils.getMethodResponse(serviceName, methodName, params);
	}

    @Override
    public long getNewIds(String entityName, int quantity) {
        if (entityName == null || quantity < 1) {
            throw new IllegalArgumentException();
        }
        Integer currentValue = ids.get(entityName);
        if (currentValue == null) {
            currentValue = 0;
        }
        ids.put(entityName, currentValue + quantity);
        return ++currentValue;
    }
	
}
