package ru.diasoft.flextera.services.ftfcreportws.utils;

import java.util.Map;

import ru.diasoft.flextera.services.ftfcreportws.i18n.FTFCReportMessage;

public class MapUtilsParamNotFoundException extends Exception {

	private static final long serialVersionUID = 8696605689931530635L;

	public MapUtilsParamNotFoundException(String paramName, Map<?, ?> map) {
		super(FTFCReportMessage.formatLocalizedString("parameter.not.found", paramName, map));
	}
	
}
