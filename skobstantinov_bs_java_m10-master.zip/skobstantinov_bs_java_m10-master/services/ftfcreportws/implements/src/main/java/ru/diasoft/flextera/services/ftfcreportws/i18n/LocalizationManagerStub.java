package ru.diasoft.flextera.services.ftfcreportws.i18n;

import ru.diasoft.core.util.localization.LocalizationManager;

public class LocalizationManagerStub implements LocalizationManager {

	@Override
	public String getMessage(String resourceBundleName) {
		return FTFCReportMessage.getLocalizedString(resourceBundleName, null);
	}

	@Override
	public String getMessage(String locale, String resourceBundleName) {
		return FTFCReportMessage.getLocalizedString(resourceBundleName, locale);
	}

	@Override
	public String getFormattedMessage(String resourceBundleName, Object... objs) {
		return FTFCReportMessage.formatLocalizedString(resourceBundleName, objs);
	}

	@Override
	public String getFormattedMessage(String locale, String resourceBundleName,
			Object... objs) {
		return FTFCReportMessage.formatLocalizedString(resourceBundleName, objs);
	}
	
}
