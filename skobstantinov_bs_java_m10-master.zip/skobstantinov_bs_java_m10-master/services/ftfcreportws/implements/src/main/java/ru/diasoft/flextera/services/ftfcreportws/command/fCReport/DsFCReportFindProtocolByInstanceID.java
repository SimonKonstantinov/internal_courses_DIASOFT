package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import org.apache.log4j.Logger;import ru.diasoft.core.application.command.CommandException;import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportFindProtocolByInstanceIDReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportFindProtocolByInstanceIDRes;
/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportFindProtocolByInstanceID extends DsFCReportFindProtocolByInstanceIDStub { 
	
	private static final Logger logger = Logger.getLogger(DsFCReportFindProtocolByInstanceID.class);	private static final String METHOD_NAME = "dsFCReportFindProtocolByInstanceID";
	
	/**
	 * Метод получения протокола
	 * 
	 * @param InstanceID Идентификатор экземпляра запуска отчета
	 * 
	 * @return MessageText Текст сообщения
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */
	@Override
	protected void executeCommand() throws CommandException {		DsFCReportFindProtocolByInstanceIDReq request = getInputData();		DsFCReportFindProtocolByInstanceIDRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());					}		try {			String messageText = "";			if (request.getInstanceID() != null) {				messageText = ProtocolDAO.getInstance().getByInstanceID(request.getInstanceID());			}							response.setMessageText(messageText);									if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());			}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);						CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}		
		
	}
}
