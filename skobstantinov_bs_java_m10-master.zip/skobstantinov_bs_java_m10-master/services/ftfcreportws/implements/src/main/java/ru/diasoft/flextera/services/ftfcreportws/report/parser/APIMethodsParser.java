package ru.diasoft.flextera.services.ftfcreportws.report.parser;

import java.io.File;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.history.ReportHistoryDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;
import ru.diasoft.flextera.services.ftfcreportws.report.method.APIAction;
import ru.diasoft.flextera.services.ftfcreportws.report.method.APIActionFactory;
import ru.diasoft.flextera.services.ftfcreportws.report.method.Method;
import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportProcessExecuteBuildingRes;
import ru.diasoft.flextera.services.ftfcreportws.utils.ExecuteStatus;
import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;

public class APIMethodsParser {

	private static final String API_ELEMENT = "//api";
	private static final String ACTION_ELEMENT = "method | merge | sql | createIndex";
	
	private static APIMethodsParser instance = new APIMethodsParser();
	
	private Logger logger = Logger.getLogger(APIMethodsParser.class);
	
	public static APIMethodsParser getInstance() {
		return instance;
	}

	private APIMethodsParser(){
	}
	
	@SuppressWarnings("unchecked")
	public List<APIAction> parseAPIMethods(File reportConfigFile, DsFCReportProcessExecuteBuildingRes response){
		List<APIAction> resultList = new LinkedList<APIAction>(); 
		if(logger.isDebugEnabled()){
			logger.debug("parseApiParameters has started");
		}
		
		try {
			SAXReader reader = new SAXReader();
			Document document = reader.read(reportConfigFile);
			Element apiRootElement = (Element) document.selectSingleNode(API_ELEMENT);
			
			List<Element> methodElementList = apiRootElement.selectNodes(ACTION_ELEMENT);
			for (Element actionElement : methodElementList) {
				if(logger.isDebugEnabled()){
					logger.debug("Processing api action [" + actionElement.getName() + "] " + actionElement.attributeValue(Method.Constanst.NAME) + ", content = \n" + actionElement.asXML());
				}
	
				APIAction action = APIActionFactory.getInstance().createAction(actionElement, response);
				
				resultList.add(action);
			}
			
		} catch (Exception e) {
			resultList = null;			
			 
			String errorMessage = RetCode.INCORRECT_REPORT_CONFIG_FILE_TEMPLATE.getMessage(reportConfigFile.getAbsolutePath(), e.getLocalizedMessage());
			logger.error(errorMessage, e);
			
			// Протокол
			ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.INCORRECT_CONFIG_TEMPLATE);				
			// Статус отчета ERROR
			ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), "");
			
			response.setReturnCode(RetCode.INCORRECT_REPORT_CONFIG_FILE_TEMPLATE.getCode());
			response.setReturnMsg(errorMessage);
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("parseApiParameters() result = " + resultList);
		}
		
		return resultList;

	}
}
