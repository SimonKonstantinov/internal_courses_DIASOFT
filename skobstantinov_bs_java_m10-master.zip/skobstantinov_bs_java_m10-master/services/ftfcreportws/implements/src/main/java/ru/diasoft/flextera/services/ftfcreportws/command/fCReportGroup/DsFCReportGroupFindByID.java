package ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroup;import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroupDAO;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportGroupFindByIDReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportGroupFindByIDRes;import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;

import org.apache.log4j.Logger;

import ru.diasoft.core.application.command.CommandException;

/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportGroupFindByID extends DsFCReportGroupFindByIDStub {

	
	/**
	 * Метод получения детальной информации о группе пользовательских отчетов
	 * 
	 * @param FCReportGroupID Идентификатор группы пользовательских отчетов
	 * 
	 * @return FCReportGroupID Идентификатор группы пользовательских отчетов
	 * @return FCReportGroupName Наименование группы пользовательских отчетов
	 * @return FCReportGroupSysName Системное наименование группы пользовательских отчетов
	 * @return FCReportGroupDescription Описание группы пользовательских отчетов
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */		private static final Logger logger = Logger.getLogger(DsFCReportGroupFindByID.class);	private static final String METHOD_NAME = "dsFCReportGroupFindByID";	
	@Override
	protected void executeCommand() throws CommandException {		DsFCReportGroupFindByIDReq request = getInputData();		DsFCReportGroupFindByIDRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());					}		try {			ReportGroup reportGroup = ReportGroupDAO.getInstance().getByID(request.getFCReportGroupID());			// Объект по идентификатору не найден			if (reportGroup == null) {								response.setReturnCode(RetCode.OBJECT_NOT_FOUND.getCode());				response.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());				if(logger.isDebugEnabled()){					logger.debug(METHOD_NAME + " Object by ID not found");				}							} 			// Параметры группы отчета			else{				response.setFCReportGroupID(reportGroup.getReportGroupID());				response.setFCReportGroupName(reportGroup.getReportGroupName());				response.setFCReportGroupSysName(reportGroup.getReportGroupSysName());				response.setFCReportGroupDescription(reportGroup.getReportGroupDescription());			}									if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());			}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);						CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}		
		
	}
}
