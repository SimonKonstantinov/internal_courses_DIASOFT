package ru.diasoft.flextera.services.ftfcreportws.utils;

import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import ru.diasoft.flextera.services.ftfcreportws.i18n.FTFCReportMessage;

public class MapUtilsParamIllegalTypeException extends Exception {

	private static final long serialVersionUID = 2896471782318176431L;

	public MapUtilsParamIllegalTypeException(String paramName, Map<?, ?> map, Class<?> paramClass, Class<?>... classes) {
		super(FTFCReportMessage.formatLocalizedString("invalid.parameter.type", paramName, paramClass, ArrayUtils.toString(classes), map));
	}
}
