package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.io.Serializable;
import java.util.List;

public class ActionInputParameter implements Serializable{

	private static final long serialVersionUID = -3240371743308753508L;

	public static interface Constants {
		String NAME = "name";
		String TYPE = "type";
		String VALUE = "value";
	}
	
	private String name;
	
	private String type;
	
	private String value;
	
	private List<ActionInputParameter> subParametersList;

	public ActionInputParameter(){
	}
	
	public ActionInputParameter(String name, String type, String value, List<ActionInputParameter> subParametersList) {
		super();
		this.name = name;
		this.type = type;
		this.value = value;
		this.subParametersList = subParametersList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public List<ActionInputParameter> getSubParametersList() {
		return subParametersList;
	}

	public void setSubParametersList(List<ActionInputParameter> subParametersList) {
		this.subParametersList = subParametersList;
	}

	@Override
	public String toString() {
		return "MethodInputParameter [name=" + name + ", type=" + type + ", value=" + value + ", subParametersList=" + subParametersList
				+ "]";
	}
	
}
