package ru.diasoft.flextera.services.ftfcreportws.utils.external.services;

public class ReportwsConstanst {

	public static final String USER = "user";
	public static final String FTFC_REPORT = "FTFCReport";
	public static final String PROJECT = "project";
	public static final String FILE = "file";
	public static final String SAVE_FILE = "saveFile";
	public static final String REPORT_FORMATS = "REPORTFORMATS";
	public static final String TEMPLATE_NAME = "templateName";
	public static final String REPORT_NAME = "reportName";
	public static final String REPORT_PARAMS = "reportParams";

	public static final String REPORT_NAME_TPR = "ReportName";
	public static final String REPORT_TYPE_TPR = "ReportType";
	public static final Integer REPORT_TYPE_TPR_VALUE = 1;
	public static final String REPORT_INPUT_PARAMS_TPR = "TReportParamListTypeForDSReportExecute";
	public static final String PROJECT_SYS_NAME_TPR = "ProjectSysName";
	public static final String REPORT_UUID = "ReportUUID";

}
