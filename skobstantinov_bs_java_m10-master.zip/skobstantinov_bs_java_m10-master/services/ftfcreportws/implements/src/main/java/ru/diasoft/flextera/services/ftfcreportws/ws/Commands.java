package ru.diasoft.flextera.services.ftfcreportws.ws;

public enum Commands
{
     DSCALL("DSCALL") 
    ,DSCALLASYNC("DSCALLASYNC") 
    ,REMOTE_CALL("remoteCall")
    ,ADM_MODULE_INFO("admModuleInfo")
    ,GET_HEALTH_INFO("getHealthInfo")
    ,GETVERSION("getversion")
    ,DS_AUDITEVENT_INSERT("dsAuditEventInsert")
    ,DS_FCREPORT_MASS_DELETE_INSTANCE("dsFCReportMassDeleteInstance") 
    ,DS_FCREPORT_GROUP_FIND_BY_ID("dsFCReportGroupFindByID") 
    ,DS_FCREPORT_GROUP_BROWSE_LIST_BY_PARAM("dsFCReportGroupBrowseListByParam") 
    ,DS_FCREPORT_GROUP_UPDATE("dsFCReportGroupUpdate") 
    ,DS_FCREPORT_GROUP_DELETE("dsFCReportGroupDelete") 
    ,DS_FCREPORT_FIND_PROTOCOL_BY_INSTANCE_ID("dsFCReportFindProtocolByInstanceID") 
    ,DS_FCREPORT_GROUP_INSERT("dsFCReportGroupInsert") 
    ,DS_FCREPORT_FIND_INPUT_PARAMETER_LIST_BY_REPORT_ID("dsFCReportFindInputParameterListByReportID") 
    ,DS_FCREPORT_PROCESS_EXECUTE_BUILDING("dsFCReportProcessExecuteBuilding") 
    ,DS_FCREPORT_BROWSE_LIST_BY_PARAM("dsFCReportBrowseListByParam") 
    ,DS_FCREPORT_UPDATE("dsFCReportUpdate") 
    ,DS_FCREPORT_DELETE("dsFCReportDelete") 
    ,DS_FCREPORT_MASS_INSERT("dsFCReportMassInsert") 
    ,DS_FCREPORT_BROWSE_LIST_INSTANCE_BY_PARAM("dsFCReportBrowseListInstanceByParam") 
    ,DS_FCREPORT_FIND_BY_ID("dsFCReportFindByID") 
    ,DS_ON_AFTER_FCREPORT_EXECUTE_BUILDING("dsOnAfterFCReportExecuteBuilding") 
	;

    private String commandName;
	
	Commands(String commandName)
	{
		this.commandName = commandName;
	}
	
	public String getCommandName()
	{
		return this.commandName;
	}
}