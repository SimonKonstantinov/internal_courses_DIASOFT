package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;

public class MergeUnion extends APIAction {

	private ActionInputParameter actionInputParameter;
	private Long processID;

	private Logger logger = Logger.getLogger(MergeUnion.class);

	public static interface Constanst {
		String TYPE = "type";
		String INPUT = "input";
		String PARAM = "param";
	}
	
	public MergeUnion(ActionInputParameter actionInputParameter, Long processID) {
		this.actionInputParameter = actionInputParameter;
		this.processID = processID;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute(Map<String, Object> inputParams) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("execute action " + APIActionType.UNION.name() + ". ActionInputParameters = " + actionInputParameter + "; inputParams = " + inputParams);
		}

		try {
			// Протокол "Вызов действия"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL, APIActionType.UNION.name(), actionInputParameter.getName());			
		

			List<Map<String, Object>> resultUnionList = new ArrayList<Map<String, Object>>();

			if(!actionInputParameter.getValue().contains(",")){
				throw new Exception("Invalid format action. Required symbol ','. Correct format value <@List1@, @List2@>");			
			}
		
			for (String parameterName : actionInputParameter.getValue().split(",")) {
				if (parameterName.startsWith("@") && parameterName.endsWith("@")) {
					String sourceListName = parameterName.replaceAll("@", "");

					Object value = inputParams.get(sourceListName);
					if (value != null && value instanceof List) {
						resultUnionList.addAll((List<? extends Map<String, Object>>) value);
					}
				} else {
					throw new Exception("Invalid format action. Required symbol '@'. Correct format value <@List1@, @List2@>");
				}
			}

			// Переименование ключей
			renameParameters(actionInputParameter, resultUnionList);
			// Включение результирующего списка в набор входящих параметров отчета
			inputParams.put(actionInputParameter.getName(), resultUnionList.size() > 0 ? resultUnionList : null);

			if (logger.isDebugEnabled()) {
				logger.debug("execute action " + APIActionType.UNION.name() + " Name = " + actionInputParameter.getName() + ". Result: " + resultUnionList);
			}
		
		} // try
		catch (Exception e) {			
			// Протокол "Ошибка вызова действия"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL_ERROR, APIActionType.UNION.name(), actionInputParameter.getName(), e.getMessage());			
			throw new Exception(e);
		}
	}

	public ActionInputParameter getActionInputParameter() {
		return actionInputParameter;
	}

	public void setActionInputParameter(ActionInputParameter actionInputParameter) {
		this.actionInputParameter = actionInputParameter;
	}

	public Long getProcessID() {
		return processID;
	}

	public void setProcessID(Long processID) {
		this.processID = processID;
	}
}
