package ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol;

public class Protocol {
    public static interface Fields {
    	String PROCESSID           = "ProcessID";
		String PROTOCOLMESSAGEID   = "ProtocolMessageID";
		String PROTOCOLMESSAGETYPE = "ProtocolMessageType";
		String PROTOCOLMESSAGETEXT = "ProtocolMessageText";
		String INSTANCEID          = "InstanceID";
		
		String ORDERBY = "ORDERBY";
		String PAGE = "PAGE";
		String ROWSCOUNT = "ROWSCOUNT";
	}

    private Long	protocolID;
    private Long	instanseID;
    private String  messageText;  
    

	public void setProtocolID(Long protocolID) {
		this.protocolID = protocolID;
	}

	public Long getProtocolID() {
		return protocolID;
	}

	public void setInstanseID(Long instanseID) {
		this.instanseID = instanseID;
	}

	public Long getInstanseID() {
		return instanseID;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public String getMessageText() {
		return messageText;
	}
}
