
package ru.diasoft.flextera.services.ftfcreportws.command;
import java.util.*;
import ru.diasoft.core.application.command.*;
import ru.diasoft.flextera.services.type.*;


public final class GetHealthInfoCommand 
       extends GetHealthInfoCommandStub {

    protected void executeCommand() throws CommandException {
    	GetHealthInfoRes res = new GetHealthInfoRes();
    	Map<String, Integer> crucial = new HashMap<String, Integer>();
        crucial.put("CRUCIAL_EVENTS", 50);
        List<Map<String, Integer>> resList = new ArrayList<Map<String,Integer>>();
        resList.add(crucial);
        Map<String, Object> resMap = new HashMap<String, Object>();
        resMap.put("Result", resList);
        res.fromMap(resMap);
        setOutputData(res);
    }
}
