package ru.diasoft.flextera.services.ftfcreportws.command.dao.report;

public class Report {

    public static interface Fields {
		String REPORTID = "FCReportID";
		String REPORTSYSNAME = "FCReportSysName";
		String REPORTNAME = "FCReportName";
		String USERLOGIN = "UserLogin";
		String TEMPLATENAME = "TemplatePathName";
		String FILEFORMAT = "FileFormat";
		String DELETEDATAFLAG = "DeleteDataFlag";
		String CONFIGPATH = "ConfigPathName";
		String REPORTGROUPID = "FCReportGroupID";
		String REPORTGROUPNAME = "FCReportGroupName";
		
		String ORDERBY = "ORDERBY";
		String PAGE = "PAGE";
		String ROWSCOUNT = "ROWSCOUNT";
	}

	private Long reportID;
	
	private String reportSysname;
	
	private String reportName;
	
	private String userLogin;
	
	private String templateName;
	
	private Integer fileFormat;
	
	private Boolean deleteDataFlag;
	
	private String configPath;
	
	private Long reportGroupID;
	
	private String reportGroupName;
	
	private String orderBy;
	
	private Integer page;
	
	private Integer rowsCount;
	
	public Report() {
	}

	public Long getReportID() {
		return reportID;
	}

	public void setReportID(Long reportID) {
		this.reportID = reportID;
	}

	public String getReportSysname() {
		return reportSysname;
	}

	public void setReportSysname(String reportSysname) {
		this.reportSysname = reportSysname;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(String userLogin) {
		this.userLogin = userLogin;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Integer getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(Integer fileFormat) {
		this.fileFormat = fileFormat;
	}

	public Boolean getDeleteDataFlag() {
		return deleteDataFlag;
	}

	public void setDeleteDataFlag(Boolean deleteDataFlag) {
		this.deleteDataFlag = deleteDataFlag;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public Integer getPage() {
		return page;
	}

	public void setPage(Integer page) {
		this.page = page;
	}

	public Integer getRowsCount() {
		return rowsCount;
	}

	public void setRowsCount(Integer rowsCount) {
		this.rowsCount = rowsCount;
	}

	public String getConfigPath() {
		return configPath;
	}

	public void setConfigPath(String configPath) {
		this.configPath = configPath;
	}

	@Override
	public String toString() {
		return "Report [reportID=" + reportID + ", reportSysname=" + reportSysname + ", reportName=" + reportName + ", userLogin=" + userLogin
				+ ", templateName=" + templateName + ", fileFormat=" + fileFormat + ", deleteDataFlag=" + deleteDataFlag + ", configPath=" + configPath
				+ ", orderBy=" + orderBy + ", page=" + page + ", rowsCount=" + rowsCount + "]";
	}

	public Long getReportGroupID() {
		return reportGroupID;
	}

	public void setReportGroupID(Long reportGroupID) {
		this.reportGroupID = reportGroupID;
	}

	public String getReportGroupName() {
		return reportGroupName;
	}

	public void setReportGroupName(String reportGroupName) {
		this.reportGroupName = reportGroupName;
	}
}
