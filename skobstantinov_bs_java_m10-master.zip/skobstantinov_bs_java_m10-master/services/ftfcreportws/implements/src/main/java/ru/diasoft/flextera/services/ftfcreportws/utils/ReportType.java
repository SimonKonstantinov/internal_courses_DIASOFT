package ru.diasoft.flextera.services.ftfcreportws.utils;

public enum ReportType {

	JRXML("jrxml"),
	TPR("tpr");
	
	private String extension;
	
	private ReportType(String extension) {
		this.extension = extension;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}
}
