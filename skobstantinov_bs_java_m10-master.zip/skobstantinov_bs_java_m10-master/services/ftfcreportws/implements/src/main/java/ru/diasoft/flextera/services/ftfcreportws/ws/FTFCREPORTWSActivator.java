
package ru.diasoft.flextera.services.ftfcreportws.ws;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.cayenne.access.DataContext;
import org.apache.cayenne.access.DataDomain;
import org.apache.cayenne.access.DataNode;
import org.apache.cayenne.conf.Configuration;
import org.apache.cayenne.conf.DefaultConfiguration;
import org.apache.log4j.Logger;

import ru.diasoft.core.application.command.CommandRegistry;
import ru.diasoft.core.application.command.CommandRegistryException;
import ru.diasoft.core.application.command.RemoteCommand;
import ru.diasoft.core.persistence.facet.FacetQueryStore;
import ru.diasoft.core.persistence.facet.impl.cayenne.CayenneFacetQueryStore;
import ru.diasoft.core.util.localization.LocalizationManager;
import ru.diasoft.core.util.sandbox.Sandbox;
import ru.diasoft.core.util.sandbox.service.factory.StaticServiceProviderImpl;
import ru.diasoft.fa.registry.client.RegistryClient;
import ru.diasoft.fa.rmi.DSService;
import ru.diasoft.fa.rmi.server.RMIServerStartingThread;
import ru.diasoft.flextera.services.command.AdmmoduleinfoCommand;
import ru.diasoft.flextera.services.command.DSCALLCommand;
import ru.diasoft.flextera.services.command.GetVersionCommand;
import ru.diasoft.flextera.services.command.audit.DsAuditEventInsert;
import ru.diasoft.flextera.services.ftfcreportws.command.DSCALLASYNCReportCommand;
import ru.diasoft.flextera.services.ftfcreportws.command.GetHealthInfoCommand;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportBrowseListByParam;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportBrowseListInstanceByParam;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportDelete;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportFindByID;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportFindInputParameterListByReportID;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportFindProtocolByInstanceID;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportMassDeleteInstance;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportMassInsert;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportProcessExecuteBuilding;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReport.DsFCReportUpdate;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup.DsFCReportGroupBrowseListByParam;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup.DsFCReportGroupDelete;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup.DsFCReportGroupFindByID;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup.DsFCReportGroupInsert;
import ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup.DsFCReportGroupUpdate;
import ru.diasoft.flextera.services.ftfcreportws.i18n.LocalizationManagerStub;
import ru.diasoft.flextera.services.ftfcreportws.utils.ProjectConstants;
import ru.diasoft.flextera.services.ftfcreportws.utils.event.EventFacade;
import ru.diasoft.flextera.services.ftfcreportws.utils.event.EventFacadeClientRegisterImpl;
import ru.diasoft.services.config.Config;

public class FTFCREPORTWSActivator {
	public static final String WS_CONFIG = "ftfcreportws";

	private static Logger LOGGER = Logger.getLogger(FTFCREPORTWSActivator.class);

	private static boolean activated = false;
	
	public static String NODE_NAME = "FTFCREPORTWSNode";

	private static RMIServerStartingThread rmiService;

	private FTFCREPORTWSActivator() {
	}

	static synchronized final void deactivate() {
	}

	static synchronized final void activate() {
		if(activated) {
			return;
		}

        try {
			DefaultConfiguration config = new DefaultConfiguration("ftfcreportws-cayenne.xml");
			config.initialize();

			DataDomain dataDomain = config.getDomain();
			DataSource dataSource = Config.getConfig(WS_CONFIG).getDataSource();
			DataNode node = dataDomain.getNode(NODE_NAME);
			node.setDataSource(dataSource);
            
			Sandbox.INSTANCE.registerServiceProvider(
				new StaticServiceProviderImpl(
					FacetQueryStore.class, createQueryStore()
				)
			);

			Sandbox.INSTANCE.registerServiceProvider(
				new StaticServiceProviderImpl(
					CayenneFacetQueryStore.class, new CayenneFacetQueryStore()
				)
			);

            Sandbox.INSTANCE.registerServiceProvider(
				new StaticServiceProviderImpl(
					DataContext.class, dataDomain.createDataContext()
				)
			);

			Sandbox.INSTANCE.registerServiceProvider(
				new StaticServiceProviderImpl(
					DataDomain.class, dataDomain
				)
			);

			Sandbox.INSTANCE.registerServiceProvider(
				new StaticServiceProviderImpl(
						LocalizationManager.class, new LocalizationManagerStub()
				)
			);
			
	        Sandbox.INSTANCE.registerServiceProvider(
	        		new StaticServiceProviderImpl(
	        				RegistryClient.class, new RegistryClient(ProjectConstants.SERVICE_NAME, null)));
	        
	        Sandbox.INSTANCE.registerServiceProvider(
	        		new StaticServiceProviderImpl(
	        				EventFacade.class, new EventFacadeClientRegisterImpl()));


        	registringCommand();
//        	registerRights();
        } catch(Exception e) {
			LOGGER.error(e.getMessage(), e);
        }

        activated = true;
    }
    
	public static void registringCommand() {
		CommandRegistry registry = CommandRegistry.getInstance();

		try {
			registry.bind(Commands.DSCALL.getCommandName(), DSCALLCommand.class);
			registry.bind(Commands.DSCALLASYNC.getCommandName(), DSCALLASYNCReportCommand.class);
			registry.bind(Commands.REMOTE_CALL.getCommandName(), RemoteCommand.class);
			registry.bind(Commands.ADM_MODULE_INFO.getCommandName(), AdmmoduleinfoCommand.class);
			registry.bind(Commands.GETVERSION.getCommandName(), GetVersionCommand.class);
			registry.bind(Commands.GET_HEALTH_INFO.getCommandName(), GetHealthInfoCommand.class);
			registry.bind(Commands.DS_AUDITEVENT_INSERT.getCommandName(), DsAuditEventInsert.class);
			registry.bind(Commands.DS_FCREPORT_BROWSE_LIST_BY_PARAM.getCommandName(), DsFCReportBrowseListByParam.class);
			registry.bind(Commands.DS_FCREPORT_UPDATE.getCommandName(), DsFCReportUpdate.class);
			registry.bind(Commands.DS_FCREPORT_BROWSE_LIST_INSTANCE_BY_PARAM.getCommandName(), DsFCReportBrowseListInstanceByParam.class);
			registry.bind(Commands.DS_FCREPORT_FIND_BY_ID.getCommandName(), DsFCReportFindByID.class);
			registry.bind(Commands.DS_FCREPORT_PROCESS_EXECUTE_BUILDING.getCommandName(), DsFCReportProcessExecuteBuilding.class);
			registry.bind(Commands.DS_FCREPORT_DELETE.getCommandName(), DsFCReportDelete.class);
			registry.bind(Commands.DS_FCREPORT_MASS_INSERT.getCommandName(), DsFCReportMassInsert.class);
			registry.bind(Commands.DS_FCREPORT_FIND_PROTOCOL_BY_INSTANCE_ID.getCommandName(), DsFCReportFindProtocolByInstanceID.class);
			registry.bind(Commands.DS_FCREPORT_FIND_INPUT_PARAMETER_LIST_BY_REPORT_ID.getCommandName(), DsFCReportFindInputParameterListByReportID.class);
			registry.bind(Commands.DS_FCREPORT_GROUP_DELETE.getCommandName(), DsFCReportGroupDelete.class);
			registry.bind(Commands.DS_FCREPORT_GROUP_BROWSE_LIST_BY_PARAM.getCommandName(), DsFCReportGroupBrowseListByParam.class);
			registry.bind(Commands.DS_FCREPORT_GROUP_FIND_BY_ID.getCommandName(), DsFCReportGroupFindByID.class);
			registry.bind(Commands.DS_FCREPORT_GROUP_INSERT.getCommandName(), DsFCReportGroupInsert.class);
			registry.bind(Commands.DS_FCREPORT_GROUP_UPDATE.getCommandName(), DsFCReportGroupUpdate.class);
			registry.bind(Commands.DS_FCREPORT_MASS_DELETE_INSTANCE.getCommandName(), DsFCReportMassDeleteInstance.class);

        } catch (CommandRegistryException e) {
			e.printStackTrace();
        }
    }
    
//    private static void registerRights() throws Exception {
//		Sandbox.INSTANCE.registerServiceProvider(new StaticServiceProviderImpl(PermissionManager.class, new BasePermissionManager()));
//
//		AdmmoduleinfoCommand.RightList rightList = new AdmmoduleinfoCommand.RightList();
//
//		for (Commands c : Commands.values()) {
//			ApplicationCommand<? extends TransferObject, ? extends TransferObject> cmd = CommandRegistry.getInstance().lookup(c.getCommandName());
//
//			CheckRight checkRight = cmd.getClass().getAnnotation(CheckRight.class);
//			if (checkRight != null) {
//				String rightName = checkRight.value();
//				if ("".equals(rightName)) {
//					rightName = c.getCommandName();
//				}
//				Right right = new Right();
//				right.setRIGHTNAME(rightName);
//				right.setRIGHTSYSNAME(rightName);
//				rightList.add(right);
//			}
//		}
//
//		Sandbox.INSTANCE.registerServiceProvider(new StaticServiceProviderImpl(AdmmoduleinfoCommand.RightList.class, rightList));
//	}
	
	protected static FacetQueryStore createQueryStore() {
		CayenneFacetQueryStore queryStore = new CayenneFacetQueryStore();
//		CayenneFacetQueryFactory factory = null;
		return queryStore;
	}
	
    protected static DataSource createDataSource()
    {
        try 
        {
            DataSource dataSource = Config.getConfig(WS_CONFIG).getDataSource();
            
            LOGGER.info("in createDataSource, dataSource = " + dataSource.getConnection());
            
            Configuration.getSharedConfiguration().getDomain().getNode(NODE_NAME).setDataSource(dataSource);
            
            return dataSource;
        } 
        catch (Exception ex) 
        {
        	LOGGER.error("Exception while creating datasource: " + ex.getMessage(), ex);
        	
        	throw new RuntimeException(ex);
        }

    }
    
	protected static void startRMI(DSService service) {
		Object paramObj = Config.getConfig(WS_CONFIG).getAllParams().get("rmi");
		if (paramObj instanceof Map) {
			Map<?, ?> rmi = (Map<?, ?>)paramObj;
			rmiService = new RMIServerStartingThread(
					(String)rmi.get("serverhost"),
					Integer.valueOf((String)rmi.get("serverport")),
					WS_CONFIG,
					service,
					Integer.valueOf((String)rmi.get("serviceport")));
			rmiService.start();
		}
	}
	
	protected static void stopRMI() {
		if(rmiService != null)
			rmiService.stopThread();
	}
}
