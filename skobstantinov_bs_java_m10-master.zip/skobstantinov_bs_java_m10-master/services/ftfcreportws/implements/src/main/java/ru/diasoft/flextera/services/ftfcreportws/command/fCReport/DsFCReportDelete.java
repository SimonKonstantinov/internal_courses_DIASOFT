package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import org.apache.log4j.Logger;import ru.diasoft.core.application.command.CommandException;import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportDAO;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportDeleteReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportDeleteRes;import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;
/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportDelete extends DsFCReportDeleteStub {
	private static final String METHOD_NAME = "dsFCReportDelete";	
	private static final Logger logger = Logger.getLogger(DsFCReportDelete.class);
	/**	 * Метод удаления пользовательского отчета	 * 	 * @param FCReportID Идентификатор отчета	 * 	 * @return ReturnMsg Сообщение	 * @return ReturnCode Код	 */	
	@Override
	protected void executeCommand() throws CommandException {		DsFCReportDeleteReq request = getInputData();		DsFCReportDeleteRes response = getOutputData();		
		if(logger.isDebugEnabled()){						logger.debug(METHOD_NAME + " has started. Request = " + request.toString());		}		try {						Long retVal = ReportDAO.getInstance().delete(request.getFCReportID()); 			response.setReturnCode(0L);			response.setReturnMsg("");			if (retVal > 0){				response.setReturnCode(retVal);				// Объект по идентификатору не найден				if (retVal == RetCode.OBJECT_NOT_FOUND.getCode())										response.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());				if(logger.isDebugEnabled()){					logger.debug(METHOD_NAME + " Object by ID not found");				}											}									if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());							}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);						CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}		
	}
}
