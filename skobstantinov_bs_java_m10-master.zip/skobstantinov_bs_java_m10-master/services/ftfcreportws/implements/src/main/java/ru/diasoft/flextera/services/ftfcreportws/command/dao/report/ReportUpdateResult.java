package ru.diasoft.flextera.services.ftfcreportws.command.dao.report;

public class ReportUpdateResult {
	private Long   returnCode;
	private String returnMsg;

	private Long   reportID;

	public Long getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Long returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public Long getReportID() {
		return reportID;
	}

	public void setReportID(Long reportID) {
		this.reportID = reportID;
	}
}
