package ru.diasoft.flextera.services.ftfcreportws.event;
import org.apache.log4j.Logger;import ru.diasoft.core.application.command.CommandException;

/**
 * @see {@link #executeCommand()}
 */
public class DsOnAfterFCReportExecuteBuilding extends DsOnAfterFCReportExecuteBuildingStub {
	
	/**
	 * Событие завершения выполнения отчета
	 * 
	 * @param ProcessID Идентификатор запущенного процесса
	 * @param ExecuteStatus Статус формирования отчета. Возможные значения:<br>
	 *	1 - формируется;<br>
	 *	2 - готов;<br>
	 *	3 - ошибка.
	 * @param ExecuteStatusText Комментарий к статусу формирования отчета
	 * @param IsAsync Флаг для асинхронных событий
	 * 
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */
	@Override
	protected void executeCommand() throws CommandException {
		super.executeCommand();
	}
}
