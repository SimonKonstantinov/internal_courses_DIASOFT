package ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroup;import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroupDAO;import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroupUpdateResult;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportGroupUpdateReq;
import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportGroupUpdateRes;import org.apache.log4j.Logger;
import ru.diasoft.core.application.command.CommandException;

/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportGroupUpdate extends DsFCReportGroupUpdateStub {
	
	
	/**
	 * Изменение группы пользовательских отчетов
	 * 
	 * @param FCReportGroupID Идентификатор группы пользовательских отчетов
	 * @param FCReportGroupName Наименование группы пользовательских отчетов
	 * @param FCReportGroupSysName Системное наименование группы пользовательских отчетов
	 * @param FCReportGroupDescription Описание группы пользовательских отчетов
	 * 
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */	private static final Logger logger = Logger.getLogger(DsFCReportGroupUpdate.class);	private static final String METHOD_NAME = "dsFCReportGroupUpdate";	
	@Override
	protected void executeCommand() throws CommandException {
		DsFCReportGroupUpdateReq request = getInputData();		DsFCReportGroupUpdateRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());					}		try {			ReportGroup reportGroup = new ReportGroup();			reportGroup.setReportGroupID(request.getFCReportGroupID());			reportGroup.setReportGroupName(request.getFCReportGroupName());			reportGroup.setReportGroupSysName(request.getFCReportGroupSysName());			reportGroup.setReportGroupDescription(request.getFCReportGroupDescription());									ReportGroupUpdateResult result = ReportGroupDAO.getInstance().update(reportGroup);						response.setReturnCode(result.getReturnCode());			response.setReturnMsg(result.getReturnMsg());								} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);						CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}		
	}
}
