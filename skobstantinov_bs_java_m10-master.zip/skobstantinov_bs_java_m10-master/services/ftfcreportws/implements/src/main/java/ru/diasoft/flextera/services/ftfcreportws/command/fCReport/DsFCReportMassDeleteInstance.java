package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.history.ReportHistoryDAO;import ru.diasoft.flextera.services.ftfcreportws.command.dao.history.ReportHistoryMassDeleteResult;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportMassDeleteInstanceReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.*;

import org.apache.log4j.Logger;

import ru.diasoft.core.application.command.CommandException;


/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportMassDeleteInstance extends DsFCReportMassDeleteInstanceStub {
	
	private static final Logger logger = Logger.getLogger(DsFCReportMassDeleteInstance.class);	public static final String METHOD_NAME = "dsFCReportMassDeleteInstance";	
	
	/**
	 * Метод удаления экземпляров запуска отчетов
	 * 
	 * @param InstanceIDList Список идентификаторов удаляемых экземпляров запуска отчетов
	 * 
	 * @return NotificationList Список ошибок
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */
	@Override
	protected void executeCommand() throws CommandException {
		DsFCReportMassDeleteInstanceReq request = getInputData();		DsFCReportMassDeleteInstanceRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());		}		try {			ReportHistoryMassDeleteResult massDeleteResult = ReportHistoryDAO.getInstance().massDelete(request.getInstanceIDList());			response.setNotificationList(massDeleteResult.getReportHistoryNtfList());			response.setReturnCode(massDeleteResult.getReturnCode());			response.setReturnMsg(massDeleteResult.getReturnMsg());						if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());			}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);			CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}	}		
	
}
