package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;
import ru.diasoft.flextera.services.ftfcreportws.report.database.DataLoader;
import ru.diasoft.utils.text.StringUtils;

public class SqlAction extends APIAction implements Serializable{

	private static final long serialVersionUID = 875493133776004155L;
	private Logger logger = Logger.getLogger(SqlAction.class);
	
	public static interface Constants {
		String EXPRESSION = "expression";
	}
	
	private String expression;
	
	private MethodOutputParameter outputParameter;
	
	private Long processID;
	public List<ActionInputParameter> getInputParameterList() {
		return inputParameterList;
	}

	public void setInputParameterList(List<ActionInputParameter> inputParameterList) {
		this.inputParameterList = inputParameterList;
	}

	private List<ActionInputParameter> inputParameterList;

	public SqlAction(String expression, MethodOutputParameter outputParameter, List<ActionInputParameter> inputParameterList, Long processID) {
		this.expression = expression;
		this.outputParameter = outputParameter;
		this.inputParameterList=inputParameterList;
		this.processID = processID;
	}
	
	@Override
	public void execute(Map<String, Object> inputParams) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("execute sql [" + expression + "] with inputParams = " + inputParams);
		}	
		
		try {
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL, APIActionType.SQL.name(), expression);
			executeSQLQuery(inputParams);
			
		} catch (Exception e) {
			String errorMessage = "Execute sql [" + expression + "] error";
			logger.error(errorMessage, e);
			
			// Протокол "Ошибка вызова метода"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL_ERROR, APIActionType.SQL.name(), expression, e.getMessage());			
			
			throw new Exception(e);
		}

	}

	private void executeSQLQuery(Map<String, Object> inputParams) throws Exception {
		List<Map<String, Object>> resultList = DataLoader.getInstance().executeQuery(expression, processID, inputParameterList, inputParams);
		if(logger.isDebugEnabled()){
			logger.debug("execute query result = " + resultList);
		}
		processOutputParameter(inputParams, resultList, outputParameter);
	}

	public String getExpression() {
		return expression;
	}
	
	public void setExpression(String expression) {
		this.expression = expression;
	}

	public MethodOutputParameter getOutputParameter() {
		return outputParameter;
	}

	public void setOutputParameter(MethodOutputParameter outputParameter) {
		this.outputParameter = outputParameter;
	}

	public Long getProcessID() {
		return processID;
	}

	public void setProcessID(Long processID) {
		this.processID = processID;
	}

	@Override
	public String toString() {
		return "SqlAction [expression=" + expression + ", outputParameter=" + outputParameter + ", processID=" + processID + "]";
	}

	private void processOutputParameter(Map<String, Object> inputParams, List<Map<String, Object>> resultList, MethodOutputParameter outputParameter)
			throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Processing output paramater: " + outputParameter);
		}
		
		String outputParameterTableName = outputParameter.getTableName();
		
		String parameterSysname = outputParameter.getSysname();
		String parameterName = outputParameter.getName();
		
		inputParams.put(parameterSysname != null ? parameterSysname : parameterName, resultList);
		
		if(!StringUtils.isEmpty(outputParameterTableName) && resultList != null && resultList.size() > 0){
			
			DataLoader.getInstance().load(outputParameterTableName, resultList, processID);
			ProtocolDAO.getInstance().addReportProtocol(processID, ProtocolMessage.SQL_SAVE_OUTPUT_TABLE, expression, outputParameterTableName);						
		}
	}

}
