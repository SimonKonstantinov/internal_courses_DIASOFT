package ru.diasoft.flextera.services.ftfcreportws.utils.external;

import java.util.Map;

import ru.diasoft.services.common.QueryBuilder;
import ru.diasoft.utils.XMLUtil;

public class ExternalServiceImpl extends ExternalService{

	@Override
	public Map<String, Object> callExternalService(XMLUtil xmlUtil, String serviceName, String methodName, Map<String, Object> params) throws Exception {
		return xmlUtil.callService(serviceName, methodName, params);
	}
	
    @Override
    public long getNewId(String entityName) throws Exception {
		return QueryBuilder.getNewIdLong(entityName, 1);
    }

    @Override
    public long getNewIds(String entityName, int quantity) throws Exception {
		return QueryBuilder.getNewIdLong(entityName, quantity);
    }
	

}
