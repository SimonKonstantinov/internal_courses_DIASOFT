package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtilsParamIllegalTypeException;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtilsParamNotFoundException;

public abstract class AbstractJoinAction extends APIAction {

	protected ActionInputParameter actionInputParameter;	
	protected Long processID;	
	protected String valueON;	
	
	private Logger logger = Logger.getLogger(AbstractJoinAction.class);
	
	public abstract void join(List<Map<String, Object>> resultJoinList, List<Map<String, Object>> sourceList1,
			List<Map<String, Object>> sourceList2, String relList1Key, String relList2Key);
	
	protected List<Map<String, Object>> executeJoin(Map<String, Object> inputParams) throws Exception, MapUtilsParamNotFoundException,
			MapUtilsParamIllegalTypeException {
		List<Map<String, Object>> resultJoinList = new ArrayList<Map<String, Object>>();

		if (!actionInputParameter.getValue().contains(",")) {
			throw new Exception("Invalid format action. Required symbol ','. Correct format value <@List1@, @List2@>");
		}

		String[] sourceNameArray = actionInputParameter.getValue().split(",");
		// Набор #1
		List<Map<String, Object>> sourceList1 = getSourceListByListName(sourceNameArray[0], inputParams);		
		String relList1Key = getKeyListByListName(sourceNameArray[0]);
		// Набор #2
		List<Map<String, Object>> sourceList2 = getSourceListByListName(sourceNameArray[1], inputParams);
		String relList2Key = getKeyListByListName(sourceNameArray[1]);		
		// JOIN
		join(resultJoinList, sourceList1, sourceList2, relList1Key, relList2Key);

		// Переименование ключей
		renameParameters(actionInputParameter, resultJoinList);
		// Включение результирующего списка в набор входящих параметров отчета
		inputParams.put(actionInputParameter.getName(), resultJoinList.size() > 0 ? resultJoinList : null);
		return resultJoinList;
	}

	public ActionInputParameter getActionInputParameter() {
		return actionInputParameter;
	}

	public void setActionInputParameter(ActionInputParameter actionInputParameter) {
		this.actionInputParameter = actionInputParameter;
	}

	public Long getProcessID() {
		return processID;
	}

	public void setProcessID(Long processID) {
		this.processID = processID;
	}

	public void setValueON(String valueON) {
		this.valueON = valueON;
	}

	public String getValueON() {
		return valueON;
	}
	
	private List<Map<String, Object>> getSourceListByListName(String sourceName, Map<String, Object> inputParams) throws Exception {
		List<Map<String, Object>> sourceList = null;
		if (sourceName.startsWith("@") && sourceName.endsWith("@")) {
			String sourceListName = sourceName.replaceAll("@", "");

			Object SourceObj = inputParams.get(sourceListName);
			if (SourceObj != null) {
				if (!(SourceObj instanceof List)) {
					throw new Exception("Invalid type of parameter: " + sourceListName + ". Expected java.util.List, but was "
							+ SourceObj.getClass());
				}

				sourceList = MapUtils.asList(inputParams, sourceListName);
			}

			if (logger.isDebugEnabled()) {
				if (sourceList != null) {
					logger.debug("exists list: Name = " + sourceListName);
				} else {
					logger.debug("not exists list: Name = " + sourceListName);
				}
			}
		} else {
			throw new Exception("Invalid format action. Required symbol '@'. Correct format value <@List1@, @List2@>");
		}		
		return sourceList;
	}
	
	private String getKeyListByListName(String sourceName) throws Exception {
		String sourceListName = sourceName.replaceAll("@", "");
		
		String[] relationArray = getValueON().split("=");
		if (relationArray.length < 2) {
			throw new Exception("Invalid format action. Required symbol '='. Correct format ON value <@List1@.@Key1@=@List2@.@Key2@>");
		}
		
		String[] relFirstArray = relationArray[0].split("\\.");
		String[] relSecondArray = relationArray[1].split("\\.");
		
		if ((relFirstArray.length != 2) || (relSecondArray.length != 2)) {
			throw new Exception("Invalid format action. Required symbol '.'. Correct format ON value <@List1@.@Key1@=@List2@.@Key2@>");	
		}
		
		String relFirstListName = relFirstArray[0].replaceAll("@", "");
		String relFirstListKey = relFirstArray[1].replaceAll("@", "");
		String relSecondListName = relSecondArray[0].replaceAll("@", "");
		String relSecondListKey = relSecondArray[1].replaceAll("@", "");		
		
		
		String relListKey = null;
		
		if (sourceListName.equals(relFirstListName)) {
			relListKey = relFirstListKey;
		} else if (sourceListName.equals(relSecondListName)) {
			relListKey = relSecondListKey;
		} else {
			relListKey = "undefined";
		}
		
		return relListKey;
	}

}
