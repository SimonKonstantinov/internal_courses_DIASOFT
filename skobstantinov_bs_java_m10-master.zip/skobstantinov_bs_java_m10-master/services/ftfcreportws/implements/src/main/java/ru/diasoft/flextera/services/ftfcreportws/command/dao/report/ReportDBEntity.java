package ru.diasoft.flextera.services.ftfcreportws.command.dao.report;

import java.sql.Types;

import org.apache.cayenne.map.DbAttribute;
import org.apache.cayenne.map.DbEntity;

import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;

public class ReportDBEntity {

	public static final String TABLENAME = "FCR_REPORT";
	
	public interface Field {
		String REPORTID = "REPORTID";
		String REPORTSYSNAME = "REPORTSYSNAME";
		String REPORTNAME = "REPORTNAME";
		String USERLOGIN = "USERLOGIN";
		String TEMPLATENAME = "TEMPLATENAME";
		String FILEFORMAT = "FILEFORMAT";
		String DELETEDATAFLAG = "DELETEDATAFLAG";
		String CONFIGPATH = "CONFIGPATH";
		String REPORTGROUPID = "REPORTGROUPID";
	}

	private static DbEntity dbEntity = null;
	
	public static DbEntity getDbEntity() {
		if (dbEntity == null) {
			dbEntity = new DbEntity();
			dbEntity.setName(TABLENAME);
			dbEntity.setDataMap(DataUtils.getCommonUserMap());
			dbEntity.addAttribute(new DbAttribute(Field.REPORTID, Types.BIGINT, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.REPORTSYSNAME, Types.VARCHAR, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.REPORTNAME, Types.VARCHAR, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.USERLOGIN, Types.VARCHAR, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.TEMPLATENAME, Types.VARCHAR, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.FILEFORMAT, Types.INTEGER, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.DELETEDATAFLAG, Types.INTEGER, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.CONFIGPATH, Types.VARCHAR, dbEntity));            
			dbEntity.addAttribute(new DbAttribute(Field.REPORTGROUPID, Types.BIGINT, dbEntity));
		}		
		return dbEntity;
	}
	
}
