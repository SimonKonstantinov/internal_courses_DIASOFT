package ru.diasoft.flextera.services.ftfcreportws.command.dao.group;

public class ReportGroup {
	public static interface Fields {
		String REPORTGROUPID = "FCReportGroupID";
		String NAME          = "FCReportGroupName";
		String SYSNAME       = "FCReportGroupSysName";
		String DESCRIPTION   = "FCReportGroupDescription";		
		
		String ORDERBY = "ORDERBY";
		String PAGE = "PAGE";
		String ROWSCOUNT = "ROWSCOUNT";
		
	}
	
	private Long   reportGroupID;
	private String reportGroupName;
	private String reportGroupSysName;
	private String reportGroupDescription;
	
	public Long getReportGroupID() {
		return reportGroupID;
	}
	public void setReportGroupID(Long reportGroupID) {
		this.reportGroupID = reportGroupID;
	}
	public String getReportGroupName() {
		return reportGroupName;
	}
	public void setReportGroupName(String reportGroupName) {
		this.reportGroupName = reportGroupName;
	}
	public String getReportGroupSysName() {
		return reportGroupSysName;
	}
	public void setReportGroupSysName(String reportGroupSysName) {
		this.reportGroupSysName = reportGroupSysName;
	}
	public String getReportGroupDescription() {
		return reportGroupDescription;
	}
	public void setReportGroupDescription(String reportGroupDescription) {
		this.reportGroupDescription = reportGroupDescription;
	}
	
	@Override
	public String toString() {
		return "ReportGroup [ID = "          + reportGroupID 
		                + ", Sysname = "     + reportGroupSysName
		                + ", Name = "        + reportGroupName 
		                + ", Description = " + reportGroupDescription
				        + "]";
	}	

}
