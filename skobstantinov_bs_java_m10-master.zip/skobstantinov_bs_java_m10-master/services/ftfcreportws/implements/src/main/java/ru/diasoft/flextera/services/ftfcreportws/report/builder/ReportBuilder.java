package ru.diasoft.flextera.services.ftfcreportws.report.builder;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.history.ReportHistoryDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.Report;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportDAO;
import ru.diasoft.flextera.services.ftfcreportws.report.api.APIActionExecutor;
import ru.diasoft.flextera.services.ftfcreportws.report.database.DataLoader;
import ru.diasoft.flextera.services.ftfcreportws.report.method.APIAction;
import ru.diasoft.flextera.services.ftfcreportws.report.method.Method;
import ru.diasoft.flextera.services.ftfcreportws.report.method.MethodOutputParameter;
import ru.diasoft.flextera.services.ftfcreportws.report.parser.APIMethodsParser;
import ru.diasoft.flextera.services.ftfcreportws.report.parser.InputParametersParser;
import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportProcessExecuteBuildingReq;
import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportFindInputParameterListByReportIDRes;
import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportProcessExecuteBuildingRes;
import ru.diasoft.flextera.services.ftfcreportws.utils.ConfigUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.ExecuteStatus;
import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.services.InvokerFactory;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.services.ReportWSInvoker;
import ru.diasoft.utils.XMLUtil;
import ru.diasoft.utils.text.StringUtils;

public class ReportBuilder {

	private static final String TEMPLATE_XSD_FILE_NAME = "template.xsd";
	private Logger logger = Logger.getLogger(ReportBuilder.class);
	
	public static ReportBuilder getInstance() {
		return new ReportBuilder();
	}
	
	private ReportBuilder(){
	}

	public void createInputParametersStructure(Long reportID, DsFCReportFindInputParameterListByReportIDRes response) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("createInputParametersStructure has started");
		}
		
		Report report = ReportDAO.getInstance().getByID(reportID);
		
		//Объект по идентификатору не найден
		if (report == null) {
			if(logger.isDebugEnabled()){
				logger.error("report not found by id = " + reportID);
			}

			response.setReturnCode(RetCode.OBJECT_NOT_FOUND.getCode());
			response.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());
			return;				
		}

		String subPath = report.getConfigPath();
		String pathToConfig = ConfigUtils.getPathToReportConfig();
		File reportConfigFile = new File(pathToConfig, subPath);
		
		//Конфигурационный файл не найден
		if(!reportConfigFile.exists()){
			if(logger.isDebugEnabled()){
				logger.error("report config not found by path = " + reportConfigFile.getAbsolutePath());
			}
			
			response.setReturnCode(RetCode.REPORT_CONFIG_FILE_NOT_FOUND.getCode());
			response.setReturnMsg(RetCode.REPORT_CONFIG_FILE_NOT_FOUND.getMessage(reportConfigFile.getAbsolutePath()));
			
			return;				
		}
		
		try {
			InputParametersParser parser = InputParametersParser.getInstance();
			parser.createInputParametersFromFile(reportConfigFile, response);
		} catch (Exception e) {
			String errorMessage = RetCode.INCORRECT_REPORT_CONFIG_FILE_TEMPLATE.getMessage(reportConfigFile.getAbsolutePath(), e.getLocalizedMessage());			
			logger.error(errorMessage);
			
			response.setReturnCode(RetCode.INCORRECT_REPORT_CONFIG_FILE_TEMPLATE.getCode());
			response.setReturnMsg(errorMessage);
			return;
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("createInputParametersStructure has finished");
		}
	}
	
	public boolean validateConfigFile(File configFile, DsFCReportProcessExecuteBuildingRes response) {
		try {
			if(logger.isDebugEnabled()){
				logger.debug("Validation of report template has started.");
				
				URL xsdURL = ReportBuilder.class.getResource(TEMPLATE_XSD_FILE_NAME); 
				if(xsdURL != null){
					logger.debug("XSD file path = " + xsdURL.getPath());
				}
			}
			
			InputStream inputStream = ReportBuilder.class.getResourceAsStream(TEMPLATE_XSD_FILE_NAME);

			SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = factory.newSchema(new StreamSource(inputStream));
			Validator validator = schema.newValidator();
			validator.validate(new StreamSource(configFile));
			
			inputStream.close();

	    } catch (Exception e) {
			// Протокол "Неверный формат конфигурационного файла отчета (XSD)"
			ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.INVALID_CONFIG_TEMPLATE, e.getLocalizedMessage());
			// Статус отчета ERROR
			ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), "");

			response.setReturnCode(RetCode.INCORRECT_REPORT_CONFIG_FILE_TEMPLATE.getCode());
			response.setReturnMsg(RetCode.INCORRECT_REPORT_CONFIG_FILE_TEMPLATE.getMessage());
	    	
			if(logger.isDebugEnabled()){
				logger.debug("Validation of report template has finished with errors", e);
			}
			
	        return false;
	    }
	    
		if(logger.isDebugEnabled()){
			logger.debug("Validation of report template has finished successfully.");
		}	    
		
	    return true;		
	}	
	
	public void buildReport(Long reportHistoryID,
			                DsFCReportProcessExecuteBuildingReq request,
			                DsFCReportProcessExecuteBuildingRes response) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("buildReport has started");
		}

		try {
			Long reportID = request.getFCReportID();

			Report report = ReportDAO.getInstance().getByID(reportID);
			if (report == null) {
				response.setReturnCode(RetCode.OBJECT_NOT_FOUND.getCode());
				response.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());
				return;
			}
			
			// Создание протокола "Запущен процесс с идентификатором ProcessID"
			Long reportProtocolID = ProtocolDAO.getInstance().createReportProtocol(reportHistoryID,
							                                                       ProtocolMessage.REPORT_PROCESS_ID,
							                                                       reportHistoryID.toString());
			if (reportProtocolID == 0L) {
				response.setReturnCode(RetCode.PROTOCOL_CREATE_ERROR.getCode());
				response.setReturnMsg(RetCode.PROTOCOL_CREATE_ERROR.getMessage());
				return;
			}
			// Идентификатор процесса для протоколирования
			response.setProcessID(reportHistoryID);

			File configFile = getReportConfigFile(report.getConfigPath(),
					ConfigUtils.getPathToReportConfig(), response);

			if (configFile != null) {
				if (validateConfigFile(configFile, response) == false) {
					configFile = null;
				}
			}

			File reportTemplateFile = null;
			if (configFile != null) {
				reportTemplateFile = getFileReportTemplateFile(report.getTemplateName(),
						                                       ConfigUtils.getPathToReportDirectory(), 
						                                       response);
			}

			Map<String, Object> reportInputParams = null;
			
			if (configFile != null && reportTemplateFile != null) {
				if (response.getReturnCode() == null || response.getReturnCode() == 0) {
					Map<String, Object> inputParams = getInputParams(
							request.getInputParametrXMLString(), response);
					
					reportInputParams = getInputParams(
							request.getInputParametrXMLString(), response);

					List<APIAction> actionList = null;
					if (response.getReturnCode() == null || response.getReturnCode() == 0) {
						actionList = invokeAPIs(configFile, inputParams, response);
					}

					if (response.getReturnCode() == null || response.getReturnCode() == 0) {
						build(request, report, reportInputParams, response);
					}

					if (response.getReturnCode() == null || response.getReturnCode() == 0) {
						if (report.getDeleteDataFlag() && actionList != null) {
							clearDataTables(actionList, response.getProcessID());
						}
					}
				}
			}

			if (response.getReturnCode() == null || response.getReturnCode() == 0) {
				ReportHistoryDAO.getInstance().modifyReportHistory(
						reportHistoryID, new Date(),
						ExecuteStatus.DONE.getStateCode(), null);
			}

			if (logger.isDebugEnabled()) {
				logger.debug("buildReport has finished");
			}

		} catch (Exception e) {
			// Статус выполнения ERROR
			ReportHistoryDAO.getInstance().modifyReportHistory(reportHistoryID, new Date(), ExecuteStatus.ERROR.getStateCode(), null);
			throw new Exception(e);
		}

	}

	private void build(DsFCReportProcessExecuteBuildingReq request, Report report, Map<String, Object> inputParams, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		ReportWSInvoker reportwsInvoker = InvokerFactory.getInstance().getReportWSInvoker();
		reportwsInvoker.buildReport(request, report, inputParams, response);
		
		// TODO copy file to UploadPath
	}

	private List<APIAction> invokeAPIs(File reportConfigFile, Map<String, Object> inputParams, DsFCReportProcessExecuteBuildingRes response){
		List<APIAction> actionList = APIMethodsParser.getInstance().parseAPIMethods(reportConfigFile, response);
		if(actionList != null){
			try {
				APIActionExecutor.getInstance(inputParams, actionList).execute();
			} catch (Exception e) {
				String errorMessage = RetCode.CALL_EXTERNAL_API_ERROR.getMessage(e.getLocalizedMessage());
				
				logger.error(errorMessage, e);
				
				// Протокол
				ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.CALL_EXTERNAL_API_ERROR, e.getLocalizedMessage());				
				// Статус отчета ERROR
				ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), "");
				
				response.setReturnCode(RetCode.CALL_EXTERNAL_API_ERROR.getCode());
				response.setReturnMsg(errorMessage);
			}
		}
		
		return actionList;
	}

	private File getReportConfigFile(String relativeFilePath, String parentFolder, DsFCReportProcessExecuteBuildingRes response){
		File resultFile = null;
		
		if(!StringUtils.isEmpty(relativeFilePath)){
			resultFile = new File(parentFolder, relativeFilePath);
			
			if(logger.isDebugEnabled()){
				logger.debug("Trying to find file by path = " + resultFile.getAbsolutePath());
			}
			
			//Конфигурационный файл не найден
			if(!resultFile.exists()){
				logger.error("File not found by path = " + resultFile.getAbsolutePath());
				
				// Протокол "Не найден конфигурационный файл"
				ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.CONFIG_FILE_NOT_FOUND, resultFile.getName(), resultFile.getParent());
				// Статус отчета ERROR
				ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), "");
				
				response.setReturnCode(RetCode.REPORT_CONFIG_FILE_NOT_FOUND.getCode());
				response.setReturnMsg(RetCode.REPORT_CONFIG_FILE_NOT_FOUND.getMessage(resultFile.getAbsolutePath()));
				resultFile = null;
			}
			else {
				// Протокол "Найден конфигурационный файл"
				ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.CONFIG_FILE_FOUND, resultFile.getName(), resultFile.getParent());
			}
		} else {
			if(logger.isDebugEnabled()){
				logger.debug("relativeFilePath is empty");
			}
		}

		return resultFile;
	}
	
	private File getFileReportTemplateFile(final String templateFileName, String pathToReportDirectory, DsFCReportProcessExecuteBuildingRes response) {
		File resultFile = new File(pathToReportDirectory, templateFileName);

		if (logger.isDebugEnabled()) {
			logger.debug("Trying to find report template file by path [" + resultFile.getAbsolutePath() + "]");
		}

		if (!resultFile.exists()) {
			logger.error("Report template file not found by path [" + resultFile.getAbsolutePath() + "]");

			// Протокол
			ProtocolDAO.getInstance().addReportProtocol(
				response.getProcessID(),
				ProtocolMessage.TEMPLATE_FILE_NOT_FOUND, templateFileName, resultFile.getParent());
			// Статус отчета ERROR
			ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), "");

			response.setReturnCode(RetCode.REPORT_TEMPLATE_FILE_NOT_FOUND.getCode());
			response.setReturnMsg(RetCode.REPORT_TEMPLATE_FILE_NOT_FOUND.getMessage(templateFileName, resultFile.getParent()));

		} else {
			// Протокол
			ProtocolDAO.getInstance().addReportProtocol(
				response.getProcessID(),
				ProtocolMessage.TEMPLATE_FILE_FOUND, resultFile.getName(), resultFile.getParent());
		}

		return resultFile;
	}

	private Map<String, Object> getInputParams(String inputParameterXMLString, DsFCReportProcessExecuteBuildingRes response) {
		if(logger.isDebugEnabled()){
			logger.debug("Parsing inputParametersXML = " + inputParameterXMLString);
		}
		
		Map<String, Object> inputParamsMap = new HashMap<String, Object>();

		if (!StringUtils.isEmpty(inputParameterXMLString)) {
			try {
				XMLUtil util = new XMLUtil();
				inputParamsMap = util.parse(inputParameterXMLString);
				// Протокол "Успешно определены входящие параметры"
				ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.SUCCESS_INPUT_PARAMETERS_XML, inputParamsMap.toString());				
				
			} catch (Exception e) {
				String errorMessage = RetCode.INCORRECT_INPUT_PARAMETERS_XML.getMessage(inputParameterXMLString); 
				
				logger.error(errorMessage);
				
				// Протокол "Неверный формат входящих параметров"
				ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.INCORRECT_INPUT_PARAMETERS_XML);				
				// Статус отчета ERROR
				ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), "");
				
				response.setReturnCode(RetCode.INCORRECT_INPUT_PARAMETERS_XML.getCode());
				response.setReturnMsg(errorMessage);
			}
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("Parsing inputParametersXML result = " + inputParamsMap);
		}
		
		return inputParamsMap;
	}
	
	private void clearDataTables(List<APIAction> actionList, Long processID) throws SQLException {
		Set<String> tableNames = new HashSet<String>(); 
		for (APIAction action : actionList) {
			
			if(action instanceof Method){
				
				List<MethodOutputParameter> outputParamList = ((Method)action).getOutputParameterList();
				for (MethodOutputParameter methodOutputParameter : outputParamList) {
					if(methodOutputParameter != null && !StringUtils.isEmpty(methodOutputParameter.getTableName())){
						tableNames.add(methodOutputParameter.getTableName());
					}
				}
			}
		}
		
		DataLoader.getInstance().deleteTempData(tableNames, processID);
		// Протокол "Удаление временных данных для процесса ProcessID"
		ProtocolDAO.getInstance().addReportProtocol(processID, ProtocolMessage.DELETE_TEMP_DATA, processID.toString());		
	}


}
