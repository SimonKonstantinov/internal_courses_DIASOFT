package ru.diasoft.flextera.services.ftfcreportws.utils;

/**
 * Типы БД
 */

public enum DataBaseType {
    ORACLE,
    MSSQL,
    DB2,
    SYBASE,
    H2,
    HSQL,
    UNKNOWN
}
