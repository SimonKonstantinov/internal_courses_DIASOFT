package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.io.Serializable;

public class MethodOutputParameter implements Serializable{

	private static final long serialVersionUID = -3240371743308753508L;

	public static interface Constants {
		String NAME = "name";
		String SYSNAME = "sysname";
		String TYPE = "type";
		String VALUE = "value";
		String TABLENAME = "tableName"; 
	}
	
	private String name;
	
	private String type;
	
	private String sysname;
	
	private String tableName;

	private String value;

	public MethodOutputParameter(){
	}
	
	public MethodOutputParameter(String name, String type, String sysname, String tableName, String value) {
		this.name = name;
		this.type = type;
		this.sysname = sysname;
		this.tableName = tableName;
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public String getSysname() {
		return sysname;
	}

	public void setSysname(String sysname) {
		this.sysname = sysname;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Override
	public String toString() {
		return "MethodOutputParameter [name=" + name + ", type=" + type + ", sysname=" + sysname + ", tableName=" + tableName + ", value="
				+ value + "]";
	}
}
