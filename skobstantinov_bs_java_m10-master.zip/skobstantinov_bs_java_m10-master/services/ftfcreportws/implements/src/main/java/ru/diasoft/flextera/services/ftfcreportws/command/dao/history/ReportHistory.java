package ru.diasoft.flextera.services.ftfcreportws.command.dao.history;

import java.util.Date;

public class ReportHistory {
	
    public static interface Fields {
    	String PROCESSID       = "ProcessID";
    	String INSTANCEID      = "InstanceID";
		String REPORTID        = "FCReportID";
		String REPORTSYSNAME   = "FCReportSysName";
		String REPORTNAME      = "FCReportName";
		String USERLOGIN       = "UserLogin";
		String STARTDATE       = "StartDate";
		String ENDDATE         = "EndDate";
		String EXECUTESTATUS   = "ExecuteStatus";
		String REPORTFILENAME  = "FCReportFileName";
		String REPORTGROUPID   = "FCReportGroupID";
		String REPORTGROUPNAME = "FCReportGroupName";
		
		String ORDERBY   = "ORDERBY";
		String PAGE      = "PAGE";
		String ROWSCOUNT = "ROWSCOUNT";
		
		String STARTDATE2      = "StartDate2";		
	}
    
    private Long    processID;
    private Long    instanceID;
    private Long    reportID;
    private String  userLogin;
    private Date    startDate;
    private Date    endDate;
    private Integer executeStatus;
    private String  reportFile;
    private Long    reportGroupID;
    private String  reportGroupName;
    
    
	public void setProcessID(Long processID) {
		this.processID = processID;
	}
	public Long getProcessID() {
		return processID;
	}
	public void setInstanceID(Long instanceID) {
		this.instanceID = instanceID;
	}
	public Long getInstanceID() {
		return instanceID;
	}
	public void setReportID(Long reportID) {
		this.reportID = reportID;
	}
	public Long getReportID() {
		return reportID;
	}
	public void setUserLogin(String userLogin) {
		this.userLogin = userLogin;
	}
	public String getUserLogin() {
		return userLogin;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setExecuteStatus(Integer executeStatus) {
		this.executeStatus = executeStatus;
	}
	public Integer getExecuteStatus() {
		return executeStatus;
	}
	public void setReportFile(String reportFile) {
		this.reportFile = reportFile;
	}
	public String getReportFile() {
		return reportFile;
	}
	public Long getReportGroupID() {
		return reportGroupID;
	}
	public void setReportGroupID(Long reportGroupID) {
		this.reportGroupID = reportGroupID;
	}
	public String getReportGroupName() {
		return reportGroupName;
	}
	public void setReportGroupName(String reportGroupName) {
		this.reportGroupName = reportGroupName;
	}
    


}
