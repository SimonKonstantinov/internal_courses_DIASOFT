package ru.diasoft.flextera.services.ftfcreportws.report.database.creator;

import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DB_TYPE_BIG_DECIMAL;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DB_TYPE_BOOLEAN;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DB_TYPE_DATE;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DB_TYPE_INTEGER;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DB_TYPE_LONG;
import static ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants.DB_TYPE_STRING;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.column.ColumnAlias;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.column.ColumnAliasesDAO;
import ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataBaseType;
import ru.diasoft.flextera.services.ftfcreportws.utils.KeyWord;
import ru.diasoft.utils.text.StringUtils;

public abstract class TableUpdater {

	private static final String STRING_ZERO = "0";
	private static final String FIRST_COUNTER = "01";
	private static final String DESC = "DESC";
	private static final int MAX_CHAR_COUNT = 28;
	private static final int COLUMN_NAME_INDEX = 4;
	private static final int COLUMN_TYPE_INDEX = 5;
	
	protected Logger logger = Logger.getLogger(TableUpdater.class);
	protected TableColumns columns = null;
	protected Long processID;
	private DataBaseType dataBaseType;
	
	public TableUpdater(Object value, Long processID, ResultSet columnsResultSet, DataBaseType dataBaseType) throws Exception {
		this.columns = createOrModifyTableColumns(value, columnsResultSet);
		this.processID = processID;
		this.dataBaseType = dataBaseType;
	}

	protected abstract List<String> prepareInsertQuery(String schemaName, String tableName, Object parameterValue) throws Exception;
	
	protected abstract TableColumns createOrModifyTableColumns(Object value, ResultSet tableResultSet) throws Exception;

	public void createTable(Connection connection, String schemaName, String tableName, Object parameterValue) throws Exception{
		if(logger.isDebugEnabled()){
			logger.debug("Trying to create new table[table = " + tableName + ", by parameterValue = " + parameterValue + "]");
		}
		
		boolean isOracle = DataBaseType.ORACLE.equals(dataBaseType);
		
		StringBuilder createTableSQLBulder = new StringBuilder("CREATE TABLE ");
		if(isOracle){
			createTableSQLBulder.append(schemaName + ".");
		}
		createTableSQLBulder.append(tableName + "(" + columns.getColumnsForCreateTable() + " )");
		
		StringBuilder createIndexSQLBuilder = new StringBuilder("CREATE INDEX K01_" + tableName + " ON ");
		if(isOracle){
			createIndexSQLBuilder.append(schemaName + ".");
		}
		createIndexSQLBuilder.append(tableName + " (PROCESSID ASC)");
		
		String createTableSQL = createTableSQLBulder.toString().toUpperCase();
		String createIndexSQL = createIndexSQLBuilder.toString().toUpperCase();
			
		if(logger.isDebugEnabled()){
			logger.debug("Create table script = " + createTableSQL);
			logger.debug("Create index script = " + createIndexSQL);
		}

		PreparedStatement tableCreate = connection.prepareStatement(createTableSQL);
		PreparedStatement indexCreate = connection.prepareStatement(createIndexSQL);
		
		tableCreate.executeUpdate();
		indexCreate.executeUpdate();

		if(!connection.getAutoCommit()){
			connection.commit();
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("Table " + tableName + " has created successfully.");
		}
		
	}

	public void modifyTable(Connection connection, String schemaName, String tableName, Object parameterValue) throws SQLException{
		if(logger.isDebugEnabled()){
			logger.debug("Trying to create new table [table = " + tableName + ", by parameterValue = " + parameterValue + "]");
		}
		
		if(columns == null || StringUtils.isEmpty(columns.getColumnsForCreateTable())){
			if(logger.isDebugEnabled()){
				logger.debug("Nothing to update...");
			}
			return; 
		}
		boolean isOracle = DataBaseType.ORACLE.equals(dataBaseType);
		
		StringBuilder alterTableBuilder = new StringBuilder("ALTER TABLE ");
		if(isOracle){
			alterTableBuilder.append(schemaName + ".");
		}
		alterTableBuilder.append(tableName + " ADD ");
		
		if(isOracle){
			alterTableBuilder.append("(");
		}
		alterTableBuilder.append(columns.getColumnsForCreateTable());
		if(isOracle){
			alterTableBuilder.append(")");
		}
		
		String alterTable = alterTableBuilder.toString().toUpperCase();
		
		if(logger.isDebugEnabled()){
			logger.debug("Alter table script = " + alterTable);
		}
		
		PreparedStatement tableCreate = connection.prepareStatement(alterTable);
		
		tableCreate.executeUpdate();
		
		if(!connection.getAutoCommit()){
			connection.commit();
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("Table " + tableName + " has updated successfully.");
		}
		
	}

	public void insertData(Connection connection, String schemaName, String tableName, Object parameterValue) throws Exception {
		List<String> insertQuery = prepareInsertQuery(schemaName, tableName, parameterValue);
		
		if(logger.isDebugEnabled()){
			logger.debug("Insert table script = " + insertQuery);
		}
		
		if(insertQuery.size() > 0){
			Statement insertStatement = connection.createStatement();
			for (String insertRow : insertQuery) {
				insertStatement.addBatch(insertRow);
			}
			
			insertStatement.executeBatch();
			if(!connection.getAutoCommit()){
				connection.commit();
			}
			
			if(logger.isDebugEnabled()){
				logger.debug("Data has loaded successfully into " + tableName);
			}
		} else {
			logger.debug("Nothing to load into " + tableName);
		}
	}
	
	protected String getColumnTypeByObject(Object value) throws SQLException {
		String className = value.getClass().getName();
		String result = null;
		
		if(logger.isDebugEnabled()){
			logger.debug("Java to SQL type mapping: java object class = " + className);
		}
		
		if(className.equals("java.lang.String")){
			result = DB_TYPE_STRING;
		} else if(className.equals("java.lang.Boolean")){
			result = DB_TYPE_BOOLEAN;	
		} else if(className.equals("java.math.BigDecimal")){
			result = DB_TYPE_BIG_DECIMAL;
		} else if(className.equals("java.lang.Byte") || className.equals("java.lang.Short") || className.equals("java.lang.Integer")){ 
			result = DB_TYPE_INTEGER;
		} else if(className.equals("java.lang.Long")){
			result = DB_TYPE_LONG;
		} else if(className.equals("java.util.Date")){
			result = DB_TYPE_DATE;
		} else {
			throw new SQLException("Unsupported type for column creation: " + className);
		}
		
		if(logger.isDebugEnabled()){
			logger.debug("Java to SQL type mapping: SQL type = " + result);
		}
		
		return result;
	}
	
	protected TableColumns createTableColumnsByMap(Map<String, Object> map) throws Exception {
		Map<String, String> columnsMap = new LinkedHashMap<String, String>();
		
		Set<String> columnNameSet = new HashSet<String>(); 
		
		StringBuilder tableColumnsDescription = new StringBuilder();
		
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			String upperCaseKey = key.toUpperCase();
			
			if(upperCaseKey.length() > 30){
				upperCaseKey = decreaseKeyName(upperCaseKey);
			}
			
			if (KeyWord.isReservedWord(upperCaseKey)) {
				upperCaseKey = DatabaseConstants.FCR + upperCaseKey;	
			}
			
			if(value == null || columnNameSet.contains(upperCaseKey) || DatabaseConstants.PROCESSID.equalsIgnoreCase(key)){
				continue;
			}
			
			tableColumnsDescription.append(upperCaseKey);
			tableColumnsDescription.append(" ");
			
			columnNameSet.add(upperCaseKey);
			
			String columnType = getColumnTypeByObject(value);
			tableColumnsDescription.append(columnType);
			tableColumnsDescription.append(DatabaseConstants.NULL_WITH_COMMA);
			
			columnsMap.put(upperCaseKey, columnType);
		}
		
		tableColumnsDescription.append(DatabaseConstants.PROCESSID_COLUMN);
		columnsMap.put(DatabaseConstants.PROCESSID, DatabaseConstants.NUMERIC_19_0);
		
		TableColumns tableColumns = new TableColumns(columnsMap, tableColumnsDescription.toString());
		return tableColumns;
	}
	
	protected TableColumns createTableColumnsByListMap(List<Map<String, Object>> parameterValueList) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("start createTableColumnsByListMap : size = " + parameterValueList.size());
		}
		
		Map<String, String> columnsMap = new LinkedHashMap<String, String>();
		
		Set<String> columnNameSet = new HashSet<String>(); 
		
		StringBuilder tableColumnsDescription = new StringBuilder();

		for (Map<String, Object> map : parameterValueList) {
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				Object value = entry.getValue();
				String upperCaseKey = key.toUpperCase();
				
				if(upperCaseKey.length() > 30){
					upperCaseKey = decreaseKeyName(upperCaseKey);
				}
				
				if (KeyWord.isReservedWord(upperCaseKey)) {
					upperCaseKey = DatabaseConstants.FCR + upperCaseKey;	
				}

				if (value == null || columnNameSet.contains(upperCaseKey) || DatabaseConstants.PROCESSID.equalsIgnoreCase(key)) {
					continue;
				}

				tableColumnsDescription.append(upperCaseKey);
				tableColumnsDescription.append(" ");

				columnNameSet.add(upperCaseKey);

				String columnType = getColumnTypeByObject(value);
				tableColumnsDescription.append(columnType);
				tableColumnsDescription.append(DatabaseConstants.NULL_WITH_COMMA);

				columnsMap.put(upperCaseKey, columnType);
			}
		}
		
		tableColumnsDescription.append(DatabaseConstants.PROCESSID_COLUMN);
		columnsMap.put(DatabaseConstants.PROCESSID, DatabaseConstants.NUMERIC_19_0);
		
		TableColumns tableColumns = new TableColumns(columnsMap, tableColumnsDescription.toString());

		if(logger.isDebugEnabled()){
			logger.debug("end createTableColumnsByListMap");
		}
		
		return tableColumns;
	}
	
	
	protected TableColumns modifyTableColumnsByMap(ResultSet columnsResultSet, Map<String, Object> map) throws Exception {
		Map<String, String> columnsMap = new LinkedHashMap<String, String>();
		
		Set<String> columnNameSet = new HashSet<String>(); 
		StringBuilder tableColumnsDescription = new StringBuilder();
		
		while(columnsResultSet.next()){
			String columnName = columnsResultSet.getString(COLUMN_NAME_INDEX);
			String columnType = columnsResultSet.getString(COLUMN_TYPE_INDEX);
			
			columnNameSet.add(columnName.toUpperCase());
			columnsMap.put(columnName.toUpperCase(), columnType);
		}
		
		boolean isFirst = true;
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String key = entry.getKey();
			String upperCaseKey = key.toUpperCase();
			
			if(upperCaseKey.length() > 30){
				upperCaseKey = decreaseKeyName(upperCaseKey);
			}
			
			if (KeyWord.isReservedWord(upperCaseKey)) {
				upperCaseKey = DatabaseConstants.FCR + upperCaseKey;	
			}			
			
			Object value = entry.getValue();
			if(value == null || columnNameSet.contains(upperCaseKey)){
				continue;
			}
			
			if(!isFirst){
				tableColumnsDescription.append(", ");
			} 
			
			tableColumnsDescription.append(upperCaseKey);
			tableColumnsDescription.append(" ");
			
			columnNameSet.add(upperCaseKey);
			
			String columnType = getColumnTypeByObject(value);
			tableColumnsDescription.append(columnType);
			tableColumnsDescription.append(" ");
			tableColumnsDescription.append(DatabaseConstants.NULL);
			
			columnsMap.put(upperCaseKey, columnType);
			isFirst = false;
		}
		
		if(!columnNameSet.contains(DatabaseConstants.PROCESSID)){
			if(tableColumnsDescription.length() > 0){
				tableColumnsDescription.append(", ");
			}
			
			tableColumnsDescription.append(DatabaseConstants.PROCESSID_COLUMN);
			columnsMap.put(DatabaseConstants.PROCESSID, DatabaseConstants.NUMERIC_19_0);
		}
		
		TableColumns tableColumns = new TableColumns(columnsMap, tableColumnsDescription.toString());
		return tableColumns;
		
	}
	
	protected TableColumns modifyTableColumnsByListMap(ResultSet columnsResultSet, List<Map<String, Object>> parameterValueList) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("start modifyTableColumnsByListMap : size = " + parameterValueList.size());
		}
		
		Map<String, String> columnsMap = new LinkedHashMap<String, String>();
		
		Set<String> columnNameSet = new HashSet<String>(); 
		StringBuilder tableColumnsDescription = new StringBuilder();
		
		while(columnsResultSet.next()){
			String columnName = columnsResultSet.getString(COLUMN_NAME_INDEX);
			String columnType = columnsResultSet.getString(COLUMN_TYPE_INDEX);
			
			columnNameSet.add(columnName.toUpperCase());
			columnsMap.put(columnName.toUpperCase(), columnType);
		}

		boolean isFirst = true;
		for (Map<String, Object> map : parameterValueList) {
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String key = entry.getKey();
				String upperCaseKey = key.toUpperCase();
				
				if(upperCaseKey.length() > 30){
					upperCaseKey = decreaseKeyName(upperCaseKey);
				}
				
				if (KeyWord.isReservedWord(upperCaseKey)) {
					upperCaseKey = DatabaseConstants.FCR + upperCaseKey;	
				}				

				Object value = entry.getValue();
				if (value == null || columnNameSet.contains(upperCaseKey)) {
					continue;
				}

				if (!isFirst) {
					tableColumnsDescription.append(", ");
				}

				tableColumnsDescription.append(upperCaseKey);
				tableColumnsDescription.append(" ");

				columnNameSet.add(upperCaseKey);

				String columnType = getColumnTypeByObject(value);
				tableColumnsDescription.append(columnType);
				tableColumnsDescription.append(" ");
				tableColumnsDescription.append(DatabaseConstants.NULL);

				columnsMap.put(upperCaseKey, columnType);
				isFirst = false;
			}
		}
		
		if(!columnNameSet.contains(DatabaseConstants.PROCESSID)){
			if(tableColumnsDescription.length() > 0){
				tableColumnsDescription.append(", ");
			}
			
			tableColumnsDescription.append(DatabaseConstants.PROCESSID_COLUMN);
			columnsMap.put(DatabaseConstants.PROCESSID, DatabaseConstants.NUMERIC_19_0);
		}
		
		TableColumns tableColumns = new TableColumns(columnsMap, tableColumnsDescription.toString());

		if(logger.isDebugEnabled()){
			logger.debug("end modifyTableColumnsByListMap");
		}
				
		return tableColumns;		
	}
	
	public static String convertParamValueToSQLString(Object paramValue ) {
		String sqlParamValue="";
		if (paramValue == null) {
			sqlParamValue="null";
		} else {
			if (paramValue instanceof Date) {
				Long tmpValue=((Date) paramValue).getTime();
				sqlParamValue=tmpValue.toString();
			} else if (paramValue instanceof String) {
				if(paramValue.toString().length() <= DatabaseConstants.STRING_PRECISION_3500){
					sqlParamValue="'" + paramValue + "'";
				} else {
					sqlParamValue="'" + paramValue.toString().substring(0, DatabaseConstants.STRING_PRECISION_3500) + "'";
				}
				
			} else if (paramValue instanceof Boolean) {
				sqlParamValue="'" + paramValue + "'";
			} else if (paramValue instanceof BigDecimal) {
				BigDecimal tempValue = new BigDecimal(paramValue.toString(), new MathContext(38, RoundingMode.DOWN));
				tempValue = tempValue.setScale(10, RoundingMode.DOWN);
				sqlParamValue=tempValue.toString();
			} else {
				sqlParamValue=paramValue.toString();
			}
		}
		return sqlParamValue;
	}

	protected void createInsertStringByMap(String schemaName, String tableName, List<String> result, Map<String, Object> parametersMap) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Process map " + parametersMap);
		}
		
		boolean isOracle = DataBaseType.ORACLE.equals(dataBaseType);
		
		StringBuilder insertQuery = new StringBuilder();
		insertQuery.append("INSERT INTO " + (isOracle ? schemaName + "." : "") + tableName.toUpperCase() + "(" + columns.getColumnNamesForInsertQuery().toUpperCase()
				+ ") VALUES (");

		Map<String, Object> covertedMap = convertKeysToUpperCase(parametersMap);
		
		Set<Map.Entry<String, String>> entrySet = columns.getColumnsMap().entrySet();
		int counter = 1;
		for (Map.Entry<String, String> entry : entrySet) {
			String columnName = entry.getKey();
			Object currentValue = covertedMap.get(columnName);
			
			if (!columnName.equalsIgnoreCase(DatabaseConstants.PROCESSID)) {
				String sqlParamValue= convertParamValueToSQLString(currentValue);
				insertQuery.append(sqlParamValue);
			} else {
				insertQuery.append(processID);
			}
			
			if(counter++ < entrySet.size()){
				insertQuery.append(", ");
			}

		}
			
		insertQuery.append(")");
		result.add(insertQuery.toString());
	}

	private Map<String, Object> convertKeysToUpperCase(Map<String, Object> parametersMap) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		for (Map.Entry<String, Object> entry : parametersMap.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			
			
			//TODO:!!! переделать на кэш, чтобы не лазить все время в БД !!!
			if(key.length() > 30){
				ColumnAlias columnAlias = new ColumnAlias();
				columnAlias.setParameterName(key.toUpperCase());
				List<ColumnAlias> aliases = ColumnAliasesDAO.getInstance().getColumnAliasByParams(columnAlias);
				key = aliases.get(0).getColumnName();
			}
			
			// Зарезервированные слова СУБД
			if (KeyWord.isReservedWord(key)) {
				key = DatabaseConstants.FCR + key;	
			}			
			
			resultMap.put(key.toUpperCase(), value);
		}
		
		return resultMap;
	}

	private String decreaseKeyName(String upperCaseKey) throws Exception {
		ColumnAlias columnAlias = new ColumnAlias();
		columnAlias.setParameterName(upperCaseKey);
		List<ColumnAlias> aliasesList = ColumnAliasesDAO.getInstance().getColumnAliasByParams(columnAlias);
		
		String decreasedKey = null;
		
		
		if(aliasesList.size() > 0){
			decreasedKey = aliasesList.get(0).getColumnName();
		} else {
			
			decreasedKey = upperCaseKey.substring(0, MAX_CHAR_COUNT);
			
			columnAlias = new ColumnAlias();
			columnAlias.setColumnName(decreasedKey + "%");
			columnAlias.setOrderBy(ColumnAlias.Fields.COLUMN_NAME + " " + DESC);
			
			aliasesList = ColumnAliasesDAO.getInstance().getColumnAliasByParams(columnAlias);
			if(aliasesList.size() == 0){
				decreasedKey = decreasedKey + FIRST_COUNTER;
			} else {
				String counter = aliasesList.get(0).getColumnName().substring(MAX_CHAR_COUNT);
				Integer newCounter = Integer.valueOf(counter) + 1;
				
				decreasedKey = decreasedKey + (newCounter < 10 ? STRING_ZERO + newCounter : newCounter);
			}
			createNewAlias(upperCaseKey, decreasedKey);
		}
		
		return decreasedKey;
	}

	private void createNewAlias(String upperCaseKey, String decreasedKey) throws Exception {
		ColumnAlias columnAlias;
		columnAlias = new ColumnAlias();
		columnAlias.setColumnName(decreasedKey);
		columnAlias.setParameterName(upperCaseKey);
		ColumnAliasesDAO.getInstance().createColumnAlias(columnAlias);
	}

	
}