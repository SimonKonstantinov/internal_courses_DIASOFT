package ru.diasoft.flextera.services.ftfcreportws.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

import ru.diasoft.utils.XMLUtil;

/**
 * @author dkondratiev
 *
 */
public class MapUtils {
	
	/**
	 * Количество знаков после запятой для BigDecimal. Остальные будут откинуты. 
	 * Сделано что бы залатать проблему при чтении данных из БД - 
	 * т.к. СУБД хранит их как double и далеко после запятой вылазят призрначнеы циферки
	 */
	public static final int BIGDECIMALSCALE = 4;
	public static final BigDecimal ZERO_BIGDECIMAL = (new BigDecimal(0)).setScale(4, RoundingMode.DOWN);
	public static final Long ZERO_LONG = Long.valueOf(0);
	public static final String EMPTYSTRING = "";
	public static final String WHITESPACE = "_";
	private static final Integer FALSE_INT = Integer.valueOf(0);
    private static final Integer TRUE_INT = Integer.valueOf(1);
	public static final Integer ZERO_INTEGER = Integer.valueOf(0);
	public static final Integer ONE_INTEGER = Integer.valueOf(1);
	
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getResult(Map<String, Object> map) {
		Object result = map.get("Result"); 
		if (result != null && result instanceof Map) {
			return (Map<String, Object>)map.get("Result");				
		}
		else {
			return map;
		}
	}

    @SuppressWarnings("unchecked")
	public static List<Map<String, Object>> asList(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (!(value instanceof List)) {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), List.class);
        }
        return (List<Map<String, Object>>) value;
    }
    
    @SuppressWarnings("unchecked")
	public static List<Map<String, Object>> asList(Map<String, Object> map, String name, List<Map<String, Object>> defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (!(value instanceof List)) {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), List.class);
        }
        return (List<Map<String, Object>>) value;
    }
    
	@SuppressWarnings("unchecked")
	public static Map<String, Object> asMap(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (!(value instanceof Map)) {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Map.class);
        }
        return (Map<String, Object>) value;
    }
    
    @SuppressWarnings("unchecked")
	public static Map<String, Object> asMap(Map<String, Object> map, String name, Map<String, Object> defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (!(value instanceof Map)) {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Map.class);
        }
        return (Map<String, Object>) value;
    }
    

    public static Date asDate(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (value instanceof Date) {
        	return (Date) value;
        } else if (value instanceof Float) {
        	return XMLUtil.convertDate(((Float)value).doubleValue());        	
        } else if (value instanceof Double) {
        	return XMLUtil.convertDate(((Double)value).doubleValue());        	
        } else if (value instanceof BigDecimal) {
        	return XMLUtil.convertDate((BigDecimal)value);
        } else if (value instanceof Long) {
        	return new Date(((Long)value).longValue());
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Date.class, Float.class, Double.class, BigDecimal.class, Long.class);
        }
    }
    
    public static Date asDate(Map<String, Object> map, String name, Date defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (value instanceof Date) {
        	return (Date) value;
        } else if (value instanceof Float) {
        	return XMLUtil.convertDate(((Float)value).doubleValue());        	
        } else if (value instanceof Double) {
        	return XMLUtil.convertDate(((Double)value).doubleValue());        	
        } else if (value instanceof BigDecimal) {
        	return XMLUtil.convertDate((BigDecimal)value);
        } else if (value instanceof Long) {
        	return new Date(((Long)value).longValue());
        } else {        
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Date.class, Float.class, Double.class, BigDecimal.class, Long.class);
        }
        
    }

    public static String asString(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException {
    	Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (value instanceof String) {
            return ((String) value).trim();
        } else {
            return value.toString();
        }         
    }
    
    public static String asString(Map<String, Object> map, String name, String defaultValue) {
    	Object value = map.get(name); 
        if (value == null) {
        	return defaultValue;
        } else if (value instanceof String) {
            return ((String) value).trim();
        } else {
            return value.toString();
        }
    }

    public static Double asDouble(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (value instanceof Double) {
            return (Double) value;
        } else if (value instanceof Number) {
            return ((Number) value).doubleValue();
        } else if (value instanceof String) {
            return Double.parseDouble((String)value);
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Double.class, Number.class, String.class);
        }
    }
    
    public static Double asDouble(Map<String, Object> map, String name, Double defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (value instanceof Double) {
            return (Double) value;
        } else if (value instanceof Number) {
            return ((Number) value).doubleValue();
        } else if (value instanceof String) {
        	if(value.toString().trim().length() == 0){
            	return defaultValue;
        	}else{
                return Double.parseDouble((String)value);
        	}
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Double.class, Number.class, String.class);
        }
    }

    public static BigDecimal asBigDecimal(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).setScale(BIGDECIMALSCALE, RoundingMode.DOWN);
        } else if (value instanceof Number) {
            return (new BigDecimal(Double.parseDouble(value.toString()))).setScale(4, RoundingMode.DOWN);
        } else if (value instanceof String) {
            return (new BigDecimal(Double.parseDouble((String)value))).setScale(4, RoundingMode.DOWN);
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), BigDecimal.class, Number.class, String.class);
        }
    }
    
    public static BigDecimal asBigDecimal(Map<String, Object> map, String name, BigDecimal defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).setScale(BIGDECIMALSCALE, RoundingMode.DOWN);
        } else if (value instanceof Number) {
            return (new BigDecimal(Double.parseDouble(value.toString()))).setScale(4, RoundingMode.DOWN);
        } else if (value instanceof String) {
        	if(value.toString().trim().length() == 0){
            	return defaultValue;
        	}else{
                return (new BigDecimal(Double.parseDouble((String)value))).setScale(4, RoundingMode.DOWN);
        	}
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), BigDecimal.class, Number.class, String.class);
        }
    }
    
    public static Long asLong(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (value instanceof Long) {
            return (Long) value;
        } else if (value instanceof Number) {
            return ((Number) value).longValue();
        } else if (value instanceof String) {
            return Long.parseLong((String) value);
        } else if (value instanceof Date) {
        	return ((Date) value).getTime();
     	}else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Long.class, Number.class, String.class);
        }
    }
    
    public static Long asLong(Map<String, Object> map, String name, Long defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (value instanceof Long) {
            return (Long) value;
        } else if (value instanceof Number) {
            return ((Number) value).longValue();
        } else if (value instanceof String) {
        	if(value.toString().trim().length() == 0){
            	return defaultValue;
        	}else{
                return Long.parseLong((String) value);
        	}
        } else if (value instanceof Date) {
        	return ((Date) value).getTime();
     	} else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Long.class, Number.class, String.class, Date.class);
        }
    }
    
    public static Integer asInteger(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (value instanceof Integer) {
            return (Integer) value;
        } else if (value instanceof Number) {
            return ((Number) value).intValue();
        } else if (value instanceof Boolean) {
        	return (Boolean)value?TRUE_INT:FALSE_INT;
        } else if (value instanceof String) {
            return Integer.parseInt((String) value);
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Integer.class, Number.class, Boolean.class, String.class);
        }
    }
    
    public static Integer asInteger(Map<String, Object> map, String name, Integer defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (value instanceof Integer) {
            return (Integer) value;
        } else if (value instanceof Number) {
            return ((Number) value).intValue();
        } else if (value instanceof Boolean) {
        	return (Boolean)value?TRUE_INT:FALSE_INT;
        } else if (value instanceof String) {
        	if(value.toString().trim().length() == 0){
            	return defaultValue;
        	}else{
        		return Integer.parseInt((String) value);
        	}
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Integer.class, Number.class, Boolean.class, String.class);
        }
    }

    public static Boolean asBoolean(Map<String, Object> map, String name) throws MapUtilsParamNotFoundException, MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
            throw new MapUtilsParamNotFoundException(name, map);
        } else if (value instanceof Boolean) {
            return (Boolean) value;
        } else if (value instanceof Number) {
            return ((Number) value).longValue() == 0L ?  Boolean.FALSE : Boolean.TRUE;
        } else if (value instanceof String) {
            return Boolean.parseBoolean((String) value);
        } else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Number.class, Boolean.class, String.class);
        }
    }
    
    public static Boolean asBoolean(Map<String, Object> map, String name, Boolean defaultValue) throws MapUtilsParamIllegalTypeException {
        Object value = map.get(name);
        if (value == null) {
        	return defaultValue;
        } else if (value instanceof Boolean) {
            return (Boolean) value;
        } else if (value instanceof Number) {
            return ((Number) value).longValue() == 0L ?  Boolean.FALSE : Boolean.TRUE;
        } else if (value instanceof String) {
        	if(value.toString().trim().length() == 0){
            	return defaultValue;
        	}else{
        		return Boolean.parseBoolean((String) value);
        	}
        }  else {
            throw new MapUtilsParamIllegalTypeException(name, map, value.getClass(), Number.class, Boolean.class, String.class);
        }
    }
    
    

}
