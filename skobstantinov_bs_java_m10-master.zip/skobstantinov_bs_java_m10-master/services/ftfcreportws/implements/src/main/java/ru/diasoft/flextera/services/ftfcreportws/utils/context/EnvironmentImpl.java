package ru.diasoft.flextera.services.ftfcreportws.utils.context;

import java.util.Locale;

import ru.diasoft.core.application.command.CommandContext;
import ru.diasoft.utils.XMLUtil;
import ru.diasoft.utils.text.StringUtils;

public class EnvironmentImpl implements Environment{

    private final String principal;

    private final String password;

    private final Locale locale;
    
    private final XMLUtil xmlUtil;
    
    private final CommandContext commandContext;


    public EnvironmentImpl(CommandContext commandContext) {
        this.principal = commandContext.getLogin();
        this.password = commandContext.getPassword();
        this.commandContext = commandContext;
        this.xmlUtil = commandContext.getXmlUtil();
        
        String currentLocale = commandContext.getLocale();
        this.locale = currentLocale != null ? new Locale(currentLocale) : new Locale(System.getProperty("user.language"));
        
    }

	@Override
    public String getLogin() {
        if (StringUtils.isEmpty(principal)) {
            return "admin";
        }
        return principal;
    }

	@Override
    public String getPassword() {
        if (StringUtils.isEmpty(password)) {
            return "7c222fb2927d828af22f592134e8932480637c0d";
        }
        return password;
    }
    
	@Override
    public Locale getLocale() {
        return locale;
    }

	@Override
	public XMLUtil getXmlUtil() {
		return xmlUtil;
	}

	@Override
	public CommandContext getCommandContext() {
		return commandContext;
	}

    
}
