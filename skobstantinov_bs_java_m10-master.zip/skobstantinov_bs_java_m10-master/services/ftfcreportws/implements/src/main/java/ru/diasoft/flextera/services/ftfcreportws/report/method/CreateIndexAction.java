package ru.diasoft.flextera.services.ftfcreportws.report.method;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;
import ru.diasoft.flextera.services.ftfcreportws.report.database.DataLoader;

public class CreateIndexAction extends APIAction implements Serializable {

	private static final long serialVersionUID = 3789796219334873438L;
	private Logger logger = Logger.getLogger(CreateIndexAction.class);

	private String tableName;
	
	private String indexName;
	
	private List<String> columnNameList;
	
	private Long processID;
	
	public static interface Constanst {
		String TABLE_NAME = "tableName";
		String INDEX_NAME = "indexName";
		String COLUMN_ELEMENT = "./column";
		String NAME = "name";
		
	}
	
	public CreateIndexAction(String tableName, String indexName, List<String> columnNameList, Long processID) {
		super();
		this.tableName = tableName;
		this.indexName = indexName;
		this.columnNameList = columnNameList;
		this.processID = processID;
	}

	@Override
	public void execute(Map<String, Object> inputParams) throws Exception {
		String expression = "CREATE INDEX " + indexName + " ON " + tableName + "(" + columnNameList + ")";
		
		if(logger.isDebugEnabled()){
			logger.debug("execute createIndex action: " + expression);
		}	
		
		try {
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL, APIActionType.CREATEINDEX.name(), expression);
			DataLoader.getInstance().createIndexIfNeeded(tableName, indexName, columnNameList, processID);
			
		} catch (Exception e) {
			String errorMessage = "create index error";
			logger.error(errorMessage, e);
			
			// Протокол "Ошибка построения индекса"
			ProtocolDAO.getInstance().addReportProtocol(getProcessID(), ProtocolMessage.ACTION_CALL_ERROR, APIActionType.CREATEINDEX.name(), expression, e.getMessage());			
			
			throw new Exception(e);
		}
		
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getIndexName() {
		return indexName;
	}

	public void setIndexName(String indexName) {
		this.indexName = indexName;
	}

	public List<String> getColumnNameList() {
		return columnNameList;
	}

	public void setColumnNameList(List<String> columnNameList) {
		this.columnNameList = columnNameList;
	}

	public Long getProcessID() {
		return processID;
	}

	public void setProcessID(Long processID) {
		this.processID = processID;
	}

	@Override
	public String toString() {
		return "CreateIndexAction [tableName=" + tableName + ", indexName=" + indexName + ", columnNameList=" + columnNameList
				+ ", processID=" + processID + "]";
	}
	
}
