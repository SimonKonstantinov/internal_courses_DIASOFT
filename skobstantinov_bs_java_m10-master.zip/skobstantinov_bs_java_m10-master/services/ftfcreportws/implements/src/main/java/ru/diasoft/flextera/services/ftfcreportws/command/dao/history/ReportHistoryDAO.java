package ru.diasoft.flextera.services.ftfcreportws.command.dao.history;

import java.sql.BatchUpdateException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cayenne.QueryResponse;
import org.apache.cayenne.map.Attribute;
import org.apache.cayenne.query.DeleteBatchQuery;
import org.apache.cayenne.query.QueryChain;
import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportException;
import ru.diasoft.flextera.services.ftfcreportws.type.TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam;
import ru.diasoft.flextera.services.ftfcreportws.type.TInstanceIDListTypeForDSFCReportMassDeleteInstance;
import ru.diasoft.flextera.services.ftfcreportws.type.TNotificationListTypeForDSFCReportMassDeleteInstance;
import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportBrowseListInstanceByParamReq;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.ExecuteStatus;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.context.EnvironmentHolder;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.ExternalService;
import ru.diasoft.utils.text.StringUtils;

public class ReportHistoryDAO {
	private Logger logger = Logger.getLogger(ReportHistoryDAO.class);
	public static final int BATCH_SIZE_MASSDELETE = 1000;
	
	public static ReportHistoryDAO getInstance(){
		return new ReportHistoryDAO();
	}

	private ReportHistoryDAO(){
	}
	
	public Long create(ReportHistory history) {
		Long reportHistoryID = 0L;
		try {
			reportHistoryID = ExternalService.getInstance().getNewId(ReportHistoryDBEntity.TABLENAME);
				
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(ReportHistory.Fields.INSTANCEID, reportHistoryID);
			params.put(ReportHistory.Fields.PROCESSID, reportHistoryID);
			params.put(ReportHistory.Fields.REPORTID, history.getReportID());
			params.put(ReportHistory.Fields.USERLOGIN, history.getUserLogin());
			params.put(ReportHistory.Fields.STARTDATE, history.getStartDate().getTime());
			params.put(ReportHistory.Fields.EXECUTESTATUS, history.getExecuteStatus());
		
			List<Map<String, Object>> resultList = DataUtils.performQuery("reportHistoryCreate", params);

			if(resultList.size() > 0){
				if(logger.isDebugEnabled()){
					logger.debug("ReportHistoryDAO.create resultList = " + resultList);
				}	
			}
		}
		catch (Exception e) {
			// SQL ошибки и прочее
			if(logger.isDebugEnabled()){
				logger.error("error ReportHistoryDAO.create " + e.getMessage(), e);
			}	
			reportHistoryID = 0L;
		}
		
		return reportHistoryID;
	}

	public Long modify(ReportHistory history) {
		Long retVal = 0L;
		try {							
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(ReportHistory.Fields.INSTANCEID, history.getInstanceID());
			params.put(ReportHistory.Fields.REPORTID, history.getReportID());
			params.put(ReportHistory.Fields.PROCESSID, history.getProcessID());
			params.put(ReportHistory.Fields.USERLOGIN, history.getUserLogin());
			if (history.getEndDate() != null) {
				params.put(ReportHistory.Fields.ENDDATE, history.getEndDate().getTime());
			}	
			if (history.getExecuteStatus() != null) {
				params.put(ReportHistory.Fields.EXECUTESTATUS, history.getExecuteStatus());
			}	
			params.put(ReportHistory.Fields.REPORTFILENAME, history.getReportFile());			
		
			List<Map<String, Object>> resultList = DataUtils.performQuery("reportHistoryModify", params);

			if(resultList.size() > 0){
				if(logger.isDebugEnabled()){
					logger.debug("ReportHistoryDAO.create resultList = " + resultList);
				}	
			}
		}
		catch (Exception e) {
			// SQL ошибки и прочее
			if(logger.isDebugEnabled()){
				logger.error("error ReportHistoryDAO.modify " + e.getMessage(), e);
			}	
			retVal = Long.valueOf(1L); 
		}
		
		return retVal;
	}

	public Long createReportHistory(Long reportID) {
		Long instanseID = 0L;
		Date startDate = new Date();
		ReportHistory history = new ReportHistory();
		// Отчет
		history.setReportID(reportID);
		// Текущий пользователь
		history.setUserLogin(EnvironmentHolder.currentContext().getLogin());
		// Текущая дата и время
		history.setStartDate(startDate);
		// Статус формирования отчета - формируется
		history.setExecuteStatus(ExecuteStatus.IN_PROCESS.getStateCode());
		
		instanseID = create(history);

		return instanseID;
	}
	
	public Long modifyReportHistory(Long reportHistoryID, Date endDate, Integer executeStatus, String reportOutFileName) {
		Long retVal = 0L;
		
		ReportHistory history = new ReportHistory();
		// HistoryID
		history.setInstanceID(reportHistoryID);
		// Дата окончания формирования отчета
		history.setEndDate(endDate);
		// Статус формирования отчета - формируется
		history.setExecuteStatus(executeStatus);
		// Наименование сформирвоанного файла отчета
		history.setReportFile(reportOutFileName);
		
		retVal = modify(history);

		return retVal;
	}	
	
	public ReportHistoryBrowseListResult getListByParams(DsFCReportBrowseListInstanceByParamReq request) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		request.toMap(params);

		String reportSysname = request.getFCReportSysName();
		if(!StringUtils.isEmpty(reportSysname)){
			params.put(ReportHistory.Fields.REPORTSYSNAME, reportSysname + "%");	
		}
		
		String reportName = request.getFCReportName();
		if(!StringUtils.isEmpty(reportName)){
			params.put(ReportHistory.Fields.REPORTNAME, reportName + "%");	
		}		
		
		String userLogin = request.getUserLogin();
		if(!StringUtils.isEmpty(userLogin)){
			params.put(ReportHistory.Fields.USERLOGIN, userLogin + "%");	
		}
		
		Date startDate = request.getStartDate();		
		if (startDate != null) {
			startDate = getStartOfDay(startDate);			
			params.put(ReportHistory.Fields.STARTDATE, startDate.getTime());
			
			Date startDate2 = getEndOfDay(startDate);			
			params.put(ReportHistory.Fields.STARTDATE2, startDate2.getTime());			
		}
		
		// По умолчанию номер страницы = 1
		if (request.getPAGE() == null ) {
			params.put(ReportHistory.Fields.PAGE, 0);
		}	
		
		// По умолчанию число записей на страницу = 10
		if (request.getROWSCOUNT() == null) {
			params.put(ReportHistory.Fields.ROWSCOUNT, 10);
		}
		
		// По умолчанию сортировка по первому полю выходного набора
		if (request.getORDERBY() == null) {
			params.put(ReportHistory.Fields.ORDERBY, "ProcessID DESC");
		}		
		
		if(logger.isDebugEnabled()){			
			logger.debug("ReportHistoryDAO.getListByParams" + " params = " + params.toString());
		}		
		
		Map<String, Object> resultMap = DataUtils.getList("reportHistoryGetListByParamsCount", "reportHistoryGetListByParams", params); 
		List<Map<String, Object>> resultList = DataUtils.getListFromResultMap(resultMap);
		
		ReportHistoryBrowseListResult reportHistoryBrowse = new ReportHistoryBrowseListResult();
		
		List<TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam> reportResultList = new ArrayList<TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam>();
		for (Map<String, Object> reportRow : resultList) {
			TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam param = new TInstanceBrowseListTypeTypeForDSFCReportBrowseListInstanceByParam();
			param.setProcessID(MapUtils.asLong(reportRow, ReportHistory.Fields.INSTANCEID, null));
			param.setInstanceID(MapUtils.asLong(reportRow, ReportHistory.Fields.INSTANCEID, null));
			param.setFCReportID(MapUtils.asLong(reportRow, ReportHistory.Fields.REPORTID, null));
			param.setFCReportName(MapUtils.asString(reportRow, ReportHistory.Fields.REPORTNAME, null));
			param.setFCReportSysName(MapUtils.asString(reportRow, ReportHistory.Fields.REPORTSYSNAME, null));
			param.setUserLogin(MapUtils.asString(reportRow, ReportHistory.Fields.USERLOGIN, null));
			param.setStartDate(MapUtils.asDate(reportRow, ReportHistory.Fields.STARTDATE, null));
			param.setEndDate(MapUtils.asDate(reportRow, ReportHistory.Fields.ENDDATE, null));			
			param.setExecuteStatus(MapUtils.asInteger(reportRow, ReportHistory.Fields.EXECUTESTATUS, null));
			param.setFCReportFileName(MapUtils.asString(reportRow, ReportHistory.Fields.REPORTFILENAME, null));
			param.setFCReportGroupID(MapUtils.asLong(reportRow, ReportHistory.Fields.REPORTGROUPID, null));
			param.setFCReportGroupName(MapUtils.asString(reportRow, ReportHistory.Fields.REPORTGROUPNAME, null));
			
			reportResultList.add(param);
		}

		reportHistoryBrowse.setResultList(reportResultList);
		reportHistoryBrowse.setTotalCount(MapUtils.asInteger(resultMap, DataUtils.TOTALCOUNT, null));
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ReportHistoryDAO.getListByParams" + " ResultList = " + reportResultList.toString());
		}		
		return reportHistoryBrowse;
	}
	
	private Date getStartOfDay(Date date) {
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    int year = calendar.get(Calendar.YEAR);
	    int month = calendar.get(Calendar.MONTH);
	    int day = calendar.get(Calendar.DATE);
	    calendar.set(year, month, day, 0, 0, 0);
	    return calendar.getTime();
	}
	
	private Date getEndOfDay(Date date) {
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    int year = calendar.get(Calendar.YEAR);
	    int month = calendar.get(Calendar.MONTH);
	    int day = calendar.get(Calendar.DATE);
	    calendar.set(year, month, day, 23, 59, 59);
	    return calendar.getTime();
	}

    public Boolean checkUpdateCounts(int[] updateCounts) {
    	Boolean bSuccess = true;    	
    	
        for (int i=0; i < updateCounts.length; i++) {
            if (updateCounts[i] >= 0) {
            	if(logger.isInfoEnabled()){
            		logger.info("Successfully executed [" + i + "]: number of affected rows: " + updateCounts[i]);
            	}
            } else if (updateCounts[i] == Statement.SUCCESS_NO_INFO) {
            	if(logger.isInfoEnabled()){
            		logger.info("Successfully executed [" + i + "] : number of affected rows not available: " + updateCounts[i]);
            	}
            } else if (updateCounts[i] == Statement.EXECUTE_FAILED) {
            	bSuccess = false;
            	if(logger.isDebugEnabled()){
            		logger.debug("Failed to execute [" + i + "] : " + updateCounts[i]);
            	}
            }
            if (bSuccess == false) { 
            	break;       
            }	
        }
    	return bSuccess;
    }	
	
	public ReportHistoryMassDeleteResult massDelete(List<TInstanceIDListTypeForDSFCReportMassDeleteInstance> instanceIDList) throws Exception{
		if(logger.isDebugEnabled()){			
			logger.debug("ReportHistoryDAO.massDelete start");
		}

		ReportHistoryMassDeleteResult result = new ReportHistoryMassDeleteResult();
		
		// Формируем список параметров для массового удаления
		List<Attribute> idAttributes = Collections.singletonList(ReportHistoryDBEntity.getDbEntity().getAttribute("REPORTHISTORYID"));
		DeleteBatchQuery deleteBatchQuery = new DeleteBatchQuery(ReportHistoryDBEntity.getDbEntity(), idAttributes, null, instanceIDList.size());
		//DeleteBatchQuery deleteBatchQuery = new DeleteBatchQuery(ReportHistoryDBEntity.getDbEntity(), instanceIDList.size());

		// Исходящий набор NotificationList
		List<TNotificationListTypeForDSFCReportMassDeleteInstance> notificationList = new ArrayList<TNotificationListTypeForDSFCReportMassDeleteInstance>();

		try {
			for (TInstanceIDListTypeForDSFCReportMassDeleteInstance deleteRow: instanceIDList) {
				Map<String, Object> queryParams = new HashMap<String, Object>();
				queryParams.put(ReportHistoryDBEntity.Field.REPORTHISTORYID, deleteRow.getInstanceID());
				
				deleteBatchQuery.add(queryParams);
				
			} 
				
			QueryChain deleteQueryChain = new QueryChain();
			deleteQueryChain.addQuery(deleteBatchQuery);
			
			// MASS DELETE			
			try {
				QueryResponse queryRes = DataUtils.performGenericQuery(deleteQueryChain);
                
				 for (queryRes.reset(); queryRes.next();) {
				     if (!queryRes.isList()) {
				         int[] updateCounts = queryRes.currentUpdateCount();				         
				         checkUpdateCounts(updateCounts);				    	 
				     }
				 }				
				
			}
			catch (BatchUpdateException e) {
				// Не все успешно выполнено
				int[] updateCounts = e.getUpdateCounts();
				checkUpdateCounts(updateCounts);
				logger.error("ReportHistoryDAO.massDelete Not all of the statements were successfully executed. Delete records from a table FCR_REPORTHISTORY " + e.getMessage(), e);
				throw new Exception("Not all of the statements were successfully executed. Delete records from a table FCR_REPORTHISTORY " + e.getMessage());
				
			}
			catch (Exception e) {								
				logger.error("ReportHistoryDAO.massDelete Failed to delete records from a table FCR_REPORTHISTORY " + e.getMessage(), e);
				throw new Exception("Failed to delete records from a table FCR_REPORTHISTORY " + e.getMessage());
			}

			result.setReportHistoryNtfList(notificationList);
			if (notificationList.size() > 0) {				
				throw new ReportException(notificationList.get(0).getNTFID(), notificationList.get(0).getNTFMessage());				
			}
			
		} catch (ReportException e) {			
			result.setReturnCode(e.getReturnCode());
			result.setReturnMsg(e.getReturnMessage());	
		} 		
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ReportHistoryDAO.massDelete" + " result = " + result.toString());
		}		
		
		return result;
	}
		

}
