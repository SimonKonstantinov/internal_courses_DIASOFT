package ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.type.TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam;
import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportBrowseListProtocolByParamReq;
import ru.diasoft.flextera.services.ftfcreportws.utils.DataUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.ExternalService;

public class ProtocolDAO {
	private Logger logger = Logger.getLogger(ProtocolDAO.class);
	
	public static ProtocolDAO getInstance() {
		return new ProtocolDAO();
	}
	
	private ProtocolDAO(){
	}
	
	private Long create(Protocol protocol) {
		Long reportProtocolID = 0L;
		try {
			reportProtocolID = ExternalService.getInstance().getNewId("FCR_Protocol");
				
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(Protocol.Fields.PROTOCOLMESSAGEID, reportProtocolID);			
			params.put(Protocol.Fields.PROTOCOLMESSAGETEXT, protocol.getMessageText());
			params.put(Protocol.Fields.PROTOCOLMESSAGETYPE, 0L); // not null
			params.put(Protocol.Fields.INSTANCEID, protocol.getInstanseID());
		
			DataUtils.performQuery("protocolCreate", params);
		}
		catch (Exception e) {
			// SQL ошибки и прочее
			if(logger.isDebugEnabled()){
				logger.error("error ProtocolDAO.create " + e.getMessage(), e);
			}	
			reportProtocolID = 0L;
		}		
		return reportProtocolID;
	}
	
	private Long createReportProtocol(Long reportHistoryID, String protocolMessage) {
		Long protocolID = 0L;
		Protocol protocol = new Protocol();
		// HistoryID
		protocol.setInstanseID(reportHistoryID);
		// Текст протокола
		protocol.setMessageText(protocolMessage);
		
		protocolID = create(protocol);
		
		return protocolID;
	}
	
	public Long createReportProtocol(Long reportHistoryID, ProtocolMessage protocolMessage, Object ... args) {
		Long protocolID = 0L;
		protocolID = createReportProtocol(reportHistoryID, protocolMessage.getMessage(args));
		return protocolID;
	}	
	
	private Long modify(Protocol protocol) {
		Long retVal = 0L;
		try {							
			// TODO реализовать изменение протокола в отдельной транзакции
			// убрать двойной запрос SELECT + UPDATE, необходимо хранить текст протокола в памяти и не читать из базы 

			Long   instanceID = protocol.getInstanseID();
			String messageText = "";
			
			if (instanceID > 0L) {
				// Текущий текст протокола
				messageText = getByInstanceID(instanceID);
				messageText = messageText + "\n\n" + protocol.getMessageText();
			
				Map<String, Object> params = new HashMap<String, Object>();			
				params.put(Protocol.Fields.INSTANCEID, instanceID);			
				params.put(Protocol.Fields.PROTOCOLMESSAGETEXT, messageText);

				DataUtils.performQuery("protocolModify", params);
			}
			else {
				retVal = Long.valueOf(1L);
			}	

		}
		catch (Exception e) {
			// SQL ошибки и прочее
			if(logger.isDebugEnabled()){
				logger.error("error ProtocolDAO.modify " + e.getMessage(), e);
			}	
			retVal = Long.valueOf(1L);
		}
		
		return retVal;
	}
	
	private Long modifyReportProtocol(Long reportHistoryID, String protocolMessage) {
		Long retVal = 0L;
		
		Protocol protocol = new Protocol();
		// HistoryID
		protocol.setInstanseID(reportHistoryID);
		// Текст протокола
		protocol.setMessageText(protocolMessage);
		
		retVal = modify(protocol);		

		return retVal;
	}
	
	public Long addReportProtocol(Long reportHistoryID, ProtocolMessage protocolMessage, Object ... args) {
		Long res = 0L;
		res = modifyReportProtocol(reportHistoryID, protocolMessage.getMessage(args));		
		return res;
	}	
	
	public String getByInstanceID(Long instanceID) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put(Protocol.Fields.INSTANCEID, instanceID);
		
		if(logger.isDebugEnabled()){
			logger.debug("ProtocolDAO.getByInstanceID instanceID = " + Long.toString(instanceID));
		}		
		
		List<Map<String, Object>> resultList = DataUtils.performQuery("protocolGetByInstanceId", params);
		
		String messageText = "";		
		
		if(resultList.size() > 0) {
			messageText = MapUtils.asString(resultList.get(0), Protocol.Fields.PROTOCOLMESSAGETEXT, null);			
		}		
		
		return messageText;
	}
	
	
	public ProtocolBrowseListResult getListByParams(DsFCReportBrowseListProtocolByParamReq request) throws Exception {
		Map<String, Object> params = new HashMap<String, Object>();
		request.toMap(params);
		
		// По умолчанию номер страницы = 1
		if (request.getPAGE() == null ) {
			params.put(Protocol.Fields.PAGE, 0);
		}	
		
		// По умолчанию число записей на страницу = 10
		if (request.getROWSCOUNT() == null) {
			params.put(Protocol.Fields.ROWSCOUNT, 10);
		}	
		
		if (request.getLastProtocolMessageID() != null) {
			params.put(Protocol.Fields.PROTOCOLMESSAGEID, request.getLastProtocolMessageID());
		}	
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ProtocolDAO.getListByParams" + " params = " + params.toString());
		}		
		
		Map<String, Object> resultMap = DataUtils.getList("protocolGetListByParamsCount", "protocolGetListByParams", params); 
		List<Map<String, Object>> resultList = DataUtils.getListFromResultMap(resultMap);
		
		ProtocolBrowseListResult protocolBrowse = new ProtocolBrowseListResult();
		
		List<TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam> protocolResultList = new ArrayList<TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam>();
		for (Map<String, Object> reportRow : resultList) {
			TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam param = new TProtocolBrowseListTypeForDSFCReportBrowseListProtocolByParam();
			param.setProtocolMessageID(MapUtils.asLong(reportRow, Protocol.Fields.PROTOCOLMESSAGEID, null));
			param.setProtocolMessageText(MapUtils.asString(reportRow, Protocol.Fields.PROTOCOLMESSAGETEXT, null));
			param.setProtocolMessageType(MapUtils.asInteger(reportRow, Protocol.Fields.PROTOCOLMESSAGETYPE, null));			
			
			protocolResultList.add(param);
		}

		protocolBrowse.setResultList(protocolResultList);
		protocolBrowse.setTotalCount(MapUtils.asInteger(resultMap, DataUtils.TOTALCOUNT, null));
		
		if(logger.isDebugEnabled()) {			
			logger.debug("ProtocolDAO.getListByParams" + " ResultList = " + protocolBrowse.toString());
		}		
		return protocolBrowse;
	}
	
}
