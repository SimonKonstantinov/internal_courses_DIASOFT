package ru.diasoft.flextera.services.ftfcreportws.utils.context;

import java.util.Locale;

import ru.diasoft.core.application.command.CommandContext;
import ru.diasoft.utils.XMLUtil;

public interface Environment {

    String getLogin();

    String getPassword();

    Locale getLocale();
    
    XMLUtil getXmlUtil();

    CommandContext getCommandContext();

}
