package ru.diasoft.flextera.services.ftfcreportws.utils.context;

public class EnvironmentHolder {

    private static final InheritableThreadLocal<Environment> contextHolder = new InheritableThreadLocal<Environment>();

    public static void setCurrentContext(Environment environment) {
		if (environment == null) {
			throw new IllegalStateException("Environment cannot be NULL!");
		}
		contextHolder.set(environment);
	}

    /**
     * Инициализация EnvironmentHolder происходит в методе call класса FTFCREPORTWSImpl!
     * 
     * @return
     */
    public static Environment currentContext() {
    	Environment environment = contextHolder.get();
    	if(environment == null){
			throw new IllegalStateException(
					"Environment cannot be NULL! Check method call in FTFCREPORTWSImpl, it must contain EnvironmentHolder initialization!");
    	}
    	
    	return environment;
    }
}
