package ru.diasoft.flextera.services.ftfcreportws.command.dao.report;

import java.util.List;

import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportIDListTypeForDSFCReportMassInsert;
import ru.diasoft.flextera.services.ftfcreportws.type.TNotificationListTypeForDSFCReportMassInsert;

public class ReportMassInsertResult {

	private List<TFCReportIDListTypeForDSFCReportMassInsert> reportIDList;
	private List<TNotificationListTypeForDSFCReportMassInsert> reportNtfList;
	private Long returnCode;
	private String returnMsg;

	public List<TFCReportIDListTypeForDSFCReportMassInsert> getReportIDList() {
		return reportIDList;
	}

	public void setReportIDList(List<TFCReportIDListTypeForDSFCReportMassInsert> reportIDList) {
		this.reportIDList = reportIDList;
	}

	public void setReturnCode(Long returnCode) {
		this.returnCode = returnCode;
	}

	public Long getReturnCode() {
		return returnCode;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReportNtfList(List<TNotificationListTypeForDSFCReportMassInsert> reportNtfList) {
		this.reportNtfList = reportNtfList;
	}

	public List<TNotificationListTypeForDSFCReportMassInsert> getReportNtfList() {
		return reportNtfList;
	}
	
	
}
