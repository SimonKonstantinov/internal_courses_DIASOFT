package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import java.util.List;import org.apache.log4j.Logger;import ru.diasoft.core.application.command.CommandException;import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportBrowse;import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportDAO;import ru.diasoft.flextera.services.ftfcreportws.type.TFCReportBrowseListTypeForDSFCReportBrowseListByParam;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportBrowseListByParamReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportBrowseListByParamRes;import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;
/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportBrowseListByParam extends DsFCReportBrowseListByParamStub {
	
	private static final String METHOD_NAME = "dsFCReportBrowseListByParam";	private static final Logger logger = Logger.getLogger(DsFCReportBrowseListByParam.class);
	
	/**
	 * Метод получения основной информации по списку отчетов
	 * 
	 * @param FCReportID Идентификатор отчета
	 * @param FCReportName Наименование отчета
	 * @param FCReportSysName Системное наименование отчета
	 * @param UserLogin Логин пользователя
	 * @param ORDERBY Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 * @param PAGE Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 * @param ROWSCOUNT Число записей на страницу для постраничной разбивки. По умолчанию 10
	 * 
	 * @return TOTALCOUNT Общее количество найденных записей
	 * @return Result Список основных атрибутов отчетов	 * @return ReturnMsg Сообщение	 * @return ReturnCode Код	  
	 */
	@Override
	protected void executeCommand() throws CommandException {		DsFCReportBrowseListByParamReq request = getInputData();		DsFCReportBrowseListByParamRes response = getOutputData();		
		if(logger.isDebugEnabled()){						logger.debug(METHOD_NAME + " has started. Request = " + request.toString());		}		try {			Long reportID = request.getFCReportID(); // Входящий параметр ReportID							ReportBrowse reportBrowse = ReportDAO.getInstance().getBrowseListByParam(request);			response.setResult(reportBrowse.getResultList());			response.setTOTALCOUNT(reportBrowse.getTotalCount());						// Код ошибки, если отчет не найден по переданному идентификатору	     	if (reportID != null && reportID > 0L) {		     	List<TFCReportBrowseListTypeForDSFCReportBrowseListByParam> resultList = reportBrowse.getResultList();	     		if (resultList.size() > 0){	     			TFCReportBrowseListTypeForDSFCReportBrowseListByParam resultParam = resultList.get(0);	     			if (!reportID.equals(resultParam.getFCReportID())) {						response.setReturnCode(RetCode.OBJECT_NOT_FOUND.getCode());						response.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());						if(logger.isDebugEnabled()){							logger.debug(METHOD_NAME + " Object by ID not found");						}	     			}	     		}	     		else {					response.setReturnCode(RetCode.OBJECT_NOT_FOUND.getCode());					response.setReturnMsg(RetCode.OBJECT_NOT_FOUND.getMessage());					if(logger.isDebugEnabled()){						logger.debug(METHOD_NAME + " Object by ID not found");					}						     		}	     	}     			     	//	     				if(logger.isDebugEnabled()){								logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());			}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);			CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}		
	}}
