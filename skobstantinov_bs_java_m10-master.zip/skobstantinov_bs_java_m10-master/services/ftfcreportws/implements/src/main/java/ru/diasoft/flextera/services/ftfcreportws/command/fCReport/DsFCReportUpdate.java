package ru.diasoft.flextera.services.ftfcreportws.command.fCReport;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportDAO;import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.ReportUpdateResult;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportUpdateReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.*;
import org.apache.log4j.Logger;

import ru.diasoft.core.application.command.CommandException;

/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportUpdate extends DsFCReportUpdateStub {
	private static final String METHOD_NAME = "dsFCReportUpdate";	
	private static final Logger logger = Logger.getLogger(DsFCReportUpdate.class);
	
	/**	 * Метод обновления пользовательского отчета	 * 	 * @param FCReportID Идентификатор отчета	 * @param FCReportName Наименование отчета	 * @param FCReportSysName Системное наименование отчета	 * @param FileFormat Формат файла, в котором будет сохранен отчет. Возможные значения:<br>	 *	1 - xml;<br>	 *	2 - pdf;<br>	 *	3 - rtf.	 * @param DeleteDataFlag Флаг удаления данных, загруженных для экземпляра отчета	 * @param TemplatePathName Путь и наименование файла шаблона отчета	 * @param ConfigPathName Путь и наименование конфигурационного файла	 * 	 * @return ReturnMsg Сообщение	 * @return ReturnCode Код	 */	@Override
	protected void executeCommand() throws CommandException {
		DsFCReportUpdateReq request = getInputData();		DsFCReportUpdateRes response = getOutputData();			if(logger.isDebugEnabled()){						logger.debug(METHOD_NAME + " has started. Request = " + request.toString());		}		try {									ReportUpdateResult result = ReportDAO.getInstance().update(request);				response.setReturnCode(result.getReturnCode());			response.setReturnMsg(result.getReturnMsg());							if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());							}		} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);						CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}					
	}
}
