package ru.diasoft.flextera.services.ftfcreportws.utils.external.services;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import ru.diasoft.flextera.services.ftfcreportws.command.dao.history.ReportHistoryDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolDAO;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.protocol.ProtocolMessage;
import ru.diasoft.flextera.services.ftfcreportws.command.dao.report.Report;
import ru.diasoft.flextera.services.ftfcreportws.report.database.DatabaseConstants;
import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportProcessExecuteBuildingReq;
import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportProcessExecuteBuildingRes;
import ru.diasoft.flextera.services.ftfcreportws.utils.ConfigUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.ExecuteStatus;
import ru.diasoft.flextera.services.ftfcreportws.utils.FileFormat;
import ru.diasoft.flextera.services.ftfcreportws.utils.MapUtils;
import ru.diasoft.flextera.services.ftfcreportws.utils.ProjectConstants;
import ru.diasoft.flextera.services.ftfcreportws.utils.ReportType;
import ru.diasoft.flextera.services.ftfcreportws.utils.RetCode;
import ru.diasoft.flextera.services.ftfcreportws.utils.context.EnvironmentHolder;
import ru.diasoft.flextera.services.ftfcreportws.utils.external.ExternalService;

public class ReportWSInvoker {

	private static final String DATASOURCEALIAS = "DATASOURCEALIAS";
	private static final String CUSTOMDS = "CUSTOMDS";
	private static final char DOT = '.';
	
	private Logger logger = Logger.getLogger(ReportWSInvoker.class);
	
	public void buildReport(DsFCReportProcessExecuteBuildingReq request, Report report, Map<String, Object> inputParams, DsFCReportProcessExecuteBuildingRes response) throws Exception{
		String reportName = request.getFCReportFileName();
		String templateName = report.getTemplateName();
		
		ReportType reportType = getReportTypeByTemplateName(templateName, response);
		if(reportType == null){
			return;
		}
		
		String methodName = FileFormat.getMethodNameByCode(report.getFileFormat());
		
		if (logger.isDebugEnabled()) {
			logger.debug("Building report: reportName = " + reportName + ", templateName = " + templateName + ", reportwsMethodName = "
					+ methodName + ", inputParams = " + inputParams);
		}
		
		// Протокол "Запущено выполнение шаблона отчета"
		ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.BUILDING_REPORT_START, templateName);		
		
		Map<String, Object> reportParams = createReportWSParams(reportType, inputParams, response, reportName, templateName, methodName);
		
		try {
			Map<String, Object> result = ExternalService.getInstance().callExternalService(EnvironmentHolder.currentContext().getXmlUtil(), ConfigUtils.getReportWS(), 
				methodName, reportParams);

			// Протокол "Файл отчета сформирован"
			String outputReportName = getOutputReportFileName(reportType, reportName, methodName);
			
			ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.BUILDING_REPORT_DONE, outputReportName);		
			ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), null, null, outputReportName);
			
			if(logger.isDebugEnabled()){
				logger.debug("reportws response = " + result);
			}
		
		}
		catch (Throwable t){
			String errorMessage = "Error building report: reportName = " + reportName + ", templateName = " + templateName; 
			logger.error(errorMessage, t);

			// Протокол "Ошибка запуска выполнение шаблона отчета"
			ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.BUILDING_REPORT_ERROR, templateName);			
			// Статус отчета ERROR
			ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), null);
			response.setReturnCode(RetCode.CALL_REPORT_TEMPLATE_ERROR.getCode());
			response.setReturnMsg(RetCode.CALL_REPORT_TEMPLATE_ERROR.getMessage(templateName));			
			
			throw new Exception(errorMessage, t);			
		} 
	}

	private Map<String, Object> createReportWSParams(ReportType reportType, Map<String, Object> inputParams, DsFCReportProcessExecuteBuildingRes response,
			String reportName, String templateName, String methodName) throws Exception {
		
		
		Map<String, Object> reportParams = new HashMap<String, Object>();
		inputParams.put(DatabaseConstants.PROCESSID, response.getProcessID());
		
		if(ReportType.JRXML.equals(reportType)){
			templateName = templateName.substring(0, templateName.lastIndexOf(DOT));
			
			inputParams.put(ReportwsConstanst.REPORT_NAME, reportName);
			inputParams.put(ReportwsConstanst.TEMPLATE_NAME, templateName);
			putDataSourceParams(inputParams);
			
			reportParams.put(ReportwsConstanst.TEMPLATE_NAME, templateName);
			reportParams.put(ReportwsConstanst.REPORT_FORMATS, methodName);
			reportParams.put(ReportwsConstanst.SAVE_FILE, ReportwsConstanst.FILE);
			reportParams.put(ReportwsConstanst.PROJECT, ReportwsConstanst.FTFC_REPORT);
			reportParams.put(ReportwsConstanst.USER, EnvironmentHolder.currentContext().getLogin());
			reportParams.put(ReportwsConstanst.REPORT_PARAMS, inputParams);
			
		} else if(ReportType.TPR.equals(reportType)){ 
			reportParams.put(ReportwsConstanst.REPORT_TYPE_TPR, ReportwsConstanst.REPORT_TYPE_TPR_VALUE);
			reportParams.put(ReportwsConstanst.REPORT_NAME_TPR, templateName);
			reportParams.put(ReportwsConstanst.REPORT_INPUT_PARAMS_TPR, inputParams);
			reportParams.put(ReportwsConstanst.PROJECT_SYS_NAME_TPR, ReportwsConstanst.FTFC_REPORT);
			reportParams.put(ReportwsConstanst.PROJECT, ReportwsConstanst.FTFC_REPORT);
			reportParams.put(ReportwsConstanst.REPORT_UUID, reportName);
		}
		
		return reportParams;
	}	

	private void putDataSourceParams(Map<String, Object> inputParams) throws Exception {
		inputParams.put(DATASOURCEALIAS, CUSTOMDS);
		Map<String, Object> configParams = ConfigUtils.getProjectConfigMap();
		
		inputParams.put(ProjectConstants.PARAMETER_DATA_SOURCE_URL, MapUtils.asString(configParams, ProjectConstants.PARAMETER_DATA_SOURCE_URL));
		inputParams.put(ProjectConstants.PARAMETER_JDBC_DRIVER, MapUtils.asString(configParams, ProjectConstants.PARAMETER_JDBC_DRIVER));
		inputParams.put(ProjectConstants.PARAMETER_PASSWORD, MapUtils.asString(configParams, ProjectConstants.PARAMETER_PASSWORD));
		inputParams.put(ProjectConstants.PARAMETER_USER_NAME, MapUtils.asString(configParams, ProjectConstants.PARAMETER_USER_NAME));
		inputParams.put(ProjectConstants.PARAMETER_MAX_CON, MapUtils.asString(configParams, ProjectConstants.PARAMETER_MAX_CON));
		inputParams.put(ProjectConstants.PARAMETER_MIN_CON, MapUtils.asString(configParams, ProjectConstants.PARAMETER_MIN_CON));
	}	

	private ReportType getReportTypeByTemplateName(String templateName, DsFCReportProcessExecuteBuildingRes response) throws Exception {
		ReportType reportType = null;
		if(templateName.endsWith(ReportType.JRXML.getExtension())){
			reportType = ReportType.JRXML;
		}else if(templateName.endsWith(ReportType.TPR.getExtension())){
			reportType = ReportType.TPR;
		} else {
			String fileExtension = "";
			if(templateName.contains(".")){
				fileExtension = templateName.substring(templateName.lastIndexOf(DOT) + 1);
			}
			String errorMessage = "Incorrect report template [" + templateName + "] file extension [" + fileExtension + "]"; 
			logger.error(errorMessage);
			
			ProtocolDAO.getInstance().addReportProtocol(response.getProcessID(), ProtocolMessage.INCORRECT_TEMPLATE_EXTENSION,
					templateName, fileExtension);
			
			// Статус отчета ERROR
			ReportHistoryDAO.getInstance().modifyReportHistory(response.getProcessID(), new Date(), ExecuteStatus.ERROR.getStateCode(), null);
			response.setReturnCode(RetCode.INCORRECT_TEMPLATE_EXTENSION.getCode());
			response.setReturnMsg(RetCode.INCORRECT_TEMPLATE_EXTENSION.getMessage(templateName, fileExtension));
			
		}
		return reportType;
	}

	private String getOutputReportFileName(ReportType reportType, String reportName, String methodName) {
		String outputFileName = null;
		if(ReportType.TPR.equals(reportType)){
			outputFileName = reportName + ".txt" + reportName;
		} else {
			outputFileName = reportName + '.' + methodName;			
		}
		return outputFileName;
	}


}
