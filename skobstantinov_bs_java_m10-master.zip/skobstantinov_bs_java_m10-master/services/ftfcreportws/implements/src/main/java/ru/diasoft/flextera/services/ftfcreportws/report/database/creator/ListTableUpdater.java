package ru.diasoft.flextera.services.ftfcreportws.report.database.creator;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ru.diasoft.flextera.services.ftfcreportws.utils.DataBaseType;

public class ListTableUpdater extends TableUpdater{

	public ListTableUpdater(Object value, Long processID, ResultSet tableResultSet, DataBaseType dataBaseType) throws Exception {
		super(value, processID, tableResultSet, dataBaseType);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected List<String> prepareInsertQuery(String schemaName, String tableName, Object parameterValue) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Prepare insert query: tableName = " + tableName + ", parameterValue = " + parameterValue) ;
		}
		
		List<String> result = new ArrayList<String>();
		
		List<Map<String, Object>> parameterValueList = (List<Map<String, Object>>) parameterValue;
		
		for (Map<String, Object> map : parameterValueList) {
			createInsertStringByMap(schemaName, tableName, result, map);
		}
		
		return result;
	}
	

	@Override
	protected TableColumns createOrModifyTableColumns(Object value, ResultSet columnsResultSet) throws Exception {
		TableColumns tableColumns = null;
		
		if(columnsResultSet == null){
			tableColumns = create(value);
		} else {
			tableColumns = modify(value, columnsResultSet);
		}
		
		return tableColumns;
	}

	@SuppressWarnings("unchecked")
	private TableColumns create(Object parameterValue) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Creation of tableColumns object has started. ParameterValue = " + parameterValue);
		}
		
		if(!(parameterValue instanceof List)){
			throw new SQLException("Create new table error: incorrect parameterValue class. Expected: java.util.List, but was "
					+ parameterValue.getClass());
		}
		
		List<Map<String, Object>> parameterValueList = (List<Map<String, Object>>) parameterValue;
		if(parameterValueList.size() == 0){
			throw new SQLException("parameterValue is empty. Could not create new table.");
		}
		
		TableColumns tableColumns = createTableColumnsByListMap(parameterValueList);
		
		return tableColumns;
	}

	@SuppressWarnings("unchecked")
	private TableColumns modify(Object parameterValue, ResultSet columnsResultSet) throws Exception {
		if(logger.isDebugEnabled()){
			logger.debug("Modifying of tableColumns object has started. ParameterValue = " + parameterValue);
		}
		
		if(!(parameterValue instanceof List)){
			throw new SQLException("Modifying of table error: incorrect parameterValue class. Expected: java.util.List, but was "
					+ parameterValue.getClass());
		}
		
		TableColumns tableColumns = null;

		List<Map<String, Object>> parameterValueList = (List<Map<String, Object>>) parameterValue;

		if (parameterValueList.size() > 0) {
			tableColumns = modifyTableColumnsByListMap(columnsResultSet, parameterValueList);
		}
		
		return tableColumns;
	}


}
