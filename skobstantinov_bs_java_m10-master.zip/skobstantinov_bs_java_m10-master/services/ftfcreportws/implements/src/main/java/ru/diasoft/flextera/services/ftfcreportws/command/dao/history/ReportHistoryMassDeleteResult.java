package ru.diasoft.flextera.services.ftfcreportws.command.dao.history;

import java.util.List;

import ru.diasoft.flextera.services.ftfcreportws.type.TNotificationListTypeForDSFCReportMassDeleteInstance;

public class ReportHistoryMassDeleteResult {

	private List<TNotificationListTypeForDSFCReportMassDeleteInstance> reportHistoryNtfList;	
	private Long returnCode;
	private String returnMsg;
	
	public List<TNotificationListTypeForDSFCReportMassDeleteInstance> getReportHistoryNtfList() {
		return reportHistoryNtfList;
	}
	public void setReportHistoryNtfList(List<TNotificationListTypeForDSFCReportMassDeleteInstance> reportHistoryNtfList) {
		this.reportHistoryNtfList = reportHistoryNtfList;
	}
	public Long getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(Long returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMsg() {
		return returnMsg;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}	
	
}
