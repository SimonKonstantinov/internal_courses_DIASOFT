package ru.diasoft.flextera.services.ftfcreportws.report.database;

public class DatabaseConstants {

	public static String NODE_NAME = "FTFCREPORTWSNode";
	
	public static final String DB_TYPE_DATE = "NUMERIC(21,0)";
	
	public static final String DB_TYPE_LONG = "NUMERIC(19,0)";
	
	public static final String DB_TYPE_INTEGER = "INTEGER";
	
	public static final String DB_TYPE_BIG_DECIMAL = "NUMERIC(28, 10)";
	
	public static final String DB_TYPE_BOOLEAN = "VARCHAR(25)";
	
	public static final String DB_TYPE_STRING = "VARCHAR(3500)";
	
	public static final int DATE_SCALE_0 = 0;
	
	public static final int DATE_PRECISION_21 = 21;
	
	public static final int LONG_PRECISION_19 = 19;
	
	public static final int INTEGER_ORACLE_PRECISION = 38;
	
	public static final int BIG_DECIMAL_SCALE_10 = 10;
	
	public static final int BIG_DECIMAL_PRECISION_28 = 28;
	
	public static final int BOOLEAN_PRECISION_25 = 25;
	
	public static final int STRING_PRECISION_3500 = 3500;
	
	public static final String INT = "INT";
	
	public static final String NUM = "NUM";
	
	public static final String VARCHAR = "VARCHAR";
	
	public static final String FCR = "FCR_";
	
	public static final String DELETE_FROM = "DELETE FROM ";
	
	public static final String WHERE_PROCESSID = " WHERE PROCESSID = ";

	public static final String NUMERIC_19_0 = "NUMERIC(19,0)";
	
	public static final String PROCESSID = "PROCESSID";
	
	public static final String PROCESSID_COLUMN = "PROCESSID NUMERIC(19, 0) NOT NULL";
	
	public static final String PROCESSID_COLUMN_NULL = "PROCESSID NUMERIC(28, 10) NULL";
	
	public static final String SCIENTIFIC_ZERO = "0E-10";
	
	public static final String NULL_WITH_COMMA = " NULL, ";
	
	public static final String NULL = "NULL";
	
	public static final String VALUE = "VALUE";

	public static final String ADD = "ADD";

	public static final String COLUMN = "COLUMN";

}
