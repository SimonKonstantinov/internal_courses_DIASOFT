package ru.diasoft.flextera.services.ftfcreportws.report.parser;

public class InputParameter {

	public static interface Fields {
		String SYSNAME = "sysname";
		String NAME = "name";
		String TYPE = "type";
		String REQUIRED = "required";
		String DEFAULT_VALUE = "defaultValue";
	}
	
}
