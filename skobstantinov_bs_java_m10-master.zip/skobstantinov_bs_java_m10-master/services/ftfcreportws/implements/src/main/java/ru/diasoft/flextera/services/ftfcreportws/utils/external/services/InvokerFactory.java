package ru.diasoft.flextera.services.ftfcreportws.utils.external.services;

public class InvokerFactory {
	
	public static InvokerFactory getInstance(){
		return new InvokerFactory();
	}
	
	private InvokerFactory(){
	}

	public ReportWSInvoker getReportWSInvoker(){
		return new ReportWSInvoker();
	}
}
