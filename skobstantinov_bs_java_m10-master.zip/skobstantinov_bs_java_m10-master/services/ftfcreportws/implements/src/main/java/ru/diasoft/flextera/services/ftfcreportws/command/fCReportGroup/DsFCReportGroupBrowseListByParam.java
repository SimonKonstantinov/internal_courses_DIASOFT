package ru.diasoft.flextera.services.ftfcreportws.command.fCReportGroup;
import org.apache.log4j.Logger;import ru.diasoft.core.application.command.CommandException;import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroupBrowseListResult;import ru.diasoft.flextera.services.ftfcreportws.command.dao.group.ReportGroupDAO;import ru.diasoft.flextera.services.ftfcreportws.type.request.DsFCReportGroupBrowseListByParamReq;import ru.diasoft.flextera.services.ftfcreportws.type.response.DsFCReportGroupBrowseListByParamRes;
/**
 * @see {@link #executeCommand()}
 */
public class DsFCReportGroupBrowseListByParam extends DsFCReportGroupBrowseListByParamStub {
	
	/**
	 * Получение списка групп отчетов по параметрам
	 * 
	 * @param FCReportGroupID Идентификатор группы пользовательских отчетов
	 * @param FCReportGroupName Наименование группы пользовательских отчетов
	 * @param FCReportGroupSysName Системное наименование группы пользовательских отчетов
	 * @param PAGE Номер отображаемой страницы. По умолчанию номер страницы =1 (если не задан).
	 * @param ORDERBY Строка сортировки - перечисление полей выходного набора данных и направления сортировки (ASC или DESC) через запятую. <br>
	 *	Если не задана, сортировка производится по первому полю выходного набора.
	 * @param ROWSCOUNT Число записей на страницу для постраничной разбивки. По умолчанию 10
	 * 
	 * @return TOTALCOUNT Общее количество найденных записей
	 * @return Result Основная информация о группах отчетов
	 * @return ReturnMsg Сообщение
	 * @return ReturnCode Код
	 */		private static final Logger logger = Logger.getLogger(DsFCReportGroupBrowseListByParam.class);	private static final String METHOD_NAME = "dsFCReportGroupBrowseListByParam";	
	@Override
	protected void executeCommand() throws CommandException {
		DsFCReportGroupBrowseListByParamReq request = getInputData();		DsFCReportGroupBrowseListByParamRes response = getOutputData();				if(logger.isDebugEnabled()){			logger.debug(METHOD_NAME + " has started. Request = " + request.toString());					}		try {						ReportGroupBrowseListResult BrowseListResult = ReportGroupDAO.getInstance().getBrowseListByParam(request);						response.setResult(BrowseListResult.getResultList());			response.setTOTALCOUNT(BrowseListResult.getTotalCount());			response.setReturnCode(BrowseListResult.getReturnCode());			response.setReturnMsg(BrowseListResult.getReturnMsg());									if(logger.isDebugEnabled()){				logger.debug(METHOD_NAME + " has finished. Response = " + response.toString());			}					} catch (Exception e) {			logger.error("Error has occured while running " + METHOD_NAME + " " + e.getMessage(), e);						CommandException exception = new CommandException(getContext(), e);			    		throw exception;		}				
	}
}
